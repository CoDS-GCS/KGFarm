#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sns
import math

%matplotlib inline

# In[ ]:


bank_churn = pd.read_csv('../input/churn-for-bank-customers/churn.csv')

# In[ ]:


bank_churn.head()

# In[ ]:


bank_churn.info()

# In[ ]:


sns.countplot(x='Gender',hue='Exited',data=bank_churn,palette='rainbow')

# In[ ]:


sns.countplot(x='Geography',hue='Exited',data=bank_churn,palette='rainbow')

# From this plot Germany customer was exited close to France customer. In spite of France customer are two time more than Germany customer.

# In[ ]:


sns.countplot(x='NumOfProducts',hue='Exited',data=bank_churn,palette='rainbow')


# Number of product has significant effect for exited decision

# In[ ]:


sns.countplot(x='HasCrCard',hue='Exited',data=bank_churn,palette='rainbow')


# In[ ]:


sns.countplot(x='IsActiveMember',hue='Exited',data=bank_churn,palette='rainbow')


# In[ ]:


geography = pd.get_dummies(bank_churn['Geography'],drop_first=True)
gender = pd.get_dummies(bank_churn['Gender'],drop_first=True)

# In[ ]:


bank_churn.drop(['RowNumber', 'CustomerId', 'Surname', 'Geography', 'Gender'], axis = 1, inplace = True)

# In[ ]:


bank_churn = pd.concat([bank_churn, geography, gender],axis=1)

# In[ ]:


bank_churn.head()

# In[ ]:


bank_churn.info()

# In[ ]:


bank_churn.isnull().sum()

# ## Logistic regression

# ## Train and Test data

# In[ ]:


X = bank_churn.drop('Exited', axis = 1)
Y = bank_churn['Exited']

# In[ ]:


from sklearn.model_selection import train_test_split

# In[ ]:


X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.30)

# ## Training and Predicting

# In[ ]:


from sklearn.linear_model import LogisticRegression

# In[ ]:


logmodel = LogisticRegression()
logmodel.fit(X_train,y_train)

# In[ ]:


predictions = logmodel.predict(X_test)

# ## Evaluation

# In[ ]:


from sklearn.metrics import classification_report

# In[ ]:


print(classification_report(y_test,predictions))
