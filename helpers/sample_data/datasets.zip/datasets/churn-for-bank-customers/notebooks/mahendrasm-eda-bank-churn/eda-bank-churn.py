#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns
pd.options.display.max_rows = None
pd.options.display.max_columns = None

# In[ ]:


xy = pd.read_csv("../input/churn-for-bank-customers/churn.csv")

# In[ ]:


import os.path
homedir = os.path.expanduser("~")
print(homedir)

# In[ ]:


xy.shape

# In[ ]:


# Get unique count for each variable
xy.nunique()

# In[ ]:


# Drop the columns whixh are specific to customers
xy = xy.drop(["RowNumber", "CustomerId", "Surname"], axis = 1)

# In[ ]:


xy.shape

# In[ ]:


xy.head()

# In[ ]:


# Check data types
xy.dtypes

# In[ ]:


labels = ["Churned", "Retained"]
y = [xy.Exited[xy['Exited']==1].count(), xy.Exited[xy['Exited']==0].count()]
explode = (0, 0.1)
plt.pie(y, labels = labels, explode = explode, startangle = 90, autopct='%1.1f%%',)
plt.show() 

# In[ ]:


fig, sty = plt.subplots(2, 2, figsize=(15, 8))
sns.countplot(data = xy, x='Geography', hue='Exited', ax = sty[0][0])
sns.countplot(data = xy, x='Gender', hue = 'Exited', ax = sty[0][1])
sns.countplot(data = xy, x='HasCrCard', hue = 'Exited',ax = sty[1][0])
sns.countplot(data = xy, x='IsActiveMember', hue = 'Exited', ax = sty[1][1])

# In[ ]:


fig, sty = plt.subplots(3, 2, figsize=(20, 15))
sns.boxplot(data = xy, y='CreditScore',x = 'Exited', hue = 'Exited', ax=sty[0][0])
sns.boxplot(data = xy, y='Age',x = 'Exited', hue = 'Exited', ax=sty[0][1])
sns.boxplot(data = xy, y='Tenure',x = 'Exited', hue = 'Exited', ax=sty[1][0])
sns.boxplot(data = xy, y='Balance',x = 'Exited', hue = 'Exited', ax=sty[1][1])
sns.boxplot(data = xy, y='NumOfProducts',x = 'Exited', hue = 'Exited', ax=sty[2][0])
sns.boxplot(data = xy, y='EstimatedSalary',x = 'Exited', hue = 'Exited', ax=sty[2][1])

# In[ ]:



