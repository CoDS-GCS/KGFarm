#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[ ]:


df=pd.read_csv('../input/bank-customer-churn-modeling/Churn_Modelling.csv')
df.head()

# In[ ]:


df.drop(['RowNumber','CustomerId','Surname'],axis=1,inplace=True)

# In[ ]:


df.Geography.unique()

# In[ ]:


df[df.Exited==1]

# In[ ]:


from matplotlib import pyplot as plt
plt.hist([df[df.Exited==1].Balance,df[df.Exited==0].Balance])

# we understood that where the balance is zero there is high number of people are there

#  

# In[ ]:


plt.hist([df[df.Exited==1].CreditScore,df[df.Exited==0].CreditScore])

# some type of visualisation is over let's do the feature engineering

# In[ ]:


df['Gender'].replace({'Male':1,'Female':0},inplace=True)

# In[ ]:


df['Geography'].replace({'France':1,'Spain':0,'Germany':2},inplace=True)

# In[ ]:


df.head()

# In[ ]:


import seaborn as sn
sn.boxenplot(data=df,y=df.Balance)

# we cannot assume that above 200000 is outlier because in bank deposit above 2 lakh is common but this 
# data is imbalanced i think so

# In[ ]:


df1=df.Balance>200000
df1.value_counts()

# In[ ]:


df = df.loc[df["Balance"] < 200000]

# In[ ]:


df.shape

# But we have to go with the data that's why we removed outlier's in data

# and check estimated salary outlier's in it

# In[ ]:


sn.boxenplot(data=df,y=df.EstimatedSalary)

# as per data no outlier's
# and start building the model

# In[ ]:


df.dtypes

# In[ ]:


df.Balance = df.Balance.astype(int)
df.EstimatedSalary = df.EstimatedSalary.astype(int)

# In[ ]:


cols_to_scale = ['CreditScore','Geography','Age','Tenure','Balance','NumOfProducts','EstimatedSalary']

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
df[cols_to_scale] = scaler.fit_transform(df[cols_to_scale])

# In[ ]:


x=df.drop('Exited',axis=1)

y=df.Exited

# In[ ]:


from sklearn.model_selection import train_test_split,cross_val_score
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=None)

# In[ ]:


import tensorflow as tf
from tensorflow import keras

# In[ ]:


x_train.shape

# In[ ]:


model=keras.Sequential([
    keras.layers.Dense(10, input_shape=(10,),activation='relu'),
    keras.layers.Dense(5,activation='sigmoid'),
    keras.layers.Dense(1,activation='sigmoid')
])
model.compile(optimizer='SGD',
             loss='binary_crossentropy',
             metrics=['accuracy'])

# In[ ]:


model.fit(x_train,y_train,epochs=5)

# In[ ]:


model.evaluate(x_test,y_test)

# In[ ]:


from sklearn.linear_model import LogisticRegression
cross_val_score(LogisticRegression(),x,y).mean()
