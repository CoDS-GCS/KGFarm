#!/usr/bin/env python
# coding: utf-8

# * [Statistical Estimators](#Statistical Estimators)
#     - [Central Tendency](#Central Tendency)
#     - [Mean](#Mean)
#     - [Median](#Median)
#     - [Mode](#Mode)
#     - [Variance](#Variance)
#     - [Standard deviation](#Standard deviation)
#     - [Covariance](#Covariance)
#     - [Correlation / Pearson's Correlation](#Correlation / Pearson's Correlation)
#     - [Standard Error](#Standard Error)     
# * [Probability Distributions](#Probability Distributions)
#     - [Gausian / Normal distribution](#Gausian / Normal distribution)  
#          - [Standard Normal distribution](#Standard Normal distribution)
#     - [Student’s T-Distribution](#Student’s T-Distribution) 
#     - [Binomial Distribution](#Binomial Distribution) 
#     - [Bernoulli’s Distribution](#Bernoulli’s Distribution) 
#     - [Uniform Distribution](#Uniform Distribution)
#     - [Exponential Distribution](#Exponential Distribution)
#     - [Poisson Distribution](#Poisson Distribution)
#     - [Probability Density Function and Probability Mass Function](#Probability Density Function and Probability Mass Function)
# * [P-value](#P-value)
# * [Degrees of Freedom](#Degrees of Freedom)
# * [Parametric vs. Non-Parametric Data](#Parametric vs. Non-Parametric Data) 
#      - [Parametric Data](#Parametric Data)
#      - [Non-Parametric Data](#Non-Parametric Data) 
# * [Univariate Statistical Analysis](#Univariate Statistical Analysis)
#      - [Normality Tests](#Normality Tests)
#          - [Shapiro-Wilk Test](#Shapiro-Wilk Test) 
#          - [D’Agostino’s K^2 Test](#D’Agostino’s K^2 Test) 
#          - [Anderson-Darling Test](#Anderson-Darling Test)
#      - [Correlation Tests](#Correlation Tests)  
#          - [Covariance Analysis](#Covariance Analysis) 
#          - [Pearson’s Correlation Coefficient](#Pearson’s Correlation Coefficient) 
#          - [Spearman’s Rank Correlation](#Spearman’s Rank Correlation) 
#          - [Chi-Squared Test](#Chi-Squared Test)
#      - [Parametric Statistical Hypothesis Tests](#Parametric Statistical Hypothesis Tests)
#           - [Student’s t-test](#Student’s t-test) 
#           - [Analysis of Variance Test (ANOVA)](#Analysis of Variance Test)
#      - [Nonparametric Statistical Hypothesis Tests](#Nonparametric Statistical Hypothesis Tests)
#           - [Mann-Whitney U Test](#Mann-Whitney U Test) 
#           - [Wilcoxon Signed-Rank Test](#Wilcoxon Signed-Rank Test) 
#           - [Kruskal-Wallis H Test](#Kruskal-Wallis H Test) 
#           - [Friedman Test](#Friedman Test)
# * [Multivariate Statistical Analysis](#Multivariate Statistical Analysis)  
#     - [Covariance and Correlation Statistical Analysis](#Covariance and Correlation Statistical Analysis)
# 

# <a id="Statistical Estimators"></a>
# # <u> Statistical Estimators </u>
# 
# <a id="Central Tendency"></a>
# ## <u> Central Tendency </u>
# 
# A measure of central tendency is a single value that describes the way in which a group of data cluster around a central value. It is a way to describe the center of a data set. There are three measures of central tendency: the mean, the median, and the mode.
# 
# <a id="Mean"></a>
# ## <u> Mean </u>
# 
# Add up the values in the data set and then divide by the number of values.
# 
# $$\bar{x} = \frac{\sum{x_i}}{n}$$
# 
# <a id="Median"></a>
# ## <u> Median </u>
# 
# List the values of the data set in numerical order (ascending/ descending) and identify which value appears in the middle of the list.
# 
# $$\text{Median} = \frac{n + 1}{2}$$
# 
# <a id="Mode"></a>
# ## <u> Mode </u>
# 
# Value in the data set which occurs most often.
# 
# 
# <a id="Variance"></a>
# ## <u> Variance </u>
# 
# Variance measures how far a set of data is spread out. Variance of zero indicates that all of the data values are identical. It is the average of the squared distances from each point to the mean.
# 
# $$\sigma^2 = \frac{\sum (x_i - \bar{x})^2}{N}$$
# 
# <a id="Standard deviation"></a>
# ## <u> Standard deviation </u>
# 
# Standard Deviation measures the absolute variability of a datasets’ distribution. It is the square root of variance. It is used more often than variance because the unit in which it is measured is the same as that of mean, a measure of central tendency.
# 
# $$\sigma = \sqrt{\sigma^2}$$
# 
# <a id="Covariance"></a>
# ## <u> Covariance </u>
# 
# Covariance is a measure of how change in one variable is associated with change in a second variable. Covariance measures the degree to which two variables are linearly associated. The sign of the covariance shows the tendency in the linear relationship between the variables. The magnitude of the covariance is not easily interpreted.
# 
# $$Cov(𝑋, 𝑌 ) = \frac{\sum(x_i - \bar{x}) (y_i - \bar{y})}{N-1}$$
# 
# $$Cov(𝑋, 𝑋) = Var(𝑋)$$
# $$Cov(𝑋, 𝑌 ) = Cov(𝑌, 𝑋)$$
# 
# The use of the mean in the calculation suggests the need for each data sample to have a Gaussian or Gaussian-like distribution. Term in numerator is called the sum of cross products. Term in denominator (N-1) indicates the degrees of freedom.
# 
# The value of covariance is affected by the change in scale of the variables. If all the values of the given variable are multiplied by a constant and all the values of another variable are multiplied, by a similar or different constant, then the value of covariance also changes.
# Covariance can take any value between -∞ and +∞.
# 
# <a id="Correlation / Pearson's Correlation"></a>
# ## <u> Correlation / Pearson's Correlation</u>
# 
# Both Covariance and Correlation measures the relationship and the dependency between two variables. “Covariance” indicates the direction of the linear relationship between variables whereas “Correlation” measures both the magnitude and direction of the linear relationship between two variables. Correlation values are standardized whereas, covariance values are not. When we divide the covariance values by the standard deviation, it scales the value down to a limited range of -1 to +1 that represents the limits of correlation from a full negative correlation to a full positive correlation. A value of 0 means no correlation. The value below -0.5 or above 0.5 indicates a notable correlation, and values below those values suggests a less notable correlation.
# 
# $$Corr_{xy} = \frac{Cov(𝑋, 𝑌 )}{\sigma_x \sigma_y}$$
# 
# Types of correlations:
# - Positive Correlation: both variables change in the same direction.
# - Neutral Correlation: No relationship in the change of the variables.
# - Negative Correlation: variables change in opposite directions.
# 
# The value of correlation is not influenced by the change in scale of the values. 
# 
# The performance of some algorithms can deteriorate if two or more variables are tightly related, called multicollinearity. An example is Logistic Regression or Linear Regression. Decision trees and boosted trees algorithms are immune to multicollinearity by nature.
# 
# <b>Quick Tip</b> : Multicollinearity can be handled by: 1 -  Delete one of the perfectly correlated features. 2 -  Use a dimension reduction algorithm such as Principle Component Analysis (PCA).
# 
# 

# <a id="Standard Error"></a>
# ## <u> Standard Error</u>
# 
# The standard error of the mean, also called the standard deviation of the mean tells us how accurate the mean of any given sample from that population is likely to be compared to the true population mean. When the standard error increases, i.e. the means are more spread out, it becomes more likely that any given mean is an inaccurate representation of the true population mean.
# 
# - Draw "n" samples from a population.
# - Calaulate the mean of every sample.
# - Calculate the standard deviation of all the means.
# - Divide by the number of samples observed.
# 
# $$SE(\bar{x}) = \frac{\sigma_x}{\sqrt{n}}$$

# <a id="Confidence Intervals"></a>
# ## <u> Confidence Intervals</u>
# 
# A Confidence Interval is a range of values we are fairly sure our true value (eg. mean) lies in.
# 
# $$\text{Confidence interval} =\bar{X} \pm Z\frac{\sigma}{\sqrt{n}}$$
# 
# Where $\bar{X}$ is the mean, $Z$ is the z-value(calculated from a table) for a confidence interval (eg. 80%, 85%), $\sigma$ is the standard deviation, $n$ is the number of items in a sample.
# 
# <b> Example: Average Height </b>
# 
# We measure the heights of 40 randomly chosen men, and get a mean height of 175cm, We also know the standard deviation of men's heights is 20cm. The 95% Confidence Interval is:  175cm ± 6.2cm.
# 
# This says the true mean (95% of times) of ALL men (population) is likely to be between 168.8cm and 181.2cm.

# <a id="Probability Distributions"></a>
# # <u> Probability Distributions</u>
# 
# In statistics when we use the term Distribution it usually means Probability distribution.
# 
# A Distribution is a function that shows the possible values for a variable and how often they occur.
# 
# Or A Probability Distribution is a mathematical function that can be thought of as providing the probabilities of occurrence of different possible outcomes in an experiment.
# 
# 
# <a id="Gausian / Normal distribution"></a>
# ## <u> Gausian / Normal distribution </u> 
# 
# Normal Distribution is useful because of the <b> Central Limit Theorem (CLT) </b> which states that when a large number of simple random samples are selected from the population and the mean is calculated for each then the distribution of these sample means will assume the normal probability distribution. For example, the distribution of sum of heights of all men in a region tends towards a Gaussian probability distribution.
# 
# - 68% of the data falls within the first standard deviation from the mean.
# - 95% fall within two standard deviations.
# - 99.7% fall within three standard deviations.

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
%matplotlib inline

mu = 0 # mean
variance = 2 #variance
sigma = np.sqrt(variance) #standard deviation",
x = np.linspace(mu - 3*variance, mu + 3*variance, 100)
plt.plot(x, norm.pdf(x, mu, sigma))

# <a id="Standard Normal distribution"></a>
# ### <u> Standard Normal distribution </u> 
# 
# When we standardize a random variable, its ‘mean’ becomes 0 and its standard deviation becomes 1. When a Normal Distribution is standardized, the result is called a Standard Normal Distribution.  
# 
# $$\text{Z} = \frac{x - \mu}{\sigma}$$
# 
# We use the letter Z to denote standardization. The standardized value i.e., Z is known as the z-score.
# 
# These Z scores are important because they tell us how far a value is from the mean. If the Z score of x is zero, then the value of x is equal to the mean.

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
%matplotlib inline

mu = 0 # mean
variance = 1 #variance
sigma = np.sqrt(variance) #standard deviation",
x = np.linspace(mu - 2*variance, mu + 2*variance, 100)
plt.plot(x, norm.pdf(x, mu, sigma))

# <a id="QQ-Plot"></a>
# ### <u> QQ-Plot </u>
# 
# A QQ-Plot is used to visually determine how close a sample is to the normal distribution. The QQ-Plot orders the z-scores from low to high, and plots each value’s z-score on the y-axis; the x-axis is the corresponding quantile of a normal distribution for that value’s rank. Since the data is normalized, the units correspond to the number of standard deviations away of the data from the mean. If the points roughly fall on the diagonal line, then the sample distribution can be considered close to normal.

# In[ ]:


import numpy as np
import statsmodels.api as sm
import pylab

sm.qqplot(x, loc = 0, scale = 1)
pylab.show()

# <a id="Student’s T-Distribution"></a>
# ## <u> Student’s T-Distribution </u>
# 
# T Distribution or Student’s T Distribution is a probability distribution that is used to estimate population parameters when the sample size is small(~30). It is the distribution of the difference between an estimated parameter and its true (or assumed) value divided by the standard deviation of the estimated parameter (standard error).
# 
# Student’s T distribution looks much like a Normal distribution but generally has fatter tails. Fatter tails, allow for a higher dispersion of variables, as there is more uncertainty. The distribution follows Normal Distribution when the sample size is sufficiently large.
# 
# The t-distribution has been used as a reference for the distribution of a sample mean, the difference between two sample means, regression parameters, and other statistics.
# 
# As the z-statistic is related to the standard Normal distribution, the t-statistic is related to the Student’s T distribution. 
# 
# $$t = \frac{\bar{x} - \mu}{\frac{\sigma}{\sqrt{n}}}$$
# 
# $ \bar{x}$ =  Sample Mean, $ \mu$ = Population Mean, $\sigma$ = standard deviation, n  = sample size

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
%matplotlib inline

mu = 0 # mean
variance = 20 #variance
sigma = np.sqrt(variance) #standard deviation",
x = np.linspace(mu - 3*variance, mu + 3*variance, 100)
plt.plot(x, norm.pdf(x, mu, sigma))

# <a id="Binomial Distribution"></a>
# ## <u> Binomial Distribution </u> 
# 
# This type of distribution is used when there are exactly two outcomes of a trial. These outcomes are labeled as “Success” and “Failure”. The random variable X can take value 1 with the probability of success, p, and the value 0 with the probability of failure, q or 1−p.
#  
# The probabilities of success and failure need not be equally likely.
# 
# Same Probability: Probability of head in a toss(0.5/0.5)
# 
# Different Probability: Probability of me winning with superman(0.1/0.9)
# 
# Each trial is independent since the outcome of the previous toss doesn’t determine or affect the outcome of the current toss. An experiment with only two possible outcomes repeated n number of times is called binomial. The parameters of a binomial distribution are N and P where N is the total number of trials and P is the probability of success in each trial.

# In[ ]:


from scipy.stats import binom
import seaborn as sns

data_binom = binom.rvs(n=10,p=0.8,size=10000) # size = number of times to repeat the trials.
ax = sns.distplot(data_binom, kde=True)
ax.set(xlabel='Binomial Distribution', ylabel='Frequency')

# Since the probability(0.8) of success is greater than 0.5 the distribution is skewed towards the right side.

# <a id="Bernoulli’s Distribution"></a>
# ## <u> Bernoulli’s Distribution </u> 
# 
# Bernoulli Distribution is a special case of Binomial Distribution with a single trial.

# In[ ]:


from scipy.stats import bernoulli

data_bern = bernoulli.rvs(size=10000,p=0.6)
ax= sns.distplot(data_bern, kde=False)
ax.set(xlabel='Bernoulli Distribution', ylabel='Frequency')

# <a id="Uniform Distribution"></a>
# ## <u> Uniform Distribution </u> 
# 
# There are two kinds of uniform random variables: discrete and continuous ones.
# 
# A discrete uniform distribution will take a (finite) set of values S, and assign a probability of 1/n to each of them, where n is the amount of elements in S.
# 
# This way, if for instance a variable Y is uniform in {1,2,3}, there’d be 33% chance for each of those values to be assigned to Y.
# 
# In a continuous uniform distribution, probability of Y taking a value in an interval (from c to d) is proportional to its size versus the size of the whole interval (b-a).

# In[ ]:


# import uniform distribution
from scipy.stats import uniform
import seaborn as sns

data_uniform = uniform.rvs(size=1000, loc = 10, scale=20)
ax = sns.distplot(data_uniform, bins=100, kde=True)
ax.set(xlabel='Uniform Distribution ', ylabel='Frequency')

# <a id="Exponential Distribution"></a>
# ## <u> Exponential Distribution </u>
# 
# Exponential Distribution measures the distribution of the time between events.
# 
# <u> Example </u>
# 1. Length of time beteeen metro arrivals,
# 2. Length of time between arrivals at a gas station.
# 3. The life of an Air Conditioner.

# In[ ]:


# Decreasing Exponential Function

import numpy as np 
from scipy.stats import expon
import matplotlib.pyplot as plt 
  
distribution = np.linspace(expon.ppf(0.01), expon.ppf(0.99), 100)
  
plot = plt.plot(distribution, expon.pdf(distribution))

# In[ ]:


from scipy.stats import expon
data_expon = expon.rvs(scale=1,loc=0,size=1000)
ax = sns.distplot(data_expon, kde=True, bins=100)
ax.set(xlabel='Exponential Distribution', ylabel='Frequency')

# <a id="Poisson Distribution"></a>
# ## <u> Poisson Distribution </u>
# 
# Poisson random variable is typically used to model the distribution of events per unit of time or space.
# 
# <u> Example </u>
# - The number of emergency calls recorded at a hospital in a day.
# - The number of thefts reported in an area on a day.
# - The number of customers arriving at a salon in an hour.
# - The number of suicides reported in a particular city.
# - The number of printing errors at each page of the book.
# 
# A distribution is called Poisson distribution when the following assumptions are valid:
# 
# 1. Any successful event should not influence the outcome of another successful event.
# 2. The probability of success over a short interval must equal the probability of success over a longer interval.
# 3. The probability of success in an interval approaches zero as the interval becomes smaller.

# In[ ]:


from scipy.stats import poisson

# "mu" = "The average number of events in an interval.
data_poisson = poisson.rvs(mu=3, size=10000)
ax = sns.distplot(data_poisson, bins=30, kde=True)
ax.set(xlabel='Poisson Distribution', ylabel='Frequency')

# <a id="Probability Density Function and Probability Mass Function"></a>
# ## <u> Probability Density Function and Probability Mass Function </u> 
# 
# Probability density function and Probability mass function is a statistical expression that defines a Probability Distribution for a random variable.
# 
# <b> Probability density function(PDF) </b> is used to determine the probability distribution for a Continuous Random Variable. When the PDF is graphically plotted the area under the curve indicates the interval in which the variable will fall.
# 
# Whereas the <b> Probability Mass Function(PMF) </b> is used to determine the probability distribution for a Discrete Random Variable.

# <a id="P-value"></a>
# # <u> P-value </u>
# 
# <a id="Hypothesis testing"></a>
# ## <u> Hypothesis testing </u>
# Hypothesis testing is a statistical method that is used in making statistical decisions using experimental data. It is an assumption that we make about the population parameter. A hypothesis test evaluates two mutually exclusive statements about a population to determine which statement is best supported by the sample data.
# 
# <b>Null hypothesis </b>: A null hypothesis is a general statement or default position.
# 
# Example : a company production is = 50 unit/per day.
# 
# <b>Alternative hypothesis </b>: The alternative hypothesis is the hypothesis that is contrary to the null hypothesis.
# 
# Example : a company production is !=50 unit/per day etc.
# 
# <b>Level of significance </b>: Refers to the degree of significance in which we accept or reject the null-hypothesis. 100% accuracy is not possible for accepting or rejecting a hypothesis, so we therefore select a level of significance that is usually 5% which means the output should be 95% confident to give similar kind of result in each sample.
# 
# 
# In a Probability Distribution graph, we have the range of values on the x-axis and the frequency of occurrences of different values on the y-axis. If we pick any random value from this distribution, the probability that we will pick values close to the mean is highest as it has the highest peak (due to high occurrence values in that region). If we move away from the peak, the occurrence of the values decreases rapidly and so does the corresponding probability, towards a very small value close to zero.

# In[ ]:


# In a coin toss suppose Head comes 60/100 times, N = 100, P(Head) = 60/100

import scipy.stats
import matplotlib.pyplot as plt

# succes = np.linspace(0, 100, 101)
succes = np.linspace(30, 70, 41)
plt.plot(succes, scipy.stats.binom.pmf(succes, 100, 0.5), 'b-', label="Binomial(100, 0.5)", color = "blue")
upper_succes_tvalues = succes[succes > 60]
plt.fill_between(upper_succes_tvalues, 0, scipy.stats.binom.pmf(upper_succes_tvalues, 100,0.5), alpha=.3, label="p-value")
plt.axvline(x=55, ymin=0, ymax=0.8, color = "orange")
plt.axvline(x=58, ymin=0, ymax=0.5, color = "red")
plt.axvline(x=upper_succes_tvalues[0], ymin=0, ymax=0.2, color = "green")
plt.axvline(x=upper_succes_tvalues[3], ymin=0, ymax=0.15, color = "pink")
_ = plt.legend()
pval = 1 - scipy.stats.binom.cdf(60, 100, 0.5)
print(pval)

# <u> p-value is the cumulative probability (area under the curve) of the values, right of the green line in the figure above.</u>
# 
# Or,
# 
# <u> p-value corresponding to the green point(point of intersection of green line and the curve) tells us about the ‘total probability’ of getting any value to the right hand side of the green line, when the values are picked randomly from the population distribution. </u>
# 
# A large p-value implies that sample scores are more aligned or similar to the population score.

# <a id="Alpha value / Significance Level"></a>
# ## <u> Alpha value / Significance Level</u>
# 
# Alpha value / Significance Level (generally 0.05 or 5%) is a threshold p-value, which we decide before conducting a test of similarity or significance ( Z-test or a T-test).
# 
# Consider the above normal distribution. The red point in this distribution represents the alpha value or the threshold p-value. Now, let’s say that the orange and pink points represent different sample results obtained after an experiment.
# 
# ### p-value > alpha:
# The orange point has a p-value greater than the alpha. As a result, these values can be obtained with fairly high probability. It also means that the results are in favor of the null hypothesis and therefore we fail to reject it. This result is often against the alternate hypothesis (obtained results are from another distribution).
# 
# ### p-value < alpha:
# The pink point has a p-value less than the alpha value (red). As a result, the sample results are a rare outcome. Therefore, they are significantly different from the population.
# 
# The smaller the value of alpha we consider, the harder it is to consider the results as significant.
# 
# 
# <a id="Example"></a>
# ## <u> Example</u>

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import statsmodels.api as sm
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import warnings
warnings.filterwarnings('ignore')

dataset = pd.read_csv("../input/50-startups/50_Startups.csv")
X = dataset[['R&D Spend', 'Administration', 'Marketing Spend', 'State']] 
y = dataset[['Profit']] 
X = pd.get_dummies(X, columns = ['State'])
model = sm.OLS(y, X).fit()
predictions = model.predict(X)
print(model.summary())

# We can clearly see that "Administration" has a p-value over 0.50.
# 
# #### Hypothesis:
# 
# - Null Hypothesis: The independent variable has no significant effect over the target variable.
# - Alternate Hypothesis: The independent variables have a significant effect on the target variable.
# 
# The above results show that "Administration" has no significant effect over the “Profit” earned by the startups. Let’s remove this variable from the model.

# In[ ]:


X.drop(['Administration'], axis = 1, inplace = True) 
model = sm.OLS(y, X).fit()
predictions = model.predict(X)
print(model.summary())

# The most important thing to note in this model summary is that although we have reduced two independent variables, the value of the adjusted R-Square is increased.
# 
# With the help of p-value, we not only made a simpler model with fewer variables,  but we also improved the model’s performance.

# <a id="Remarks"></a>
# ## <u> Remarks </u>
# 
# - Although a low p-value promotes the rejection of the null hypothesis, it addresses nothing about the probability of rejecting it.
# - We choose the significance level before we perform the experiment. If the p-value satisfies our level of significance (p < alpha), only then can we make conclusions.
# - To talk about a null hypothesis being true using a p-value is impossible. A high p-value means that our data is highly consistent with our null hypothesis, nothing more.

# <a id="Degrees of Freedom"></a>
# # <u> Degrees of Freedom </u>
# 
# To explain what degrees of freedom are, let us just take an example. In a set of 3 numbers with the mean as 10 and two out of three variables as 5 and 15, there is only one possibility of the value that the third number can take up i.e. 10. With any set of 3 numbers with the same mean, for example: 12,8 and 10 or say 9,10 and 11, there is only one value for any 2 given values in the set. You can basically change the two values here and the third value fixes itself. The degree of freedom here is 2. Essentially, degrees of freedom is the number of independent data points that went into calculating the estimate.

# <a id="Parametric vs. Non-Parametric Data"></a>
# # <u> Parametric vs. Non-Parametric Data </u>
# 
# <a id="Parametric Data"></a>
# ## <u> Parametric Data </u>
# 
# Parametric data is a sample of data drawn from a known data distribution.
# 
# This means that we already know the distribution and we know its parameters. Often, parametric is shorthand for real-valued data drawn from a Gaussian distribution. This is a useful shorthand, but strictly this is not entirely accurate.
# 
# If we have parametric data, we can use parametric methods and can harness the entire suite of statistical methods developed for data assuming a Gaussian distribution, such as:
# 
# - Summary statistics.
# - Correlation between variables.
# - Significance tests for comparing means.
# 
# In general, we prefer to work with parametric data, and even go so far as to use data preparation methods that make data parametric, such as data transforms, so that we can harness these well-understood statistical methods.
# 
# <a id="Non-Parametric Data"></a>
# ## <u> Non-Parametric Data </u>
# 
# Data that does not fit a known or well-understood distribution is referred to as nonparametric data.
# 
# Data could be non-parametric for many reasons, such as:
# 
# - Data is not real-valued, but instead is ordinal, intervals, or some other form.
# - Data is real-valued but does not fit a well understood shape.
# - Data is almost parametric but contains outliers, multiple peaks, a shift, or some other feature.
# 
# Most parametric methods have an equivalent nonparametric version.
# 
# In general, the findings from nonparametric methods are less powerful than their parametric counterparts, namely because they must be generalized to work for all types of data.
# 
# In the case of real-valued data(that does not fit the familiar Gaussian distribution) or ordinal data or interval data nonparametric statistics are the only type of statistics that can be used.
# 
# <a id="Data Ranking"></a>
# ### <u> Data Ranking </u>
# 
# Before a nonparametric statistical method can be applied, the data must be converted into a rank format.
# 
# Data Ranking is exactly as its name suggests. The procedure is as follows:
# 
# - Sort all data in the sample in ascending order.
# - Assign an integer rank from 1 to N for each unique value in the data sample.

# In[ ]:


from numpy.random import rand
from numpy.random import seed
from scipy.stats import rankdata

data = rand(100)
# rank data
ranked = rankdata(data)
# review first 10 ranked samples
ranked[:10]

# <a id="Univariate Statistical Analysis"></a>
# # <u> Univariate Statistical Analysis </u>
# 
# <a id="Normality Tests"></a>
# ## <u> Normality Tests </u>
# 
# Statistical tests to check if the data has a Gaussian distribution.
# 
# <a id="Shapiro-Wilk Test"></a>
# ### <u> Shapiro-Wilk Test </u>
# 
# Test the null hypothesis that the data is drawn from a normal distribution.
# 
# 

# In[ ]:


from scipy import stats

x = stats.norm.rvs(loc=5, scale=3, size=100)
stat, p = stats.shapiro(x)
print('stat=%.3f, p=%.3f' % (stat, p))
if p > 0.05:
    print('Probably Gaussian')
else:
    print('Probably not Gaussian')

# <a id="D’Agostino’s K^2 Test"></a>
# ### <u> D’Agostino’s $K^2$ Test </u>
# 
# Test the null hypothesis that the data is drawn from a normal distribution.
# 

# In[ ]:


from scipy import stats

x = stats.norm.rvs(loc=5, scale=3, size=100)
stat, p = stats.normaltest(x)
print('stat=%.3f, p=%.3f' % (stat, p))
if p > 0.05:
    print('Probably Gaussian')
else:
    print('Probably not Gaussian')

# <a id="Anderson-Darling Test"></a>
# ### <u> Anderson-Darling Test </u> 
# 
# Test the null hypothesis that the data is drawn from a particular distribution.
# 
# 

# In[ ]:


from scipy.stats import anderson

data_expon = expon.rvs(scale=1,loc=0,size=1000)

statistic, critical_values, significance_level = anderson(data_expon, dist='expon')
print(statistic)

for i in range(len(critical_values)):
    sl, cv = significance_level[i], critical_values[i]
    if statistic < cv:
        print('Probably exponential at the %.1f%% level' % (sl))
    else:
        print('Probably not exponential at the %.1f%% level' % (sl))

# <a id="Correlation Tests"></a>
# ## <u> Correlation Tests </u>
# 
# <a id="Covariance Analysis"></a>
# ### <u> Covariance Analysis </u>

# In[ ]:


from numpy import mean
from numpy import std
from numpy.random import randn
from numpy.random import seed
from matplotlib import pyplot

#  Random numbers drawn from a Gaussian distribution with mean = 100 and standard deviation = 20.
data1 = 20 * randn(1000) + 100
# Gaussian noise added with a mean of a 50 and a standard deviation of 10
data2 = data1 + (10 * randn(1000) + 50)
# summarize
print('data1: mean=%.3f stdv=%.3f' % (mean(data1), std(data1)))
print('data2: mean=%.3f stdv=%.3f' % (mean(data2), std(data2)))
# plot
pyplot.scatter(data1, data2)
pyplot.show()

# In[ ]:


from numpy import cov
covariance = cov(data1, data2)
covariance

# The covariance between the two variables is 389.75. We can see that it is positive, suggesting the variables change in the same direction as we expect.

# <a id="Pearson’s Correlation Coefficient"></a>
# ### <u> Pearson’s Correlation Coefficient </u>
# 
# Pearson Correlation Coefficient can be used with
#  - Continuous variables that have a linear relationship. (draw a scatterplot first to check a linear relationship).
#  
#  Pearson Correlation Coefficient is not robust to outliers
#   - Presence of outliers will always impace Pearson Correlation Coefficient value.

# In[ ]:


from scipy.stats import pearsonr

corr, _ = pearsonr(data1, data2)
corr

# The two variables are positively correlated and the correlation is 0.8. This suggests a high level of correlation.

# <a id="Spearman’s Rank Correlation"></a>
# ### <u> Spearman’s Rank Correlation </u>
# 
# Spearman’s Correlation is used when: 
# - Two variables are/may be related by a nonlinear relationship, such that the relationship is stronger or weaker across the distribution of the variables.
# - Two variables being considered may have a non-Gaussian distribution.
# 
# Spearman’s Correlation can also be used if there is a linear relationship between the variables, but may result in lower coefficient scores.
# 
# As with the Pearson correlation coefficient, the scores are between -1 and 1 for perfectly negatively correlated variables and perfectly positively correlated respectively.
# 
# Instead of calculating the coefficient using covariance and standard deviations on the samples themselves, Spearman’s Correlation is calculated from the relative rank of values on each sample.
# 
# $$\text{Spearman’s Correlation Coefficient} = \frac{Covariance(rank(x), rank(y))}{stdv(rank(x)) * stdv(rank(y))}$$ 

# In[ ]:


from scipy.stats import spearmanr

corr, _ = spearmanr(data1, data2)
print('Spearmans correlation: %.3f' % corr)

# <a id="Chi-Squared Test"></a>
# ### <u> Chi-Squared Test </u>
# 
# Chi-Square Test is used in statistics to test whether two non-negative features(boolean, category, non negative numbers) are related or independent. Given the data of two variables, we can get observed count O and expected count E. Chi-Square measures how expected count E and observed count O deviates each other.
# 
# $$\text{Chi-Square} = \sum{\frac{(O_i - E_i)^2}{E_i}} $$
# $$\text{O = Observed values, E = Expected Values}$$
# 
# In feature selection, we aim to select the features which are highly dependent on the response(y). When two features are independent, the observed count is close to the expected count, thus we will have smaller Chi-Square value. A higher Chi-Square value indicates that the feature is more dependent on the response and can be selected for model training.
# 
# <u> Example </u>:
# 
# Consider a data-set where we have to determine why customers are leaving the bank. Gender of a customer with values as Male/Female as the predictor(X) and Exited describes whether a customer is leaving the bank with values Yes/No as the response(y). In this test we will check is there any relationship between Gender and Exited.
# 
# Steps to perform the Chi-Square Test:
# - Define Hypothesis.
# - Build a Contingency table.
# - Find the expected values.
# - Calculate the Chi-Square statistic.
# - Accept or Reject the Null Hypothesis.
# 
# ### <u> Define Hypothesis </u>:
# - Null Hypothesis (H0): Two variables are independent.
# - Alternate Hypothesis (H1): Two variables are not independent.
# 
# ### <u> Contingency table </u>:
# 
# | Gender/Exited | Yes | No | Total |
# | --- | --- | --- |
# | Male | 38 | 178 | 216 |
# | Female | 44 | 140 | 184 |
# | Total | 82 | 318 | 400 |
# 
# Degrees of freedom for contingency table is given as (r-1) * (c-1) where r,c are rows and columns. Here df = (2–1) * (2–1) = 1.
# 
# In the above table we have figured out all observed values and our next steps is to find expected values, get the Chi-Square value and check for relationship.
# 
# ### <u> Find the Expected Value </u>:
# 
# Based on the null hypothesis that the two variables are independent. We can say if A, B are two independent events
# 
# $$P(A \land B) = P(A) \text{ * } P(B)$$
# 
# Let’s calculate the expected value for the first cell that is those who are Males and are Exited from the bank.
# 
# $$E_1 = N \text{ * } P$$
# $$P = P(yes) \text{ * } P(male)$$
# $$P = \frac{82}{400} \text{ * } \frac{216}{400}$$
# $$P = 0.1107$$
# $$E_1 = 400 \text{ * } 0.1107 = 44$$
# 
# We also calculated E2, E3, E4 and get the following results.
# 
# | Gender/Exited | Yes | No |
# | --- | --- |
# | Male | 44 | 172 |
# | Female | 38 | 146 |
# 
# ### <u> Calculate Chi-Square value </u>:
# 
# | Gender/Exited | O | E | $\frac{(O - E)^2}{E}$ |
# | --- | --- | --- |
# | Male, Yes | 38 | 44 | 0.8181 |
# | Male, No | 178 | 172 | 0.2093 |
# | Female, Yes | 44 | 38 | 0.9473 |
# | Female, No | 140 | 146 | 0.2465 |
# | Chi-Square Value |  |  | 2.2214 |
# 
# ### <u> Accept or Reject the Null Hypothesis </u>:
# The Chi-Square value is greater than alpha(0.05), we accept the null hypothesis.

# In[ ]:


import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import chi2

Churn_Modelling = pd.read_csv("../input/bank-customer-churn-modeling/Churn_Modelling.csv")
# Select all Categorical variables, and dependent variable
Churn_Modelling = Churn_Modelling[['Surname', 'Geography', 'Gender', 'Exited']] 
Churn_Modelling = Churn_Modelling.apply(LabelEncoder().fit_transform)
X = Churn_Modelling[['Surname', 'Geography', 'Gender']] 
y = Churn_Modelling['Exited']
chi_scores = chi2(X,y)
chi_scores

# first array represents chi square values and second array represnts p-values.

# In[ ]:


p_values = pd.Series(chi_scores[1],index = X.columns)
p_values.sort_values(ascending = False , inplace = True)
p_values.plot.bar()

# Since "Geography" has higher the p-value, it says that the variable is independent of the repsone and may not be considered for model training.

# <a id="Stationary Tests"></a>
# ## <u> Stationary Tests </u>
# <a id="Augmented Dickey-Fuller"></a>
# - ### <u> Augmented Dickey-Fuller </u>
# <a id="Kwiatkowski-Phillips-Schmidt-Shin"></a>
# - ### <u> Kwiatkowski-Phillips-Schmidt-Shin </u>

# <a id="Parametric Statistical Hypothesis Tests"></a>
# ## <u> Parametric Statistical Hypothesis Tests </u>
# <a id="Student’s t-test"></a>
# ### <u> Student’s t-test </u>
# 
# A common question about two or more datasets is whether they are same/different. Specifically, whether the simplarity/difference between their central tendency (e.g. mean or median) is statistically significant. Student’s t-test compares the means of two independent groups in order to determine if the two population means are equal. It assume that the two random variables are normally distributed.  The variances of the two samples may be assumed to be equal or unequal.
# 
# Applications:
# - compare the performance of two workers of by checking the average sales done by each of them.
# - compare the performance of a worker by comparing the average sales done by him with the standard value.

# In[ ]:


import pandas as pd
from scipy import stats

blood_pressure = pd.read_csv("../input/blood-pressure-dataset/blood_pressure.csv")
# Use "ttest_rel" when the data samples may represent two independent measures or evaluations of the same object. These data samples are repeated or dependent and are referred to as paired samples or repeated measures.
ttest,pval = stats.ttest_rel(blood_pressure['bp_before'], blood_pressure['bp_after'])
# ttest is the calculated difference of the population mean represented in units of standard error.
# The greater the magnitude of T, the greater the evidence against the null hypothesis. The closer T is to 0, the more likely there isn't a significant difference.
ttest,pval

# In the [scipy documents](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_rel.html), Null Hypothesis for "ttest_rel" is : That 2 related or repeated samples have identical average (expected) values.
# 
# As pval < 0.05, we can discard the null hypothesis.

# <a id="Analysis of Variance Test"></a>
# ### <u> Analysis of Variance Test (ANOVA) </u>
# 
# ANOVA is a statistical test that assumes that the mean across 2 or more groups are equal. If the evidence suggests that this is not the case, the null hypothesis is rejected and at least one data sample has a different distribution. It assume that the two(or more) random variables are normally distributed.
# 
# Importantly, the test can only comment on whether all samples are the same or not; it cannot quantify which samples differ or by how much.

# In[ ]:


from scipy.stats import f_oneway
data1 = [0.873, 2.817, 0.121, -0.945, -0.055, -1.436, 0.360, -1.478, -1.637, -1.869]
data2 = [1.142, -0.432, -0.938, -0.729, -0.846, -0.157, 0.500, 1.183, -1.075, -0.169]
data3 = [-0.208, 0.696, 0.928, -1.148, -0.213, 0.229, 0.137, 0.269, -0.870, -1.204]
stat, p = f_oneway(data1, data2, data3)
print('stat=%.3f, p=%.3f' % (stat, p))
if p > 0.05:
    print('Probably the same distribution')
else:
    print('Probably different distributions')

# <a id="Nonparametric Statistical Hypothesis Tests"></a>
# ## <u> Nonparametric Statistical Hypothesis Tests </u>
# 
# The null hypothesis of these tests is often the assumption that both samples were drawn from a population with the same distribution, and therefore the same population parameters, such as mean or median.
# 
# <a id="Test Dataset"></a>
# ### <u> Test Dataset </u>
# Generate two samples drawn from different distributions. We will draw the samples from Gaussian distributions for simplicity, although, as noted, the tests we review are for data samples where we do not know or assume any specific distribution.
# 
# We expect the statistical tests to discover that the samples were drawn from differing distributions.

# In[ ]:


# generate gaussian data samples
from numpy.random import seed
from numpy.random import randn
from numpy import mean
from numpy import std

# generate two sets of univariate observations
data1 = 5 * randn(100) + 50
data2 = 5 * randn(100) + 51
data3 = 5 * randn(100) + 52
# summarize
print('data1: mean=%.3f stdv=%.3f' % (mean(data1), std(data1)))
print('data2: mean=%.3f stdv=%.3f' % (mean(data2), std(data2)))
print('data3: mean=%.3f stdv=%.3f' % (mean(data3), std(data3)))

# <a id="Mann-Whitney U Test"></a>
# ### <u> Mann-Whitney U Test </u>
# 
# In Mann-Whitney U Test, the two samples are combined and rank ordered together. The strategy is to determine if the values from the two samples are randomly mixed in the rank ordering or if they are clustered at opposite ends when combined. A random rank order would mean that the two samples are not different, while a cluster of one sample values would indicate a difference between them.

# In[ ]:


from scipy.stats import mannwhitneyu

stat, p = mannwhitneyu(data1, data2)
print('Statistics=%.3f, p=%.3f' % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
    print('Same distribution (fail to reject H0)')
else:
    print('Different distribution (reject H0)')

# <a id="Wilcoxon Signed-Rank Test"></a>
# ### <u> Wilcoxon Signed-Rank Test </u>
# 
# If the the data samples are paired in some way or represent two measurements of the same technique or each sample is independent, but comes from the same population, we use Wilcoxon Signed-Rank Test. It is the equivalent of the paired Student T-test, but for ranked data instead of real valued data with a Gaussian distribution.
# 
# Examples of paired samples in machine learning might be the same algorithm evaluated on different datasets or different algorithms evaluated on exactly the same training and test data.
# 
# The samples are not independent, therefore the Mann-Whitney U test cannot be used.

# In[ ]:


from scipy.stats import wilcoxon

stat, p = wilcoxon(data1, data2)
print('Statistics=%.3f, p=%.3f' % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
    print('Same distribution (fail to reject H0)')
else:
    print('Different distribution (reject H0)')

# <a id="Kruskal-Wallis H Test"></a>
# - ### <u> Kruskal-Wallis H Test </u>
# 
# Generalization of Mann-Whitney U test.
# 
# The Kruskal-Wallis test is a nonparametric version of the one-way analysis of ANOVA.

# In[ ]:


from scipy.stats import kruskal

stat, p = kruskal(data1, data2, data3)
print('Statistics=%.3f, p=%.3f' % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
    print('Same distributions (fail to reject H0)')
else:
    print('Different distributions (reject H0)')

# <a id="Friedman Test"></a>
# - ### <u> Friedman Test </u>
# 
# Generalization of the Kruskal-Wallis H Test to more than two samples.
# 
# The Friedman test is the nonparametric version of the repeated measures analysis of variance test, or repeated measures ANOVA.

# In[ ]:


from scipy.stats import friedmanchisquare

stat, p = friedmanchisquare(data1, data2, data3)
print('Statistics=%.3f, p=%.3f' % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
    print('Same distributions (fail to reject H0)')
else:
    print('Different distributions (reject H0)')

# <a id="Multivariate Statistical Analysis"></a>
# # <u> Multivariate Statistical Analysis </u>
# 
# Multivariate statistics includes all statistical techniques for analyzing samples made of two or more variables.
# 
# <a id="Covariance and Correlation Statistical Analysis"></a>
# ## <u> Covariance and Correlation Statistical Analysis </u>
# 
# ### <u> Covariance Matrix </u>
# 
# The Covariance matrix of $X_{NP}$ is a "P * P" matrix where the covariance of any two features "P1", "P2" is calculated by the formula -
# 
# $$Cov(P1, P2 ) = \frac{\sum({P1}_i - \bar{P1}) ({P2}_i - \bar{P2})}{N}$$
# 
# For diagonal elements, $Cov(P1, P1) = Var(P1)$
# 
# ### <u> Correlation Matrix </u>
# 
# The Correlation matrix of $X_{NP}$ is also a "P * P" matrix where the correlation of any two features "P1", "P2" is calculated by the formula -
# 
# $$Corr(P1, P2 ) = \frac{Cov(P1, P2 )}{\sigma_{P1} \sigma_{P2}}$$
# 
# The correlation of an element with itself $ Corr(P1, P1) = 1$, or the highest value possible.
# 
# ### <u>Covariance and Correlation Statistical Analysis in PCA </u>:
# 
# In PCA analysis, use the covariance matrix when the variable are on similar scales and the correlation matrix when the scales of the variables differ.
# 
# We will see(R code) how Covariance and Correlation Matrix can be used to explain which features contributes to maximum variance in PCA analysis. We will also see how PCA results differ when computed with the correlation matrix and the covariance matrix respectively.

# In[ ]:


# rpy2 runs embedded R in a Python process.

# In[ ]:


conda install -c r rpy2 

# In[ ]:


%load_ext rpy2.ipython

# In[ ]:


import pandas as pd
mtcars = pd.read_csv("../input/mtcars/mtcars.csv")

# In[ ]:


%%R
head(mtcars, 2)

# #### <u>PCA with covariance matrix </u>

# In[ ]:


%%R
# We will use the prcomp() function from the ‘stats’ package.
# Setting the scale=FALSE option will use the covariance matrix to get the PCs
cars.pca = prcomp(mtcars[,-11], scale=FALSE)
str(cars.pca)

# prcomp() returns 5 key measures: sdev, rotation, center, scale and x.
# 
# - The <b>center </b> and <b> scale </b> provide the respective means and standard deviation of the variables that were used for normalization before implementing PCA.
# - <b> sdev </b> shows the standard deviation of principal components. In other words, it shows the square roots of the eigenvalues.
# - Each column of the <b>rotation matrix </b> contains the principal component loading vector. The component loading can be represented as the correlation of a particular variable on the respective PC(principal component). It can assume both positive or negative. Higher the loading value, higher is the correlation. With this information, we can easily interpret the ‘key variable’ in the PC.
# - The matrix <b> x </b>has the principal component score vectors.

# The scale measure is set as "FALSE" as specified by in the input arguments. Let us now look at the principal component loading vectors:

# In[ ]:


%%R
cars.pca$rotation

# In[ ]:


conda install -c bioconda r-ggbiplot

# To help with the interpretation, let us plot these results.

# In[ ]:


%%R

library(ggbiplot)
ggbiplot(cars.pca, labels=rownames(mtcars))

# To read this chart, one has to look at the extreme ends (top, down, left and right). The first principal component here (on the left and right) corresponds to the measure of ‘disp’ and ‘hp’. The second principal component (PC2) does not seem to have a strong measure.
# 
# We can finish this analysis with a summary of the PCA with the covariance matrix:

# In[ ]:


%%R
summary(cars.pca)

# From this table, we see that the maximum contribution to variation caused is caused by PC1 (~92.7%) and all other principal components have progressively lower contribution. In simpler terms, it means that almost 93% of the variance in the data-set can be explained using the first principal component with measures of ‘disp’ and ‘hp’.
# 
# As a conclusion, not a lot of significant insights can be driven from the Principal Component Analysis on the basis of the covariance matrix.

# #### <u> PCA with correlation matrix </u>

# In[ ]:


%%R
# Setting the scale=FALSE option will use the correlation matrix to get the PCs
cars.pca = prcomp(mtcars[,-11], scale=TRUE)
# obtain the rootation matrix
cars.pca$rotation
# obtain the biplot
ggbiplot(cars.pca, labels=rownames(mtcars))

# This plot looks more informative. It says that variables like ‘disp’, ‘cyl’, ‘hp’, ‘wt’, ‘mpg’, ‘drat’ and ‘vs’ contribute significantly to PC1 (first principal component). ‘qsec, ‘gear’ and ‘am’ have a significant contribution to PC2.
# 
# Let us try to look at the summary of this analysis.

# In[ ]:


%%R
summary(cars.pca)

# One significant change we see is the drop in the contribution of PC1 to the total variation. It has dropped from 92.7% to 63.5%. On the other hand, the contribution of PC2 has increased from 7% to 22%. Furthermore, the component loading values show that the relationship between the variables in the data-set is way more structured and distributed. Another significant difference can be observed if we look at the standard deviation values in both the results above. The values from PCA done using the correlation matrix are closer to each other and more uniform as compared to the analysis done using the covariance matrix.
# 
# This analysis with the correlation matrix definitely, uncovers some better structure in the data and relationships between variables. The above example can be used to conclude that the results significantly differ when one tries to define variable relationships using covariance and correlation. This in turn, affects the importance of the variables computed for any further analyses. Selection of predictors and independent variables is one prominent application of such exercises.

# ### <u>Correlation Matrix for to compare feature correlations </u>:

# In[ ]:


import seaborn as sns

# correlation matrix:
# method : {‘pearson’, ‘kendall’, ‘spearman’} 
corrMatrix = mtcars.corr(method ='pearson')

fig, ax = plt.subplots(figsize=(10,10)) 
sns.heatmap(corrMatrix, annot=True, ax = ax)

# Q&A
# 
# Q: What is the difference between type I vs type II error?
# 
# A: Type I error:  False Positive, when a girl is not pregnant but the doctor has stated that she is pregnant. i.e. the null hypothesis is true but is rejected. Type II error is opposite of Type I error.
