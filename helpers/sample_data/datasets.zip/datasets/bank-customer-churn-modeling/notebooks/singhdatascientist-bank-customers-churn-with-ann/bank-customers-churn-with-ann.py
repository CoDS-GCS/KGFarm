#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# In[ ]:


df = pd.read_csv('../input/bank-customer-churn-modeling/Churn_Modelling.csv')

# In[ ]:


df.head()

# #### First of all, drop customerID column as it is of no use

# In[ ]:


df1 = df.drop(['RowNumber', 'CustomerId', 'Surname'], axis=1)

# In[ ]:


df1.head()

# In[ ]:


df1.dtypes

# In[ ]:


df1.isnull().sum()

# #### One hot encoding for categorical columns

# In[ ]:


df2 = pd.get_dummies(data=df1, columns=['Geography', 'Gender'])

# In[ ]:


df2

# In[ ]:


df2_col = ['CreditScore', 'Balance', 'EstimatedSalary']

# In[ ]:


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
df2[df2_col] = scaler.fit_transform(df2[df2_col])

# In[ ]:


df2

# In[ ]:


for col in df2:
    print(f'{col}: {df2[col].unique()}')

# In[ ]:


X = df2.drop('Exited',axis='columns')
y = df2['Exited']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=5)

# In[ ]:


import tensorflow as tf
from tensorflow import keras


model = keras.Sequential([
    keras.layers.Dense(32, input_shape=(13,), activation='relu'),
    keras.layers.Dense(13, activation='relu'),
    keras.layers.Dense(1, activation='sigmoid')
])

# opt = keras.optimizers.Adam(learning_rate=0.01)

model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

model.fit(X_train, y_train, epochs=100)

# In[ ]:


model.evaluate(X_test, y_test)

# In[ ]:


yp = model.predict(X_test)
yp[:5]

# In[ ]:


y_pred = []
for element in yp:
    if element > 0.5:
        y_pred.append(1)
    else:
        y_pred.append(0)

# In[ ]:


y_pred[:10]

# In[ ]:


y_test[:10]

# In[ ]:


from sklearn.metrics import confusion_matrix , classification_report
print(classification_report(y_test,y_pred))

# In[ ]:



