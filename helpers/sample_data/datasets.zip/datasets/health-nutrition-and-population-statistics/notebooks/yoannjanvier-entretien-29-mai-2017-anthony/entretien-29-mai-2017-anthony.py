#!/usr/bin/env python
# coding: utf-8

# **To Do List:**
# 
# 1) Display the first five rows of the dataset
# 
# 2) Display the list of countries included in the dataset
# 
# 3) Filter the dataset to display only France data
# 
# 4) Eliminate the rows for France where there is no numeric value available 
# 
# 5) Display visually the adolescent fertility rate ('Adolescent fertility rate (births per 1,000 women ages 15-19)') over years for France
# 
# 6) Propose strategies to fill the missing values for the others data
# 
# 7) Same as (5) but displaying on the same plot the following countries : 'Armenia', 'France', 'Euro area', 'Zambia'

# In[ ]:


import numpy as np 
import pandas as pd 

# In[ ]:


source_file = '../input/data.csv'

# In[ ]:



