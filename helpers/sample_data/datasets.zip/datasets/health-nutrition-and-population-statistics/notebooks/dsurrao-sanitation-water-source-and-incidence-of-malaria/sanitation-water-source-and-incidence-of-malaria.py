#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[ ]:


# Sanitation, water source, and incidence of malaria in India (IND)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

stats_data = pd.read_csv("../input/data.csv")
country_data = stats_data[stats_data["Country Code"]=="IND"] \
    [stats_data["Indicator Code"].isin(["SH.STA.ACSN", "SH.STA.ACSN.RU","SH.STA.ACSN.UR", \
                                        "SH.H2O.SAFE.ZS","SH.H2O.SAFE.RU.ZS","SH.H2O.SAFE.UR.ZS","SH.STA.MALR"])]
country_data_filtered = country_data[['Indicator Code', 'Indicator Name', '1990','1991', '1992', '1993', '1994', '1995',
       '1996', '1997', '1998', '1999', '2000', '2001', '2002', '2003', '2004',
       '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013',
       '2014', '2015']]
country_data_filtered

# In[ ]:


% matplotlib inline

for i, row in enumerate(country_data_filtered.values):
    country_data_frame = pd.DataFrame({'years': country_data_filtered.axes[1].values[2:], \
                                 'percentage': row[2:]})
    country_data_frame.plot(kind='line', x='years', y='percentage', title=row[1], legend=False, figsize=(6,3))
