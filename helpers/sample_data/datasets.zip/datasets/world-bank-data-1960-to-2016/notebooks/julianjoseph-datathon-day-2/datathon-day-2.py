#!/usr/bin/env python
# coding: utf-8

# #  Agenda for the day
#  * ML lifecycle. Problem solving techniques.  
#  * Why is EDA important ?
#  * Univariate and bivariate data analysis along with different visualizations - with Case studies.
#  * Dataset cleaning strategies
#  

# 
# ![image.png](attachment:image.png)
# Image Source : https://medium.com/analytics-vidhya/machine-learning-development-life-cycle-dfe88c44222e

# A dataset along with the business problem helps us decide what approach to take.
# 
# The next step is to categorize the problem.
# * a) By Output 
# * b) By Input

# 2 types of variables (column names) - continuous & Categorical 
# * continuous - variables that have numerical data values
# * categorical - ordinal values, binary values, grades, 

# # **Categorize by output:**
# 
# 1. a number ---> regression problem. (supervised)
# 2. a class ---> classification problem. (supervised)
# 3. a set of input groups ---> it’s a clustering problem.
# ![image.png](attachment:image.png)
# 
# Briefly - Linear Regression: 
#  y = mx
# relationships between two continuous (quantitative) variables.
#  X - the independent variable. 
#  y - the dependent variable. 
# We use X to explain or predict Y.
# 
# ![fig2.1.png](attachment:fig2.1.png)
# 
# Multiple Linear Regression:
# 
# y = b1x1 + b2x2 + … + bnxn + c.
# 
# 
# Multiple regression generally explains the relationship between multiple independent or predictor variables and one dependent or criterion variable.  A dependent variable is modeled as a function of several independent variables with corresponding coefficients, along with the constant term.  Multiple regression requires two or more predictor variables, and this is why it is called multiple regression.
# 
# 
# 
# Here, bi’s (i=1,2…n) are the regression coefficients, which represent the value at which the criterion variable changes when the predictor variable changes.
# 
# Works well even with huge datasets. But it can be unstable in case features are redundant.
# 
# 
# 2-Logistic Regression
# This performs binary classification, ---> outputs are binary. 
# Its a special case of linear regression --->  output variable is categorical, where we are using a log of odds as the dependent variable. 
# Fun fact - Uses a linear combination of features, applies a nonlinear function (sigmoid) to it, ---> tiny instance of the neural network!
# 
# ![linear_vs_logistic_regression_h8voek.jpg](attachment:linear_vs_logistic_regression_h8voek.jpg)
# 
# 
# 

# # **Categorize by the input:**
# 
# ### 1. a labeled data ---> supervised learning problem.
# human supervises/guides the algorithm on what conclusions it should come up with. For this we need to know algorithm’s possible outputs beforehand. 
# ![image.png](attachment:image.png)
# 
# 

# ### 2. unlabeled data ---> to find structure ---> unsupervised learning problem. 
# 
# Apparently true artificial intelligence as a computer learns to identify patterns without a human.
# For this we have very little information about objects and try to come up with clusters by observing some similarities between groups of objects. Those that don't fit in any of the clusters ---> anomalies.
# 
# ![image.png](attachment:image.png)
# 
# #### K-means
# This is a  clustering algorithm used to automatically divide a large group into smaller groups. K number of groups. First round of clustering when compared to a second round of clustering might have different points, so we have to take the average. 
# If None of the points change groups, so you’re finished. Otherwise, try again.
# 

# # Neural Network

# ### 3. optimize a function by interacting with an environment ---> reinforcement learning problem.
# 
# For this we refer to goal-oriented algorithms, aiming to maximize along a particular dimension over many steps. eg: maximize the points won in a game over many moves. Since there is no training dataset, the reinforcement agent learns from experience and decides what to do on ths spot. 
# 
# 
# ![image.png](attachment:image.png)
# As you graduate you will understand this video better
# <!-- ![1_qVq3H2Lln3WB1lb5hBInfg.png](attachment:1_qVq3H2Lln3WB1lb5hBInfg.png)
#  -->
# https://www.youtube.com/watch?v=Lu56xVlZ40M 

# Successful companies not only capture and have access to data, but they’re also able to derive insights that drive better decisions, which result in better customer service, competitive differentiation, and higher revenue growth. 
# 
# The process of understanding the data plays a key role in the process of choosing the right algorithm for the right problem. 
# 
# Some algorithms can work with smaller sample sets while others require tons and tons of samples. Certain algorithms work with categorical data while others like to work with numerical input.

# 
# https://medium.com/@dataakkadian?source=post_page-----295d0b0c7f60--------------------------------
# 
# Once you have analyzed the data, understood the problem well enough, you create the model either from scratch or
# using a known named algorithm tuning it for your solution. 
# 
# #### Implement machine learning algorithms.
# * Set up a machine learning pipeline that compares the performance of each algorithm on the dataset using a set of carefully selected evaluation criteria.
# * Another approach is to use the same algorithm on different subgroups of datasets. 
# * The best solution for this is to do it once or have a service running that does this in intervals when new data is added.
# 
# 
# #### Questions to ask yourself when you decide on the model/algorithm to use 
# 
# - The accuracy of the model,  interpretability, complexity,  scalability of the model.
# - How long does it take to build, train, and test the model?
# - How long does it take to make predictions using the model?
# - Does the model meet the business goal?
# 
# ### Validation strategies. Will be taken in detail with examples by Swetha. 
#  So no one strategy would work for all scenarios. There could be data leakage or not. 
# * Train/test split - usually we have a 70% training and 30 % for testing our model but there could a sampling bias. 
# To avoid this there are various strategies 
# * Holdout set 
# * k-Fold Cross-Validation
# * Leave-one-out Cross-Validation
# * Leave-one-group-out Cross-Validation
# 
# There are more ways mentioned in this article
# 
# https://towardsdatascience.com/validating-your-machine-learning-model-25b4c8643fb7
# 
# 
# #### Optimize hyperparameters. 
# There are three options for optimizing hyperparameters, 
# * grid search, random search, and Bayesian optimization.
# 
# 
# #### Model deployment
# If you have answered all of the above and are satisfied (within the stipulated time given to you) - Finally deploy
# 

# # Why EDA
# 
# developed back in the 1970s by John Turkey – the same scientist who coined the word “Bit” (short for Binary Digit). 
# No hard-and-fast rules for approaching it. 
# 
# Helps in: 
# * Spotting missing and erroneous data
# * Mapping and understanding the underlying structure of your data
# * Identifying the most important variables in your dataset
# * Testing a hypothesis or checking assumptions related to a specific model
# * Establishing a parsimonious model (one that can explain your data using minimum variables)
#  

# # Univariate and BiVariate 
# 
# Univariate visualisations are essentially probability distributions of each and every field in the raw dataset – with summary statistics. 
# 
# **Univariate visualisations use**
# 
# * frequency distribution tables, 
# * bar charts, 
# * histograms, or 
# * pie charts for the graphical representation.
# 
# **Bivariate Analysis depend on the type of variable in question**
# 
# * For instance, if you’re dealing with **two continuous** variables, **a scatter plot** should be the graph of your choice. 
# * If one is categorical and the other is continuous, a **box plot** is preferred and 
# * when both the variables are categorical, a **mosaic plot** is chosen.
# 
# Multivariate visualizations help in understanding the interactions between different data-fields. It involves observation and analysis of more than one statistical outcome variable at any given time.

# 
# Thanks to [Pedro Marcelino](https://www.kaggle.com/pmarcelino), PhD whose comprehension strategies helped me add a lot of interpretation to the Data Visualisations

# In[ ]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
%matplotlib inline

# In[ ]:


house_prices = pd.read_csv('../input/house-prices-advanced-regression-techniques/train.csv')


# In[ ]:


house_prices.head(10)

# In[ ]:


house_prices.shape()

# In[ ]:


house_prices.columns

# In[ ]:


#SalePrice - the property's sale price in dollars. This is the target variable that you're trying to predict.
house_prices['SalePrice'].describe()

# In[ ]:


#bar plot 
fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
ax.bar(house_prices['Street'],house_prices['SalePrice'])
ax.set_ylabel('Price')
ax.set_xlabel('Street')

plt.show()

# In[ ]:


#histogram plot 
plt.hist(house_prices['SalePrice'],50)
plt.ylabel('Count')
plt.xlabel('Price')
plt.show()

# In[ ]:




# > how to choose the "best" number of bins is an interesting one, and there's actually a fairly vast literature on the subject. There are some commonly-used rules-of-thumb that have been proposed (e.g. the Freedman-Diaconis Rule, Sturges' Rule, Scott's Rule, the Square-root rule, etc.) each of which has its own strengths and weaknesses. https://stackoverflow.com/questions/33458566/how-to-choose-bins-in-matplotlib-histogram

# In[ ]:


 house_prices['SalePrice'][0:4]

# In[ ]:


labels = house_prices['LotShape'][0:4]#'Frogs', 'Hogs', 'Dogs', 'Logs'
sizes = house_prices['SalePrice'][0:4] #[15, 30, 45, 10]
explode = (0, 0.1, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

plt.show()

# In[ ]:


# univariate distribution of observations
sns.distplot(house_prices['SalePrice']);

# In[ ]:


#Deviate from the normal distribution.Have appreciable positive skewness.Show peakedness.
print("Skewness: %f" % house_prices['SalePrice'].skew())
print("Kurtosis: %f" % house_prices['SalePrice'].kurt())

# Skewness is a measure of symmetry, or more precisely, the lack of symmetry. A distribution, or data set, is symmetric if it looks the same to the left and right of the center point.
# 
# Kurtosis is a measure of whether the data are heavy-tailed or light-tailed relative to a normal distribution. That is, data sets with high kurtosis tend to have heavy tails, or outliers. Data sets with low kurtosis tend to have light tails, or lack of outliers. A uniform distribution would be the extreme case.
# 
# 
# https://www.itl.nist.gov/div898/handbook/eda/section3/eda35b.htm
# More details on Skewness and kurtosis
# 

# # Relationship with Numerical features

# #### Bivariate analysis
# * 2 Continuous variables ---> Scatter plot

# In[ ]:


#scatter plot grlivarea/saleprice
var = 'GrLivArea' #GrLivArea: Above grade (ground) living area square feet
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000));

# ### that's a linear relationship! Price of the property increases as the living area increases. 

# In[ ]:


#scatter plot totalbsmtsf/saleprice
var = 'TotalBsmtSF'#TotalBsmtSF: Total square feet of basement area
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000));

# ### strong linear relationship but becomes exponential 

# # Relationship with categorical features
# 
# * 1 continuous and 1 categorical box and whiskers plot
# * heatmap

# ## How to read a box and whiskers plot
# 

# ### **Definitions**
# * Median
# The median (middle quartile) marks the mid-point of the data and is shown by the line that divides the box into two parts. Half the scores are greater than or equal to this value and half are less.
# 
# * Inter-quartile range
# The middle “box” represents the middle 50% of scores for the group. The range of scores from lower to upper quartile is referred to as the inter-quartile range. The middle 50% of scores fall within the inter-quartile range.
# 
# * Upper quartile
# Seventy-five percent of the scores fall below the upper quartile. 
# * Lower quartile
# Twenty-five percent of scores fall below the lower quartile.
# 
# * Whiskers
# The upper and lower whiskers represent scores outside the middle 50%. Whiskers often (but not always) stretch over a wider range of scores than the middle quartile groups.
# 
# Example to understand how to interpret these box plots
# 
# https://www.khanacademy.org/math/statistics-probability/summarizing-quantitative-data/box-whisker-plots/a/box-plot-review
# 
# https://www.wellbeingatschool.org.nz/information-sheet/understanding-and-interpreting-box-plots

# In[ ]:


#box plot overallqual/saleprice 
# OverallQual: Overall material and finish quality examples

var = 'OverallQual'
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
f, ax = plt.subplots(figsize=(8, 6))
fig = sns.boxplot(x=var, y="SalePrice", data=data)
fig.axis(ymin=0, ymax=800000);

# In[ ]:


var = 'YearBuilt'
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
f, ax = plt.subplots(figsize=(16, 8))
fig = sns.boxplot(x=var, y="SalePrice", data=data)
fig.axis(ymin=0, ymax=800000);
plt.xticks(rotation=90);

# * GrLivArea' and 'TotalBsmtSF' seem to be linearly related with 'SalePrice'. Both relationships are positive, which means that as one variable increases, the other also increases. In the case of 'TotalBsmtSF', we can see that the slope of the linear relationship is particularly high.
# * 'OverallQual' and 'YearBuilt' also seem to be related with 'SalePrice'. The relationship seems to be stronger in the case of 'OverallQual', where the box plot shows how sales prices increase with the overall quality.
# * We just analysed four variables, but there are many other that we should analyse. The trick here seems to be the choice of the right features (feature selection) and not the definition of complex relationships between them (feature engineering).

# Since there are several variables to keep finding a relationship with our target variable, 
# lets first create a heatmap using seahorse itself.
# 

# Some practical strategies.
# 
# * Correlation matrix (heatmap style).
# * 'SalePrice' correlation matrix.
# * Scatter plots between the most correlated variables

# In[ ]:


#correlation matrix
corrmat = house_prices.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, vmax=.8, square=True);

# ### If the heatmap looks confusing to you with those colors. (color blindness is way more common than you think) lets see the numbers first! 
# 

# In[ ]:


corrmat

# ## Understanding correlation. 
# 

# ![image.png](attachment:image.png)

# # "Correlation Is Not Causation"
# * for eg: The correlation between Sunglasses and Ice Cream sales is high
# 
# Does this mean that sunglasses make people want ice cream?

# Since from the  first one heatmap look at 'TotalBsmtSF' and '1stFlrSF' variables,  & 'GarageX' variables. 
# significant the correlation is between these variables. 
# ### Its so strong ---> we could have a situation of  multicollinearity.
# (When more than two explanatory variables in a multiple regression model are highly linearly related. perfect multicollinearity the correlation between two independent variables is equal to 1 or −1)
# 
# 'SalePrice' has high correlations with 'GrLivArea', 'TotalBsmtSF', and 'OverallQual'. But there are definitely other factors. 

# In[ ]:


#saleprice correlation matrix zoomed in

k = 10 #number of variables for heatmap
cols = corrmat.nlargest(k, 'SalePrice')['SalePrice'].index
cols

# In[ ]:


cm = np.corrcoef(house_prices[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, yticklabels=cols.values, xticklabels=cols.values)
plt.show()

# * 'OverallQual', 'GrLivArea' and 'TotalBsmtSF' are strongly correlated with 'SalePrice'. Check!
# * 'GarageCars' and 'GarageArea' are also some of the most strongly correlated variables. However, the number of cars that fit into the garage is a consequence of the garage area. 'GarageCars' and 'GarageArea' are like twin brothers. You'll never be able to distinguish them! We can keep 'GarageCars' since its correlation with 'SalePrice' is higher).
# * 'TotalBsmtSF' and '1stFloor' also seem to be twins.
# * 'TotRmsAbvGrd' and 'GrLivArea', twins again.

# In[ ]:


#scatterplot
sns.set()
cols = ['SalePrice', 'OverallQual', 'GrLivArea', 'GarageCars', 'TotalBsmtSF', 'FullBath', 'YearBuilt']
sns.pairplot(house_prices[cols], size = 2.5)
plt.show();

#  'TotalBsmtSF' and 'GrLiveArea' ---> the dots drawing a linear line, which almost acts like a border. It totally makes sense that the majority of the dots stay below that line. Basement areas can be equal to the above ground living area, but it is not expected a basement area bigger than the above ground living area.
# 
#  'SalePrice' and 'YearBuilt' ---> 'dots cloud'---> a exponential function. same tendency in the upper limit of the 'dots cloud'. Also, notice how the set of dots regarding the last years tend to stay above this limit ---> prices are increasing faster now.
# 
# 

# In[ ]:


my_filepath = "../input/world-happiness/2019.csv"
my_data=pd.read_csv(my_filepath, index_col="Overall rank")
my_data.head(5)


# In[ ]:


my_data.describe()


# In[ ]:


my_data.info()


# In[ ]:


# num_bins=10
# plt.xlabel('Generosity')
# plt.ylabel('values')
# plt.hist(my_data['Generosity'], num_bins)
sns.set_style('darkgrid')
sns.distplot(my_data['Generosity'])

# In[ ]:


num_bins=10
plt.xlabel('Healthy life expectancy')
plt.ylabel('count')
plt.hist(my_data['Healthy life expectancy'], num_bins)

# In[ ]:


num_bins=10
plt.xlabel('GDP per capita')
plt.ylabel('count')
plt.hist(my_data['GDP per capita'], num_bins)

# In[ ]:


plt.figure(figsize=(20,50))
sns.barplot(x=my_data["Score"], y=my_data['Country or region'])

# In[ ]:


sns.heatmap(data=my_data.corr(), annot=True)
plt.show()

# In[ ]:


sns.regplot(x=my_data['Healthy life expectancy'], y=my_data['Social support'])

# In[ ]:


sns.regplot(x=my_data['Healthy life expectancy'], y=my_data['Freedom to make life choices'])

# ![image.png](attachment:image.png)

# # Data Cleaning 
# https://www.kaggle.com/getting-started/52652
# * Day 1: Handling missing values
# * Day 2: Data scaling and normalization
# * Day 3: Cleaning and parsing dates
# * Day 4: Character encoding errors (no more messed up text fields!)
# * Day 5: Fixing inconsistent data entry & spelling errors

# ## Missing values
# Data intuition also comes into play here -  why column has missing values - was it not recorded or does it not exist? 
# Data Scientist or not, I urge you to think about the bigger picture always, think about the process, how you reached where you are at, and why you are doing something. 
# Steps: 
# 1. See how many missing data points we have
# 2. Figure out why the data is missing
# 3. Drop missing values. Keep track of just how much data is lost.
# 4. Filling in missing values automatically aka Imputation (A Better Option)
# 

# In[ ]:


#.isnull().sum()
missing_count = my_data.isnull().sum()
missing_count

# In[ ]:


#missing data
total = house_prices.isnull().sum().sort_values(ascending=False)
percent = (house_prices.isnull().sum()/house_prices.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
missing_data.head(20)

# In[ ]:


house_prices.shape

# In[ ]:


#dealing with missing data
house_prices = house_prices.drop((missing_data[missing_data['Total'] > 1]).index,1)
house_prices = house_prices.drop(house_prices.loc[house_prices['Electrical'].isnull()].index)
house_prices.isnull().sum().max() #just checking that there's no missing data missing...

# In[ ]:


house_prices.shape

# In[ ]:


# normalize the exponential data with boxcox
normalized_data = stats.boxcox(original_data)

# plot both together to compare
fig, ax=plt.subplots(1,2)
sns.distplot(original_data, ax=ax[0])
ax[0].set_title("Original Data")
sns.distplot(normalized_data[0], ax=ax[1])
ax[1].set_title("Normalized data")

# # Dates

# In[ ]:


import datetime

# read in our data
landslides = pd.read_csv("../input/landslide-events/catalog.csv")
np.random.seed(0)
print(landslides['date'].head())
landslides['date'].dtype


# In[ ]:


# create a new column, date_parsed, with the parsed dates
landslides['date_parsed'] = pd.to_datetime(landslides['date'], format = "%m/%d/%y")
# print the first few rows
landslides['date_parsed'].head()

# In[ ]:


# try to get the day of the month from the date column
day_of_month_landslides = landslides['date'].dt.day

# We're getting this error because the dt.day() function doesn't know how to deal with a column with the dtype "object". Even though our dataframe has dates in it, because they haven't been parsed we can't interact with them in a useful way.

# In[ ]:


# get the day of the month from the date_parsed column
day_of_month_landslides = landslides['date_parsed'].dt.day
day_of_month_landslides

# ## Few Assumptions to check for
# 1. Normality - Our data should look like a normal distribution. This is important because several statistic tests rely on this (e.g. t-statistics). 
#     - check univariate normality for 'SalePrice' (which is a limited approach). 
#     - Note: univariate normality doesn't ensure multivariate normality (which is what we would like to have), but it helps. 
#     - in big samples (>200 observations) normality is not such an issue. 
#     - if we solve normality, we avoid a lot of other problems (e.g. heteroscedacity).
# 
# 2. Homoscedasticity - assumption that dependent variable(s) exhibit equal levels of variance across the range of predictor variable(s)' (Hair et al., 2013).
#    - desirable; we want the error term to be the same across all values of the independent variables.
# 
# 3. Linearity- The most common way to assess linearity is to examine scatter plots and search for linear patterns. 
#    - If patterns are not linear, it would be worthwhile to explore data transformations. 

# ## Scaling - Normalisation/Standardisation
# 
# https://towardsdatascience.com/everything-you-need-to-know-about-min-max-normalization-in-python-b79592732b79

# In[ ]:


# for min_max scaling
from mlxtend.preprocessing import minmax_scaling

original_data = np.random.exponential(size = 1000)
original_data[0:10]

# In[ ]:


# mix-max scale the data between 0 and 1
scaled_data = minmax_scaling(original_data, columns = [0])
scaled_data[0:10]

# In[ ]:



# plot both together to compare
fig, ax=plt.subplots(1,2)
sns.distplot(original_data, ax=ax[0])
ax[0].set_title("Original Data")
sns.distplot(scaled_data, ax=ax[1])
ax[1].set_title("Scaled data")

# ## Outliers
# Almost every data would have some or the other outlier that doesn't follow the patterns of the rest of the variables. Anomalies. Their detections are super important. Eugene.ai is a company that detect anomalies or outliers from any data and warns you about it. 
# 

# In[ ]:


import pandas as pd
house_prices = pd.read_csv('../input/house-prices-advanced-regression-techniques/train.csv')
#bivariate analysis saleprice/grlivarea
var = 'GrLivArea'
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000));

# In[ ]:


#deleting points
house_prices.sort_values(by = 'GrLivArea', ascending = False)[:2]
house_prices = house_prices.drop(house_prices[house_prices['Id'] == 1299].index)
house_prices = house_prices.drop(house_prices[house_prices['Id'] == 524].index)

# In[ ]:


#bivariate analysis saleprice/grlivarea
var = 'TotalBsmtSF'
data = pd.concat([house_prices['SalePrice'], house_prices[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000));

# ## Normality

# In[ ]:


#histogram and normal probability plot with SalePrice
sns.distplot(house_prices['SalePrice'], fit=norm);
fig = plt.figure()
res = stats.probplot(house_prices['SalePrice'], plot=plt)


# In[ ]:


#applying log transformation
house_prices['SalePrice'] = np.log(house_prices['SalePrice'])

# In[ ]:


#transformed histogram and normal probability plot
sns.distplot(house_prices['SalePrice'], fit=norm);
fig = plt.figure()
res = stats.probplot(house_prices['SalePrice'], plot=plt)

# In[ ]:


#histogram and normal probability plot for GrLivArea
sns.distplot(house_prices['GrLivArea'], fit=norm);
fig = plt.figure()
res = stats.probplot(house_prices['GrLivArea'], plot=plt)

# In[ ]:


#data transformation
house_prices['GrLivArea'] = np.log(house_prices['GrLivArea'])

# In[ ]:


#transformed histogram and normal probability plot
sns.distplot(house_prices['GrLivArea'], fit=norm);
fig = plt.figure()
res = stats.probplot(house_prices['GrLivArea'], plot=plt)

# In the search for writing 'homoscedasticity' right at the first attempt
# The best approach to test homoscedasticity for two metric variables is graphically. Departures from an equal dispersion are shown by such shapes as cones (small dispersion at one side of the graph, large dispersion at the opposite side) or diamonds (a large number of points at the center of the distribution).
# 
# 

# https://www.geeksforgeeks.org/heteroscedasticity-in-regression-analysis/ 
# 
# <!-- ![image.png](attachment:image.png) -->

# In[ ]:


#scatter plot
plt.scatter(house_prices['GrLivArea'], house_prices['SalePrice']);

# As you can see, the current scatter plot doesn't have a conic shape anymore. That's the power of normality! Just by ensuring normality in some variables, we solved the homoscedasticity problem.

# Practise

# In[ ]:


world_bank_Data = pd.read_csv('../input/world-bank-data-1960-to-2016')
world_bank_Data.head()
