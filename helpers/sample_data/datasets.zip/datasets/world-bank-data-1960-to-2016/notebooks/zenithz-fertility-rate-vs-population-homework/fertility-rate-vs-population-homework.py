#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Import Library ต่างๆ
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import statsmodels.api as sm

# machine learning
import sklearn.datasets as datasets
# เช็คData ที่อยู่ใน folder input
print(os.listdir("../input"))

# # Import ข้อมูล

# Shape ของข้อมูลpopulation คือ (264,61)

# In[ ]:


# อ่าน CSV files
population = pd.read_csv('../input/country_population.csv')
fertility = pd.read_csv('../input/fertility_rate.csv')
life = pd.read_csv('../input/life_expectancy.csv')


# ## **Population**

# In[ ]:


# ตัวอย่างการ Drop Colums
temp_pop = population
temp_pop.drop(columns=['Country Name','Country Code', 'Indicator Name', 'Indicator Code'],axis =1, inplace=True)

# In[ ]:


# จำนวนทั้งหมดของประชากรตชในปีนั้นๆ
pop_sum=temp_pop.sum()
pop_sum=pd.DataFrame(pop_sum).reset_index()
pop_sum.columns= ['Year','Total Population']
pop_sum


# In[ ]:


#  Stack overflow method 
#การทำ Linear Plot ของประชากรทั้งโลกในแต่ละปี
plt.figure(figsize=(30,10))
plt.plot(pop_sum['Year'], pop_sum['Total Population'])
plt.title('Global Population from 1960 to 2016')
plt.xticks(np.arange(1960,2017))

plt.show()


# **กราฟด้านบนแสดงถึงจำนวนประชากรที่เพิ่มขึ้นในแต่ละปี**

# ## ทำเหมือนกันใน Fertility
# 

# In[ ]:


#ลบ Columns ที่ไม่ต้องการ
temp_fert= fertility
temp_fert.head()
temp_fert.drop(['Country Name','Country Code','Indicator Name', 'Indicator Code'],axis =1, inplace = True)
new_fert =temp_fert.dropna()

# In[ ]:


#ดูHead ของ Fertility
# new_fert.isnull().values.any() # no empty values 
new_fert.head()

# In[ ]:


# ค่าต่างๆและค่าเฉลี่ยของFert
fert_sum = new_fert.mean()
fert_sum = pd.DataFrame(fert_sum).reset_index()
fert_sum.columns=['Year', 'Fertility']
fert_sum.describe()

# In[ ]:


# fert_sum.plot()
plt.figure(figsize=(25,10))
plt.plot(fert_sum['Year'], fert_sum['Fertility'])
plt.xticks(np.arange(1960,2017))
plt.title('Fertility from 1960 to 2016')
plt.show()


# **กราฟด้านบนแสดงถึงอัตรการเพิ่มขึ้นหรือลดลงของอัตราเจริญพันธุ์ใบแต่ละปี**
# 

# **Life Expectancy**

# In[ ]:


df_life = life
# df_life.head()
df_life.drop(['Country Name','Country Code','Indicator Name', 'Indicator Code'],axis =1, inplace = True)
new_life = df_life.dropna()
new_life.head()


# In[ ]:


# new_life.isnull().values.any()# no empty values 
life_mean =  new_life.mean()
life_mean = pd.DataFrame(life_mean).reset_index()
life_mean.columns= ['Year', 'Life expectancy']
# life_mean.plot()
life_mean.head()

# In[ ]:


plt.figure(figsize=(25,10))
plt.plot(life_mean['Year'], life_mean['Life expectancy'])
plt.xticks(np.arange(1960,2017))
plt.title('Life Expectancy from 1960 to 2016')
plt.show()


# **ข้อมูลด้านบนทำเหมือนกับสองไฟล์ CSVที่ผ่านมา**

# **ตารางข้อมูลแสดงถึงอัตราเจริญพันธุ์ของโลกในปีนั้นๆ**

# In[ ]:


fert_sum.describe()


# **ตารางข้อมูลแสดงถึงอายุเฉลี่ยของคนในปีนั้นๆ**

# In[ ]:


life_mean.describe()


# **ตารางข้อมูลแสดงถึงจำนวนประชากรของคนในปีนั้นๆ**

# In[ ]:


pop_sum.describe()

# # ข้อมูลส่วนนี้จะเป็นการรวมกันระหว่างสามข้อมูลโดยใช้Merge 

# In[ ]:


# world_data = pd.merge(pd.merge(pop_sum, life_mean, on='Year'), fert_sum, on='Year')
test_data = pd.merge(pop_sum,life_mean, on='Year')
world_data = pd.merge(test_data, fert_sum, on='Year')
world_data.columns


# # ทำการMergeทะเงหมดแล้วจะลงกำหนดScale

# In[ ]:


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
world_data[['Total Population', 'Life expectancy', 'Fertility']] = scaler.fit_transform(world_data[['Total Population', 'Life expectancy', 'Fertility']])
world_data

# # หลังจากที่ศึกษาและทดลองSyntaxจะเริ่มแก้ปัญหาของเรา ปัญหาคือ 
# ## <font color='red'>  ทำไมประชากรในโลกยังคงมากขึ้นในขณะที่การเจริญพันธุ์ลดลง?</font>

# In[ ]:


# Import CSV file
population = pd.read_csv('../input/country_population.csv')
fertility = pd.read_csv('../input/fertility_rate.csv')
life = pd.read_csv('../input/life_expectancy.csv')
    

# In[ ]:


# เช็ค Missing Values เพื่อน Clean data
population.head()
pop_year = population.drop(['Country Code','Indicator Name', 'Indicator Code'],axis=1)
pop_year= pop_year.T
# population.head()
pop_year.head()
pop_year.shape
# pop_year.isnull().values.any()

t = pop_year.isnull().apply(sum, axis=0)
t

pop_year = pop_year.fillna(pop_year.mean())        
pop_year.isnull().values.any() # The answer is true
pop_year.shape

# In[ ]:


fertility = pd.read_csv('../input/fertility_rate.csv')

fertility=fertility.drop(['Country Code','Indicator Name', 'Indicator Code'],axis=1)
fert_year = fertility

        
fert_year= fert_year.dropna()
fert_year



# In[ ]:


fert_temp = fert_year

fert_temp= fert_temp.dropna()
# fert_temp=fert_temp.drop('mean of year', axis =1)
fert_temp


# # Ignore Columns ที่ไม่เอา

# In[ ]:


country_names = pd.DataFrame(fert_temp['Country Name'])
country_names
fert_ignore =pd.DataFrame(fert_temp.iloc[:,:]) #Ignores the names of the country

fert_ignore
if 'mean of year' in fert_ignore.columns:
    fert_ignore =fert_ignore.drop('mean of year',axis =1)
fert_ignore.T
fert_mean = fert_ignore.mean(axis =0)
type(fert_mean)
fert_mean

idx= 0
fert_add = fert_ignore.T
fert_add.insert(loc=idx, column='mean of year', value=fert_mean)
fert_add.columns[0]

fert_add = fert_add.T
fert_add.iloc[1]

# ## <font color=Green>เราจะทำการแยกปี ระหว่างปี 1960 - 1999 กับ 2000 - 2016</font>

# In[ ]:


column_drop = fert_add.columns[1:41] #1960 ถึง 1999
column_interest= fert_add.columns[41:] #2000 ถึง 2016
mil_fert = fert_add.drop(column_drop,axis=1) #fertility data since 2000

mil_fert.iloc[:,1:]#.mean().mean() = 3.0017
mil_filter = mil_fert[mil_fert[column_interest]>= mil_fert.iloc[:,1:].mean().mean()]

count_try= mil_filter.drop('Country Name', axis=1).dropna()
count_try


#  ### <font color=purple> **ข้อมูลในตารางด้านบนแสดงถึง 72 ประเทศที่มีความอุมสมบูรณ์มากวว่า mean/avg 72ตารางอาจจะมากไปเราจะทำการ Limit ใหม่**</font>

# In[ ]:


# ค่า Mean เก่ามีค่าประมาณ 3.0017 เราจึงกำกับค่าใหม่ให้สูงกว่าเดิม เพื่อลดจำนวนลง
more_filter = count_try[count_try[column_interest]>=5.0]
more_filter= more_filter.dropna()
more_filter

# <font color = green>**หลังจากที่ปรับอัตราเจริญพันธุ์ป็น 5.0 แล้วทำให้จาก72 ประเทศลดลงเหลือ 15 ประเทศ ที่มีอัตราเจริญพันธุ์มากกว่า 5.0 **</font>

# In[ ]:


# ปรับเพิ่มเป็น 5.5
filter_six = more_filter[more_filter[column_interest]>=5.5]
filter_six = filter_six.dropna()
filter_six

# ## <font color =green >******หลังจากปรัรบเพิ่มเป็น5.5 ทำให้เราได้ 10 ประเทศที่มีอัตราเจริญพันธุ์มากที่สุดในโลก**</font>

# ## <font color = Purple>**หลังจากนั้นเราจะทำการใส่ชื่อประเทศเข้าไปเพื่อจำแนกประเทศ **</font>country_indices=filter_six.index.values
# country_indices
# type(country_indices)

# In[ ]:


country_indices=filter_six.index.values
country_indices
type(country_indices)

# In[ ]:


insert_names = country_names[country_names.index.isin(country_indices)]
insert_names['Country Name']


# In[ ]:


idx= 0
country_fert = filter_six
# country_fert.insert(loc=idx, column='Country Name', value=insert_names)
country_fert

# ## <font color=red>ตารางข้อมูลด้านบนแสดงชื่อประเทศ และอัตราเจริญพันธุ์ ของ10ประเทศในโลก</font> 

# In[ ]:


country_fert.plot(figsize= (10,10), title= '10 countries with highest fertility rate 2000-2016')

# ## เราจะลองเปรียบเทียบกับกราฟ อัตราเจริญพันธุ์ของโลกในเวลาเดียวกันด้วย
# 

# In[ ]:


fertility[column_interest].dropna().plot(kind='line',figsize=(10,10), title = 'World fertility 2000-2016')

# ## หลังจากที่เปรียบเทียบแล้วเราจะเห็นได้ว่า 10 ประเทศที่เราเลือกมาคือจุด Peak ของ กราฟด้านบน
# ## ต่อไปเราจะPlot graph ประชากรของ 10 ประเทศที่เราเลือก กับประชากรที่เหลือทั้งหมด
# 

# # ส่วนนี้คือประชากรทั้งหมดในโลก ระหว่างปี 2000-2016

# In[ ]:


population[column_interest].plot(figsize=(10,10), title='World population 2000-2016')

# ## ส่วนนี้คือประชากรของ 10 ประเทศที่เราเลือก

# In[ ]:


population = population = pd.read_csv('../input/country_population.csv')
population= population.drop(['Country Code','Indicator Name','Indicator Code'], axis=1)
world_16 = population['2016'].sum()

country_pop= population[column_interest].iloc[country_indices]
ten_16= country_pop['2016'].sum()
country_pop
#population of the 10 countries in 2016 was 414258372.0

idx= 0
country_pop.insert(loc=idx, column='Country Name', value=insert_names)
country_pop.plot(figsize= (10,10), title = 'population of 10 mos fertile countries')




# ## นี่คือเปอร์เซนท์ของประชากรของ 10 ประเทศที่มีการเจริญพันธุ์มากที่สุด เมื่อเทียบกับทั้งโลก

# In[ ]:


percent = np.multiply(np.divide(ten_16,world_16),100)
print('The top 10 most fertile countries in 2016, form ', percent,'%  of the world population in 2016')
# percent 

# >  ## **10 อันดับประเทศที่มีอัตราคนเกิด(ภาวะเจริญพันธุ์)มากที่สุดในโลกตั้งแต่ปี 2000 ถึง 2016**
# 
# * Angola
# * Burundi
# * Congo, Dem. Rep.
# * Mali
# * Niger
# * Nigeria
# * Somalia
# * Chad
# * Timor-Leste
# * Uganda

# # ถึงแม้ว่าโลกจะมีอัตราภาวะเจริญพันธุ์ลดลงแต่ในบางประเทศยังมีภาวะเจริญพันธุ์สูง บางประเทศอาจสูงกว่าค่าเฉลี่ยถึง 2-3 เท่า และการเกิดนั้นมีมากกว่าการตาย จึงทำให้ยังมีประชากรเพิ่มขึ้นเรื่อยๆ   

# In[ ]:


population = population.transpose()
population

# In[ ]:


X = population["Country Name"].dropna()
y = population["Aruba"].dropna()
X_train, X_test, y_train, y_test = train_test_split(X[:1459], y[:1459], test_size = 1)
model = sm.OLS(y_train, X_train).fit()
predictions = model.predict(X_test)


# # สร้าง Model โดยให้ จำนวนประชากรเป็นแกน X และ ปีเป็นแกน Y 

# In[ ]:


plt.scatter(X_test, y_test, color = "black")
plt.plot(X_test, predictions, color = "blue")
plt.title("Regression Model")
plt.xlabel("Year")
plt.ylabel('Population')
model.summary()

# # ส่วนนี้เป็นกราฟข้อมูลที่ได้จากการ Regression
