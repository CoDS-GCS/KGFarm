#!/usr/bin/env python
# coding: utf-8

# ### In this notebook I want to view the power of pandas as in visualization feild.
# 
# ### These points will be coverd:
# 
# #### - Histogram ploting
# #### - Box plot
# #### - Area plot
# #### - Bar plot
# #### - Scatter plot
# #### - Hex plot
# #### - Kde plot
# 

# ### 1- Importing data &  Libraries

# In[ ]:


import numpy as np
import pandas as pd


# In[ ]:


df1= pd.read_csv('../input/factors-affecting-campus-placement/Placement_Data_Full_Class.csv')
df1

# In[ ]:


df2= pd.read_csv('../input/bank-marketing-dataset/bank.csv')
df2

# ### 2- Visualization 
# ### - Histogram plotting :

# ##### Method 1: Same as seaborn style

# In[ ]:


df1['salary'].hist(bins=30) 

# ##### Method2 : use plot.hist

# In[ ]:


df1['salary'].plot.hist()

# ##### Method2 : use kind.

# In[ ]:


df1['salary'].plot(kind='hist')

# ### - Box plot:
# #### By selecting a specific columns and plot it together.

# In[ ]:


df_sub=df1[['ssc_p','hsc_p','degree_t','etest_p','mba_p']].copy()
df_sub.plot.box()

# ### - Area plot : as Box blpt, compare cols with each other.

# In[ ]:


df_sub=df1[['ssc_p','hsc_p','degree_t','etest_p','mba_p']].copy()
df_sub.plot.area()

# ### - Bar plot: We can also assign x, y inside .bar()

# ### - Line plot:

# In[ ]:


df1.plot.line(x='degree_t',y='degree_p')

# ### - Scatter plot: we can assign size as 's' prameter.

# In[ ]:


df1.plot.scatter(x='mba_p',y='salary',s=df1['hsc_p']*3)

# ### - Hex plot with grid size

# In[ ]:


df1.plot.hexbin(x='ssc_p',y='etest_p',gridsize=15)

# ### - KDE Density plot

# In[ ]:


df2['duration'].plot.kde()

# In[ ]:



