#!/usr/bin/env python
# coding: utf-8

# <img src="https://www.mortgagechoice.com.au/media/3411404/term-deposit.jpg" width=1200 height=400>

# # Bank Marketing DataSet - Intelligent Targeting:
# ***
# ## Marketing Introduction:
# *The process by which companies create value for customers and build strong customer relationships in order to capture value from customers in return.*
# 
# **Kotler and Armstrong (2010).**
# ***
# 
# <img src="https://media.giphy.com/media/l378c04F2fjeZ7vH2/giphy.gif">
# 
# **Marketing campaigns** are characterized by  focusing on the customer needs and their overall satisfaction. Nevertheless, there are different variables that determine whether a marketing campaign will be successful or not. There are certain variables that we need to take into consideration when making a marketing campaign. <br>
# 
# ## The 4 Ps:
# 1) Segment of the <b>Population:</b> To which segment of the population is the marketing campaign going to address and why? This aspect of the marketing campaign is extremely important since it will tell to which part of the population should most likely receive the message of the marketing campaign. <br><br>
# 2) Distribution channel to reach the customer's <b>place</b>: Implementing the most effective strategy in order to get the most out of this marketing campaign. What segment of the population should we address? Which instrument should we use to get our message out? (Ex: Telephones, Radio, TV, Social Media Etc.)<br><br>
# 3) <b> Price:</b> What is the best price to offer to potential clients? (In the case of the bank's marketing campaign this is not necessary since the main interest for the bank is for potential clients to open depost accounts in order to make the operative activities of the bank to keep on running.)<br><br>
# 4) <b> Promotional</b> Strategy: This is the way the strategy  is going to be implemented and how are potential clients going to be address. This should be the last part of the marketing campaign analysis since there has to be an indepth analysis of previous campaigns (If possible) in order to learn from previous mistakes and to determine how to make the marketing campaign much more effective.

# # Regarding this Kernel:
# I know this is a well known dataset since it comes from <b> UCI Machine Learning Repository</b>. However, I believe there are some interesting insights you could see that you could integrate to your own data analysis. All in all, Kaggle is meant to learn from others and I hope this example suits you well. <br><br>
# <b>Please feel free to use this kernel to your projects it will be my pleasure!</b><br><br>
# Also, I'm open to new ideas and things that I could improve to make this kernel even better! Open to constructie criticisms!
# Lastly, I will like to give a special thanks to **Randy Lao** and his well-known **Predicting Employee Kernelover**. His kernel gave me different ideas as to how should I approach an analysis of a dataset.<br><br>
# Also, I want to give credit to this stackoverflow post, which helped me change the name of legends from Facetgrids. <br>
# https://stackoverflow.com/questions/45201514/edit-seaborn-plot-figure-legend <br>
# Check it out if you are struggling with the same problem.
# 
# # Regarding Plotly:
# At the end of each plotly graph, you will notice that the iplot command has been commented out. The reason behind this is that currently for some reason the graphs are not displaying maybe it is a javascript issue. Nevertheless, I will be looking closely at this issue to see when it gets fixed. What I did in this case, is to add a tag from my plotly account in order to show the graph to you guys. Sorry for the inconvenience.

# # What is a Term Deposit? 
# A **Term deposit** is a deposit that a bank or a financial institurion offers with a fixed rate (often better than just opening deposit account) in which your money will be returned back at a specific maturity time. For more information with regards to Term Deposits please click on this link from Investopedia:  https://www.investopedia.com/terms/t/termdeposit.asp

# # Outline: <br>
# ***
# A. **Attribute Descriptions**<br>
# I. *[Bank client data](#bank_client_data)<br>
# II. *[Related with the last contact of the current campaign](#last_contact)<br>
# III. [Other attributes](#other_attributes) <br>
# 
# B. **Structuring the data:** <br>
# I. *[Overall Analysis of the Data](#overall_analysis)<br>
# II. *[Data Structuring and Conversions](#data_structuring) <br>
# 
# C. **Exploratory Data Analysis (EDA)**<br>
# I. *[Accepted vs Rejected Term Deposits](#accepted_rejected) <br>
# II. *[Distribution Plots](#distribution_plots) <br>
# 
# D. **Different Aspects of the Analysis: **<br>
# I. *[Months of Marketing Activty](#months_activity) <br>
# II. *[Seasonalities](#seasonality) <br>
# III. *[Number of Calls to the potential client](#number_calls) <br>
# IV. *[Age of the Potential Clients](#age_clients) <br>
# V. [Types of Occupations that leads to more term deposits suscriptions](#occupations) <br>
# 
# E. **Correlations that impacted the decision of Potential Clients.**
# I. *[Analysis of our Correlation Matrix](#analysis_correlation) <br>
# II. *[Balance Categories vs Housing Loans](#balance_housing)<br>
# III. [Negative Relationship between H.Loans and Term Deposits](#negative_relationship) <br>
# 
# F. ** Classification Model **<br>
# I. [Introduction](#classification_model)<br> 
# II. [Stratified Sampling](#stratified)<br>
# III. [Classification Models](#models)<br>
# IV. [Confusion Matrix](#confusion)<br>
# V. [Precision and Recall Curve](#precision_recall)<br>
# VI. [Feature Importances Decision Tree C.](#decision) <br>
# 
# G. ** Next Campaign Strategy**<br>
# I. [Actions the Bank should Consider](#bank_actions)<br>
# 
# # A. Attributes Description: <br>
# 
# Input variables:<br>
# # Ai. bank client data:<br>
# <a id="bank_client_data"></a>
# 1 - **age:** (numeric)<br>
# 2 - **job:** type of job (categorical: 'admin.','blue-collar','entrepreneur','housemaid','management','retired','self-employed','services','student','technician','unemployed','unknown')<br>
# 3 - **marital:** marital status (categorical: 'divorced','married','single','unknown'; note: 'divorced' means divorced or widowed)<br>
# 4 - **education:** (categorical: primary, secondary, tertiary and unknown)<br>
# 5 - **default:** has credit in default? (categorical: 'no','yes','unknown')<br>
# 6 - **housing:** has housing loan? (categorical: 'no','yes','unknown')<br>
# 7 - **loan:** has personal loan? (categorical: 'no','yes','unknown')<br>
# 8 - **balance:** Balance of the individual.
# # Aii. Related with the last contact of the current campaign:
# <a id="last_contact"></a>
# 8 - **contact:** contact communication type (categorical: 'cellular','telephone') <br>
# 9 - **month:** last contact month of year (categorical: 'jan', 'feb', 'mar', ..., 'nov', 'dec')<br>
# 10 - **day:** last contact day of the week (categorical: 'mon','tue','wed','thu','fri')<br>
# 11 - **duration:** last contact duration, in seconds (numeric). Important note: this attribute highly affects the output target (e.g., if duration=0 then y='no'). Yet, the duration is not known before a call is performed. Also, after the end of the call y is obviously known. Thus, this input should only be included for benchmark purposes and should be discarded if the intention is to have a realistic predictive model.<br>
# # Aiii. other attributes:<br>
# <a id="other_attributes"></a>
# 12 - **campaign:** number of contacts performed during this campaign and for this client (numeric, includes last contact)<br>
# 13 - **pdays:** number of days that passed by after the client was last contacted from a previous campaign (numeric; 999 means client was not previously contacted)<br>
# 14 - **previous:** number of contacts performed before this campaign and for this client (numeric)<br>
# 15 - **poutcome:** outcome of the previous marketing campaign (categorical: 'failure','nonexistent','success')<br>
# 
# Output variable (desired target):<br>
# 21 - **y** - has the client subscribed a term deposit? (binary: 'yes','no')

# In[ ]:


import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import style
import os
pd.options.mode.chained_assignment = None

import plotly.plotly as py
import plotly.graph_objs as go
from plotly import tools
from plotly.offline import iplot, init_notebook_mode
init_notebook_mode()
sns.set_style("white")


def saving_figure_path(fig_name, tight_layout=True):
    path = os.path.join("Desktop/My_Projects",fig_name + ".png")
    print("Wait until we save the image", fig_name)
    if tight_layout:
        plt.tight_layout()
    plt.savefig(path, format="png", dpi=300)

MAIN_PATH = '../input/'
df = pd.read_csv(MAIN_PATH +'bank.csv')
term_deposits = df.copy()
# Have a grasp of how our data looks.
df.head()

# In[ ]:


%%javascript
IPython.OutputArea.prototype._should_scroll = function(lines) {
    return false;
}

# # B. Structuring the Data:
# <img src="https://media.giphy.com/media/yiHz2qxBP45tS/giphy.gif">
# ##  Bi. Overall Analysis:
# <a id="overall_analysis"></a>
# ## Summary:
# ***
# <ul>
# <li type="square"> <b>Mean Age</b> is aproximately 41 years old. (Minimum: 18 years old and Maximum: 95 years old.)</li><br>
# <li type="square"> The <b>mean balance</b> is 1,528. However, the Standard Deviation (std) is a high number so we can understand through this that the balance is heavily distributed across the dataset.</li><br>
# <li type="square">As the data information said it will be better to drop the duration column since duration is highly correlated in whether a potential client will buy a term deposit. Also, <b>duration is obtained after the call is made to the potential client</b> so if the target client has never received calls this feature is not that useful. The reason why duration is highly correlated with opening a term deposit  is because the more the bank talks to a target client the higher the probability the target client will open a term deposit since a higher duration means a higher interest (commitment) from the potential client. </li><br>
# </ul>
# 
# **Note: There are not that much insights we can gain from the descriptive dataset since most of our descriptive data is located not in the "numeric" columns but in the "categorical columns".**
# 

# In[ ]:


df.dtypes

# In[ ]:


df.describe()

# Fortunately, there are no <b>missing values</b>. If there were missing values we will have to fill them with the median, mean or mode. I tend to use the median but in this scenario there is no need to fill any missing values.

# In[ ]:


# No missing values.
df.info()

# In[ ]:


# Let's see how the numeric data is distributed.
import matplotlib.pyplot as plt

df.hist(bins=10, figsize=(14,10), color='#E14906')
plt.show()

# ## Bii. Data Structuring and Integer Conversions:
# <a id="data_structuring"></a>
# ***
# <img src="https://media.giphy.com/media/drYDHLKzpjgli/giphy.gif">
# ## Instructions:
# In this section we will convert into <b> integer </b> (For plotting reasons) columns that we think are vital to determine patterns in our next section of Exploratory Data Analysis (EVA). Here we are basically making certain modifications in our main dataset in order to be able to explore our data.

# In[ ]:


# Move the deposit column to the first column.
dep = df['deposit']
#Drop the deposit column
df.drop(labels=['deposit'], axis=1,inplace = True)
df.insert(0, 'deposit', dep)
df.head()


# In[ ]:


# There are more nos than yes. 
df["deposit"].value_counts()
#df.head()

# In[ ]:


# Convert the columns that contain a Yes or No. (Binary Columns)
def convert_to_int(df, new_column, target_column):
    df[new_column] = df[target_column].apply(lambda x: 0 if x == 'no' else 1)
    return df[new_column].value_counts()

# In[ ]:


convert_to_int(df, "deposit_int", "deposit") #Create a deposit int
convert_to_int(df, "housing_int", "housing") # Create housingint column
convert_to_int(df, "loan_int", "loan") #Create a loan_int column
convert_to_int(df, "default_int", "default") #Create a default_int column

# In[ ]:


# Drop the binary columns and leave the same column in the form of integers 0 = No and 1 = Yes
df.drop(['housing', 'loan', 'default'], axis=1, inplace=True)

# In[ ]:


df.head()

# In[ ]:


# We have the amount of targeted potential clients in each of the different months of the year.
# The cross_month var. simply states the (%) of how many p.clients accepted or refused a suscription to a term deposit.
print(df['month'].value_counts())
cross_month = pd.crosstab(df['month'], df['deposit']).apply(lambda x: x/x.sum() * 100)
cross_month

# In[ ]:


# Let's create a date column that will be interesting.
# We will assume the year is 2017
df['year'] = 2017
lst = [df]

# Create a column with the numeric values of the months.
for column in lst:
    column.loc[column["month"] == "jan", "month_int"] = 1
    column.loc[column["month"] == "feb", "month_int"] = 2
    column.loc[column["month"] == "mar", "month_int"] = 3
    column.loc[column["month"] == "apr", "month_int"] = 4
    column.loc[column["month"] == "may", "month_int"] = 5
    column.loc[column["month"] == "jun", "month_int"] = 6
    column.loc[column["month"] == "jul", "month_int"] = 7
    column.loc[column["month"] == "aug", "month_int"] = 8
    column.loc[column["month"] == "sep", "month_int"] = 9
    column.loc[column["month"] == "oct", "month_int"] = 10
    column.loc[column["month"] == "nov", "month_int"] = 11
    column.loc[column["month"] == "dec", "month_int"] = 12

# Change datatype from int32 to int64
df["month_int"] = df["month_int"].astype(np.int64)
df.head()

# In[ ]:


df.drop(['day','year', 'deposit'], axis=1, inplace=True)
# Rename deposit_int column for deposit and then move it to the first.

# In[ ]:


df = df.rename(columns={"deposit_int": "deposit"})

# In[ ]:


first = df['deposit']
df.drop(labels=['deposit'], axis=1,inplace = True)
# insert (loc, column, values) --> loc is the same as position in the column.
df.insert(0, 'deposit', first)
df["deposit"].value_counts()

# In[ ]:


# Convert duration to minutes of conversation.
decimal_points = 2
df['duration'] = df['duration'] / 60
df['duration'] = df['duration'].apply(lambda x: round(x, decimal_points))
df.head()

# # C. Exploratory Data Analysis (EVA)
# ***
# <img src="https://media.giphy.com/media/qTDdlvS5z2aT6/giphy.gif">

# ## Ci. Accepted vs Rejected Term Deposits:
# <a id="accepted_rejected"></a>
# ***
# ## Questions to Determine:
# <ul>
# <li type='square'> What <b>percentage(%)</b> of potential clients accepted to suscribe to term deposits vs refused to suscribe term deposits. </li>
# <li type='square'> Is there a huge difference between clients that <b>suscribed term deposits vs refused deposits?</b></li>
# </ul>
# 
# ## Summary:
# <ul>
# <li type='square'> <b>52.6% refused to suscribe to term deposits</b> while <b>47.4% accepted to suscribe term deposits.</b> Our labels are sort of equally distributed. </li>
# </ul>
# 
# ## What Next?
# <ul>
# <li type='square'> We should ask ourselves the following <b>question:</b> Is it possible to detect patterns that could tell us a better story about what factors influence potential clients to either <b>accept or refuse to buy term deposits?</b></li>
# <li type='square'> The next step of the analysis will focus on <b>three pillars: month, age, job status </b></li>
# </ul>

# In[ ]:


f,ax=plt.subplots(1,2,figsize=(18,8))
colors=["#F08080", "#00FA9A"]
labels = 'Refused a T.D. Suscription', 'Accepted a T.D. Suscription'
df['deposit'].value_counts().plot.pie(explode=[0,0.1],autopct='%1.1f%%',ax=ax[0],shadow=True, colors=colors, labels=labels,fontsize=14)
ax[0].set_title('Term Deposits', fontsize=20)
ax[0].set_ylabel('% of Total Potential Clients', fontsize=14)
sns.countplot('deposit',data=df,ax=ax[1], palette=colors)
ax[1].set_title('Term Deposits', fontsize=20)
ax[1].set_xticklabels(['Refused', 'Accepted'], fontsize=14)
plt.show()

# ## Cii. Distribution Plots (Months-Age-Type of Job):
# <a id="distribution_plots"></a>
# ***
# <img src="https://media.giphy.com/media/xTiTnsjKXiCp0uMnsY/giphy.gif">
# ## Questions to Determine:
# <h3>Months </h3>
# <ul>
# <li type='square'> What was the month were the marketing department had the highest amount of offers to potential clients?</li>
# <li type='square'> What were the months with the lowest level of offers made from the marketing department?</li>
# <li type='square'> Which months had the highest positive ratio [(Accepted - Refused)/ Total Number of Offers]</li>
# </ul>
# 
# <h3> Age Categories </h3> 
# <ul>
# <li type='square'> From the age categories, which were the age categories that receive the most and least offers? </li>
# <li type='square'> Should we change our strategy? (For instance, should we create a marketing campaign that focuses in the elder or younger segment of the population? </li>
# </ul>
# 
# <h3> Job Status </h3>
# <ul>
# <li type='square'> Is there a specific job status that had a significantly higher amount of suscribed term deposits. </li>
# <li type='square'> Note: Job status is highly correlated with age categories. (For instance, students are most likely to be individuals from our youngest age category. </li>
# </ul>
# 
# <h3> Marketing Campaigns </h3>
# <ul> 
# <li type='square'> Which Marketing Campaigns were the most successful? </li>
# <li type='square'> What was the probability that potential clients were buying a term deposit  per each of the campaigns? </li>
# <li type='square'> What charasteristics made the campaigns that were effective successful? </li>
# </ul>

# In[ ]:


import seaborn as sns

f, axes = plt.subplots(ncols=3, figsize=(15, 6))

# Graph Employee Satisfaction
sns.distplot(df['month_int'], kde=False, color="#ff3300", ax=axes[0]).set_title('Months of Marketing Activity Distribution')
axes[0].set_ylabel('Potential Clients Count')
axes[0].set_xlabel('Months')

# Graph Employee Evaluation
sns.distplot(df['age'], kde=False, color="#3366ff", ax=axes[1]).set_title('Age of Potentical Clients Distribution')
axes[1].set_ylabel('Potential Clients Count')

# Campaigns
sns.distplot(df['campaign'], kde=False, color="#546E7A", ax=axes[2]).set_title('Calls Received in the Marketing Campaign')
axes[2].set_ylabel('Potential Clients Count')

plt.show()

# # D. Different Aspects of the Analysis:
# ## Di. Months of Marketing Activity:
# <a id="months_activity"></a>
# ***
# 
# <img src="https://media.giphy.com/media/rM0wxzvwsv5g4/giphy.gif" width=800 height=400> <br><br>
# 
# ## Why Analyze Marketing Activity?
# The main reason why we are analyzing marketing activity is to see if there is any **pattern during the months were people tended to suscribe more term deposits.** There could be **external factors** that could influence the individual to suscribe to a term deposit at a specific month. For instance, by looking at the Months distribution plot above, we can see that the months of highest marketing activity in order to attract term deposits is May. However, there are questions we should ask ourselves in order to decipher patterns as to when is the right time for the bank to increase the marketing activity to potential clients. 
# 
# ## Summary:
# ***
# <ul>
# <li type="square"> The month of <b>May</b> was the month of highest marketing activity (25.3%), while <b>December</b> was the month of lowest marketing activity (0.985%). </li>
# <li type="square"> There is a wide gap during the month of May between rejected and accepted term deposit suscriptions. (Check the Distribution Plot)</li>
# <li type="square"> May was the month with the highest level of activity however, it had the lowest ratio (negative) meaning there were <b>more rejected requests</b> for term deposits suscriptions than accepted requests. </li>
# <li type="square"> <b>March, September, October and December had the highest ratios</b> nevertheless, the marketing activity (requested offers from the marketing department) was much lower.</li>
# </ul>

# In[ ]:



months_example = pd.crosstab(index=df['deposit'],
                            columns=df['month_int'],
                            margins=True)

# Gives the percent of suscribed term deposits
(months_example/months_example.loc['All']) * 100

# Gives the amount of suscribed vs non-suscribed term deposits accounts per month.
months_example
# We need to take the values into a list format in order to fit it to the plotly graphs.
nodeposit = pd.DataFrame(months_example.iloc[0])
deposit = pd.DataFrame(months_example.iloc[1])
# Total is the total number of Potential clients contacted.
total = pd.DataFrame(months_example.iloc[2])
dep = deposit.values.tolist()
nodep = nodeposit.values.tolist()
tot = total.values.tolist()
# We use [:12] in order to skip the last row which is the "All" row.
nodep = nodep[:12]
dep = dep[:12]
tot = tot[:12]

# In[ ]:


from plotly.offline import download_plotlyjs, init_notebook_mode, iplot
from plotly.graph_objs import *
init_notebook_mode(connected=True)

labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
values = tot
colors = ['#FEBFB3', '#E1396C', '#96D38C', '#D0F9B1', '#0099ff', '#ff944d', '#ebebe0', '#cc80ff', '#ff80bf',
         '#ffff66', '#99ffbb' '#b3e6ff']

trace = Pie(labels=labels, values=values,
               hoverinfo='label+percent', textinfo='value', 
               textfont=dict(size=16),
               marker=dict(colors=colors, 
                           line=dict(color='#000000', width=2)))

data = [trace]
layout = Layout(
    title= "# of Potential Clients Targeted per Month"
)
figure = dict(data=data, layout=layout)
# iplot(figure)

# <iframe width="800" height="600" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/572.embed"></iframe>

# In[ ]:


fig = plt.figure(figsize=(15,8),)
ax=sns.kdeplot(df.loc[(df['deposit'] == 0),'month_int'] , color='#F08080',shade=True,label='Refused a T.D Suscription')
ax=sns.kdeplot(df.loc[(df['deposit'] == 1),'month_int'] , color='#00FA9A',shade=True, label='Accepted a T.D Suscription')
ax.set(xlabel='Months of the Year', ylabel='Frequency')
plt.title('Frequency of Distribution of Deposits by Month - Finding Useful Patterns')

# In[ ]:


cross_months = pd.crosstab(df['deposit'], df['month_int'])
print(cross_months)
nodeposit_rate = pd.DataFrame(cross_months.iloc[0])
deposit_rate = pd.DataFrame(cross_months.iloc[1])
nodeposit_rate = nodeposit_rate.values.tolist()
deposit_rate = deposit_rate.values.tolist()
print(deposit_rate[0])

# In[ ]:


import plotly.plotly as py
from plotly.graph_objs import *

trace1 = {"x": nodep, 
          "y": ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], 
          "marker": {"color": "#B40404", "size": 12}, 
          "mode": "markers", 
          "name": "Refused a T.D. Suscription", 
          "type": "scatter"
}

trace2 = {"x": dep, 
          "y": ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], 
          "marker": {"color": "#0080FF", "size": 12}, 
          "mode": "markers", 
          "name": "Accepted a T.D Suscription", 
          "type": "scatter", 
}

data = [trace1, trace2]
layout = {"title": "Marketing Campaign Performance in the Year", 
          "xaxis": {"title": "# of Accounts", }, 
          "yaxis": {"title": "Month of the Year"}}

fig = go.Figure(data=data, layout=layout)
# iplot(fig)

# <iframe width="800" height="600" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/574.embed"></iframe>

# In[ ]:


# deposit_rate - nodeposit_rate
deposit_rate = np.array(deposit_rate)
nodeposit_rate = np.array(nodeposit_rate)
difference = deposit_rate - nodeposit_rate
difference

difference_quantity = np.column_stack((tot, difference))
difference_quantity

effectiveness_ratio = np.divide(difference, tot) * 100
effectiveness_ratio = np.around(effectiveness_ratio, 2)
effectiveness_ratio = pd.DataFrame(effectiveness_ratio)
effectiveness_ratio = effectiveness_ratio.values.tolist()

# The most effective months to operate are March, September, October, December 
# (months that people are more likely to open bank accounts.)

# In[ ]:


import plotly.plotly as py
import plotly.graph_objs as go

# Add data
month = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
         'August', 'September', 'October', 'November', 'December']

ratio = effectiveness_ratio

line = go.Scatter(
    x = month,
    y = ratio,
    text = '(%)',
    fill = 'tonexty',
    mode = 'lines',
    name='Effectiveness Ratio',
    line = dict(
        color = ('#ff3300'),
        width= 4,
        dash = 'dot',
    
    )

)

data = [line]

layout = dict(title='Effectiveness per Month',
             xaxis=dict(title='Month'),
              yaxis=dict(title='Effectiveness ratio')
             )

fig = dict(data=data, layout=layout)
# iplot(fig)

# <iframe width="800" height="600" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/576.embed"></iframe>

# # Dii. Seasonality:
# <a id="seasonality"></a>
# ***
# <img src="https://media.giphy.com/media/7wqLOqgtjjWO4/giphy.gif">
# ## Marketing Activity in each of the Seasons:
# In this section, we will just visualize how was the marketing activity during each of the seasons and how effective were the efforts of making people suscribing term deposits. Nevertheless, this section is **not that different from the previous one** since the only thing we are doing is creating four types of seasons(spring, summer, fall and winter). Then we will just visualize the level of activity and its effectiveness per seasonality (This should not be that different from the monthly analysis however, it should be simpler to grasp during which season should the bank focus its marketing activity.)
# 
# ## Summary:
# ***
# <ul>
# <li type="square"> Surprisingly individuals opted to suscribe more term deposits accounts during the season of <b> fall</b> and <b>winter</b>. </li>
# <li type="square"> The Marketing team of the bank looks like they have focused their efforts to make people suscribe term deposits accounts during the seasons of <b> spring</b> and <b>summer.</b> </li>
# </ul>

# In[ ]:


# Create the Season column.
df['season'] = np.nan
lst=[df]
# The conditions for determining each of the seasons.
for column in lst:
    column.loc[(column["month_int"] >= 3) & (column["month_int"] <= 5), 'season'] = 'spring'
    column.loc[(column["month_int"] >= 6) & (column["month_int"] <= 8), 'season'] = 'summer'
    column.loc[(column["month_int"] >= 9) & (column["month_int"] <= 11), 'season'] = 'fall'
    column.loc[column["month_int"] <= 2, 'season'] = 'winter'
    column.loc[column["month_int"] == 12, 'season'] = 'winter'
    
df['season'].value_counts()


# In[ ]:


fig = plt.figure(figsize=(15,4),)

colors = ['#F08080', '#00FA9A']

ax = sns.countplot(y='season', data=df,
           hue='deposit',
           palette = colors
          ) 

plt.title("Deposits by Season", fontsize=16)
plt.ylabel("Seasons", fontsize=12)
plt.xlabel("Level of Marketing Activity", fontsize=12)
legend_name = plt.legend()
legend_name.get_texts()[0].set_text('Refused a T.D Suscription')
legend_name.get_texts()[1].set_text('Accepted a T.D Suscription')

plt.show()

# In[ ]:


#Check to see if the Season column was created.
df.head()

# ## Diii. Number of Calls in this Campaign:<br>
# <a id="number_calls"></a>
# ## Campaign Calls:
# This are the number of calls made to a potential clients within the same marketing campaign. Obviously, the **more the calls we make to a potential client in a shorter period of time, the more irritated the potential client will be** and thus, a higher level of probability for the potential client to refuse suscribing a term deposit.
# 
# ## Summary:
# ***
# <ul>
# <li type="square"> The more <b> the calls </b> to potential clients within the same marketing campaign, the more likely potential clients will refuse to open term deposits with the bank. </li>
# <li type="square"> When a potential client was called more than <b>five times</b> the likelihood that he or she will accept in suscribing to a term deposit diminishes. </li>
# <li type="square"> After the <b>third call</b> the probability that a potential client will <b> refuse to suscribe a term deposit </b> increases drastically (by approx. 5%). </li>
# </ul>

# In[ ]:


colors = ['#DD4040', '#58AD4B', '#0096AA', '#9B00AA']


g = sns.lmplot(x='duration', y='campaign', data=df,
           fit_reg=False, # No regression line
           hue='deposit',
        palette = colors,
        scatter_kws={'alpha':0.6}
          ) 

g.fig.set_size_inches(12,8)
# title
new_title = 'Status of Term Deposits'
g._legend.set_title(new_title)
# replace labels
new_labels = ['Refused a T.D Suscription', 'Accepted a T.D Suscription']
for t, l in zip(g._legend.texts, new_labels): t.set_text(l)

plt.axis([0,66,0,65])
plt.axhline(y=5, linewidth=3, color="#424242", linestyle='--')
plt.annotate('After 5 Calls potential clients \n tend to refuse \n unless duration is high!', xy=(33, 5), xytext=(33,13),
            arrowprops=dict(facecolor='#190707', shrink=0.05))
plt.xlabel('Duration of the Calls (Minutes)', fontsize=14)
plt.ylabel('Campaign Calls', fontsize=14)

plt.show()

# In[ ]:


# Based from the graphs above we know that the first campaigns were the most successfull.
# Can we determine why they were successfull?
# Let's create a Ordinal column which somehow tells after when the potential client was contacted again. Pdays.
df.head()
success_rate = pd.crosstab(df['deposit'], df['campaign']).apply(lambda x: x/x.sum() * 100)
print(success_rate) #Notice rejection for offers increases after three calls that should be the threshold for the marketing team
#Nevetheless, this makes 90% of our potential clients so only 10% is likely to reject, we still save time and effort.
onecall_nod = success_rate.at[0,1]
onecall_d = success_rate.at[1,1]
twocalls_nod = success_rate.at[0,2]
twocalls_d = success_rate.at[1,2]
threecalls_nod = success_rate.at[0,3]
threecalls_d = success_rate.at[1,3]
fourcalls_nod = success_rate.at[0,4]
fourcalls_d = success_rate.at[1,4]
fivecalls_nod = success_rate.at[0,5]
fivecalls_d = success_rate.at[1,5]

per_deposit = df['deposit'].value_counts()/11162 * 100
accepted = per_deposit[0]
refused = per_deposit[1]
# Round all variables
onecall_nod =  round(onecall_nod, 2)
onecall_d = round(onecall_d, 2)
twocalls_nod = round(twocalls_nod,2)
twocalls_d = round(twocalls_d, 2)
threecalls_nod = round(threecalls_nod, 2)
threecalls_d = round(threecalls_d, 2)
fourcalls_nod = round(fourcalls_nod, 2)
fourcalls_d = round(fourcalls_d, 2)
fivecalls_nod = round(fivecalls_nod, 2)
fivecalls_d = round(fivecalls_d, 2)
accepted = round(accepted, 2)
refused = round(refused, 2)

# In[ ]:


import plotly.plotly as py
import plotly.graph_objs as go
import plotly.figure_factory as FF

# Add table data
table_data = [['Number of <br> Calls', 'Refused T.D', 'Accepted T.D'],
              ['One Call', onecall_nod , onecall_d],
              ['Two Calls', twocalls_nod , twocalls_d],
              ['Three Calls', threecalls_nod, threecalls_d],
              ['Four Calls', fourcalls_nod, fourcalls_d],
              ['Five Calls', fivecalls_nod, fivecalls_d],
              ['Overall Performance', refused, accepted]]
# Initialize a figure with FF.create_table(table_data)
figure = FF.create_table(table_data, height_constant=60)

# Add graph data
calls = ['One Call', 'Two Calls', 'Three Calls', 'Four Calls', 'Five Calls', 'Overall Performance']
Ref = [onecall_nod, twocalls_nod, threecalls_nod, fourcalls_nod, fivecalls_nod, refused]
Acc = [onecall_d, twocalls_d, threecalls_d, fourcalls_d, fivecalls_d, accepted]
# Make traces for graph
trace1 = go.Bar(x=calls, y=Ref, xaxis='x2', yaxis='y2',
                marker=dict(color=['#E74C3C', '#E74C3C',
                                  '#E74C3C', '#E74C3C',
                                   '#E74C3C', '#FA5050']),
                name='Refused T.D. Suscriptions',
               text='%')
trace2 = go.Bar(x=calls, y=Acc, xaxis='x2', yaxis='y2',
                marker=dict(color=['#229954','#229954',
                                  '#229954', '#229954',
                                   '#229954', '#05FA6C']),
                name='Accepted T.D. Sucriptions',
               text='%')

trace3 = go.Scatter(x=calls, y=Ref, xaxis='x2', yaxis='y2',
                   marker=dict(color=['#FC0000']),
                   name='Incremental Refuse Rate',
                   text='%')

# Add trace data to figure
figure['data'].extend(go.Data([trace1, trace2, trace3]))

# Edit layout for subplots
figure.layout.yaxis.update({'domain': [0, .45]})
figure.layout.yaxis2.update({'domain': [.6, 1]})
# The graph's yaxis2 MUST BE anchored to the graph's xaxis2 and vice versa
figure.layout.yaxis2.update({'anchor': 'x2'})
figure.layout.xaxis2.update({'anchor': 'y2'})
figure.layout.yaxis2.update({'title': 'Performance'})
# Update the margins to add a title and see graph x-labels. 
figure.layout.margin.update({'t':75, 'l':50})
figure.layout.update({'title': 'Number of calls to a particular client'})
# Update the height because adding a graph vertically will interact with
# the plot height calculated for the table
figure.layout.update({'height':800})

# Plot!
# iplot(figure)

# <iframe width="800" height="800" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/578.embed"></iframe>

# ## Div. Age of Potential Clients:
# <a id="age_clients"></a>
# ***
# <img src="https://media.giphy.com/media/qAuqPAddvy9uo/giphy.gif">
# 
# ## Age Categories:
# **Note: We will create categories for the range of different type of ages:** <br>
# <ul>
# <li type='square'> <b>20:</b> This category which will be an int for plotting purposes will include all the ages ranging from 18-29.</li>
# <li type='square'> <b>30:</b> This category will include all the ages ranging from 30-39. </li>
# <li type='square'> <b>40:</b> This category will include all the ages ranging from 40-49. </li>
# <li type='square'> <b>50:</b> This category will include all the ages ranging from 50-59. </li>
# <li type='square'> <b>60:</b> This category will include all the ages ranging from 60-95. (95 is our maximum age.)</li>
# </ul>
# 
# ## Summary:
# ***
# <ul>
# <li type="square"> Most of the potential clients the bank targeted have <b> 30-35 years old. </b> </li>
# <li type="square"><b>20s and younger:</b> Around 60% of potentical clients in this category suscribed to term deposit suscriptions.</li>
# <li type="square"><b>30s - 50s:</b> Around 40% of the potential clients in this category suscribed to term deposits accounts.</li>
# <li type="square"> <b>60s and older:</b> Around 76% suscribed term deposits! </li>
# <li type="square"> The <b>youngest</b> and <b>eldest</b> population segments were the most likely to open a term deposit account. </li>
# </ul>

# In[ ]:


fig = plt.figure(figsize=(15,4),)
ax=sns.kdeplot(df.loc[(df['deposit'] == 0),'age'] , color='#F08080',shade=True,label='Refused T.D. Suscriptions')
ax=sns.kdeplot(df.loc[(df['deposit'] == 1),'age'] , color='#00FA9A',shade=True, label='Accepted T.D. Suscriptions')
ax.set(xlabel='Age of Individuals', ylabel='Frequency')
plt.title('Frequency of Distribution of Deposits by Age - Finding Useful Patterns')

# In[ ]:


# This is to create each of the categories.
lst = [df]
for column in lst:
    column.loc[column["age"] < 30,  "age_category"] = 20
    column.loc[(column["age"] >= 30) & (column["age"] <= 39), "age_category"] = 30
    column.loc[(column["age"] >= 40) & (column["age"] <= 49), "age_category"] = 40
    column.loc[(column["age"] >= 50) & (column["age"] <= 59), "age_category"] = 50
    column.loc[column["age"] >= 60, "age_category"] = 60
 
df['age_category'] = df['age_category'].astype(np.int64)
df.dtypes

# In[ ]:


# How likely was each age category to suscribe to a term deposit.
cross_age_category = pd.crosstab(df['deposit'], df['age_category']).apply(lambda x: x/x.sum() * 100)
cross_age_category

# In[ ]:


# Number of potential clients in each age category.
df["age_category"].value_counts()

# In[ ]:


import seaborn as sns
sns.set(style="white")
fig, ax = plt.subplots(figsize=(12,8))
sns.countplot(x="age_category", data=df, palette="Set2")
ax.set_title("Different Age Categories", fontsize=20)
ax.set_xlabel("Age Categories")
plt.show()

# In[ ]:


# There was a positive ratio of Suscribing Term Deposits  of people in their 20s (or younger) and 60s (or older)
sns.set(style="white")
fig, ax = plt.subplots(figsize=(15, 4))
colors = ["#F08080", "#00FA9A"]
labels = ['No Deposit', 'Deposit']
sns.countplot(y="age_category", hue='deposit', data=df, palette=colors).set_title('Employee Salary Turnover Distribution')
ax.set_ylabel("Age Category")
legend_name = plt.legend()
legend_name.get_texts()[0].set_text('Refused a T.D Suscription')
legend_name.get_texts()[1].set_text('Accepted a T.D Suscription')

# ## Dv. What type of occupation leads to more Term Deposit Suscriptions?
# <a id="occupations"></a> 
# <img src="https://media.giphy.com/media/3oKIPqXWNJswXf1InS/giphy.gif" height="1000" width="600">
# 
# ## Summary
# ***
# <ul>
# <li type="square"> People working in <b>Management</b>, <b>Blue-Collars</b> and <b>Technicians</b> received the most offers from the marketing department to suscribe term deposits. </li>
# <li type="square"> <b>Students</b>, <b>entrepreneurs</b> and <b>housemaids</b> received the less amount of offers from the marketing department.</li>
# <li type="square"> <b>74.7% of the students</b> suscribed term deposits (Which was expected since the youngest segment of the population is most likely to be a student) </li>
# <li type="square"><b>66.3% of people who were retired</b> were willing to suscribe term deposits (This was also expected since the oldest segment of the population is most likely to be retirees). </li>
# <li type="square"><b>56.6% of the unemployed</b> were willing to suscribe term deposits. (People tend to save more when they are not able to find jobs since there is most likely no source of income). </li>
# <li type="square">In the boxplot, the potential clients who belong to the retired category and refused to suscribe a term deposit <b>were much younger</b> (median age: Around 57) than the potential clients who accepted to suscribe a term deposit (median age: Around 66). </li>
# </ul>

# In[ ]:


sns.set(style="white")
fig, ax = plt.subplots(figsize=(14,8))
sns.countplot(x="job", data=df, palette="Set1")
ax.set_title("Occupations of Potential Clients", fontsize=20)
ax.set_xlabel("Types of Jobs")
plt.show()

# In[ ]:


cross_job_category = pd.crosstab(df['deposit'], df['job']).apply(lambda x: x/x.sum() * 100)
print(cross_job_category)

nodeposit_by_job = pd.DataFrame(cross_job_category.iloc[0])
nodeposit_by_job = np.around(nodeposit_by_job, 1)
nodeposit_by_job = nodeposit_by_job.values.tolist()
deposit_by_job = pd.DataFrame(cross_job_category.iloc[1])
deposit_by_job = np.around(deposit_by_job, 1)
deposit_by_job = deposit_by_job.values.tolist()

nodeposit_by_job

# In[ ]:


import plotly.plotly as py
import plotly.graph_objs as go




trace1 = go.Bar(
    x=['Admin', 'Blue Collar', 'Entrepreneur',
         'Housemaid', 'Management', 'Retired',
       'Self-Employed', 'Services', 'Student',
       'Technician', 'Unemployed', 'Unknown'],
    y=nodeposit_by_job,
    text= 12 * ['(%) Refused T.D Suscription'],
    name='Refused T.D Suscription',
    marker=dict(
        color='#FF3633',
    )
)
trace2 = go.Bar(
    x=['Admin', 'Blue Collar', 'Entrepreneur',
         'Housemaid', 'Management', 'Retired',
       'Self-Employed', 'Services', 'Student',
       'Technician', 'Unemployed', 'Unknown'],
    y=deposit_by_job,
    text=12 * ['(%) Accepted T.D Suscription'],
    name='Accepted T.D Suscription',
    marker=dict(
        color='#00ff99',
    )
)

data = [trace1, trace2]
layout = go.Layout(
    title= 'Status of Accounts by Occupation',
    barmode='stack',
    xaxis=dict(
        title='Type of Job',
        tickfont=dict(
            size=14,
            color='rgb(107, 107, 107)'
        )
    ),
    yaxis=dict(
        title='Percent (%)',
        titlefont=dict(
            size=16,
            color='rgb(107, 107, 107)'
        ),
    )
)

fig = go.Figure(data=data, layout=layout)
# iplot(fig, filename='stacked-bar')

# <iframe width="800" height="600" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/580.embed"></iframe>

# In[ ]:


import seaborn as sns

# Consider removing this graph unless it tells us something.

ax = plt.figure(figsize=(14,8))
# 0 = Did not suscribe term deposits, 1 = Did suscribe term deposits.
ax = sns.boxplot(x="job", y="age", hue="deposit",
                  data=df, palette={0:'#F08080', 1:'#00FA9A'})
plt.title("Age vs Occupation", fontsize=16)
plt.xlabel(s="Type of Job", fontsize=14)
plt.ylabel(s="Age", fontsize=14)
legend_name = plt.legend()
legend_name.get_texts()[0].set_text('Refused Opening a T.D')
legend_name.get_texts()[1].set_text('Accepted Opening a T.D')

plt.show()

# # E. Correlations that impacted the decision of Potential Clients:
# <a id="analysis_correlation"></a>
# <img src="https://media.giphy.com/media/VVPKOXc6aY1Lq/giphy.gif">
# 
# ## Ei. Correlation Matrix:
# ***
# 
# ## What does the correlation matrix tells us?
# <ul>
# <li type="square">The more <b>green</b> the square is, the more <b>positive correlated</b> it is with the column. The more <b>red</b> the square is, the more <b>negative correlated</b> the columns are.</li>
# <li type="square"> In this section we will try to see which columns are <b>positively correlated</b> and <b>negatively correlated</b> with the deposit column. What we are trying to do in this excercise is to see some further patterns.</li>
# </ul>

# In[ ]:


corr = df.corr()

sns.heatmap(corr,annot=True,cmap='RdYlGn',linewidths=0.2,annot_kws={'size':20})
fig=plt.gcf()
fig.set_size_inches(18,15)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.show()

# ## Eii. Balance Categories Vs Housing Loans:
# <a id="balance_housing"></a>
# <img src="https://media.giphy.com/media/UGyQwm7NyM3ny/giphy.gif" height=400 width=400>
# 
# ## Description:
# What are we analyzing h in this section? Wouldn't it be interesting to see if the amount of balance of a potential client influences highly in whether a individual will have a house loan. We have seen in the correlation matrix, that having a house loan influences negatively in the decision of a potential client for suscribing to a term deposit. 
# 
# ## Types of Balances: 
# One of the positive correlation that I find interesting to analyze in our correlation matrix is the balance of potential clients. Balance has a 0.08 (8%) positive correlation in whether a potential clients will suscribe a term deposit. In order to make things simplier we should **split the different balances into several categories.** The categories will be the following: <br><br>
# 
# **a) No Balance**: This category will be the potential clients who do not have a balance or have a negative balance. This potential clients should not be that much of an interest to the bank, since at the end the banks are also looking for people who have balance in their accounts for investment reasons. <br><br>
# **b) Low Balance**: For this category, potential clients will have a balance greater than 0 but lower than 1,000.<br><br>
# **c) Average Balance**: For this category, potential clients will have a balance greater than 1,000 but lower than 5,000<br><br>
# **d) High Balance**: For this category potential clients will have a balance greater than 5,000.
# 
# ## Our Aim: 
# Since balance has a positive correlation with whether a potential client will suscribe a term deposit, we should emphasize our marketing strategy on the people who are more likely to have a higher amount of balance. We will discover this in our analysis. In this case we will see from the **age categories** we analyzed previously, which of these categories tend to have a high balance and which of these categories is likely to suscribe a term deposit.
# 
# ## Summary:
# ***
# <li type="square"> The marketing campaign is targeting excessively potential clients from the <b>low balance segment.</b> (Remember the lower the balance, the more likely the potential client will refuse to suscribe a term deposit.) </li> 
# <li type="square"> We can see that in all the categories of age, our focus is on the <b>low balance category</b> or <b>no balance.</b></li> 
# <li type="square">The marketing campaign targets fewer people who have an <b>average balance</b> and <b>high balance.</b></li>
# <li type="square"> People with no balance and low balance were more likely to have a <b>house loan</b></li>

# In[ ]:


df['balance_categories'] = np.nan

lst = [df]

for column in lst:
    column.loc[column['balance'] <= 0, 'balance_categories'] = 'no balance'
    column.loc[(column['balance'] > 0) & (column['balance'] <= 1000), 'balance_categories'] = 'low balance'
    column.loc[(column['balance'] > 1000) & (column['balance'] <= 5000), 'balance_categories'] = 'average balance'
    column.loc[column['balance'] > 5000, 'balance_categories'] = 'high balance'
    
df.head()
df['balance_categories'].value_counts()
# We are targeting by a lot people with low balance!

# In[ ]:


fig, ax = plt.subplots(figsize=(12,8))
g = sns.countplot(x="balance_categories", data=df)

plt.title("Target Request per Balance Categories")
plt.xlabel('Balance Categories')
plt.ylabel("Number of Potential Clients Targeted")

plt.show()

# In[ ]:


fig, ax = plt.subplots(figsize=(12,8))
g = sns.countplot(x="balance_categories", data=df, hue='deposit', palette={0:'#F08080', 1:'#00FA9A'})

legend_name = plt.legend()
legend_name.get_texts()[0].set_text('Refused to Suscribe a T.D')
legend_name.get_texts()[1].set_text('Accepted to Suscribe a T.D')
plt.xlabel('Balance Categories')


plt.show()

# In[ ]:


colors = ['255, 87, 51', '93, 109, 126  ']
labels = ["No", "Yes"]

g = sns.factorplot(x="balance_categories",
                   hue="deposit", col="age_category",
                   data=df, kind="count",
                   size=4, aspect=.7, palette={0:'#DD4040', 1:'#58AD4B'});

g.set_xticklabels(rotation=30)
g.axes[0,0].set_xlabel('')
g.axes[0,1].set_xlabel('')
g.axes[0,2].set_xlabel('Balance Categories')
g.axes[0,3].set_xlabel('')
g.axes[0,4].set_xlabel('')

# Set title
g.axes[0,0].set_title('Youngest Category')
g.axes[0,1].set_title('In their 30s')
g.axes[0,2].set_title('In their 40s')
g.axes[0,3].set_title('In their 50s')
g.axes[0,4].set_title('Eldest Category')
g.axes[0,0].set_ylabel('Amount of Balance')
# replace labels
new_labels = ['Refused', 'Accepted']
for t, l in zip(g._legend.texts, new_labels): t.set_text(l)

plt.show()

# # Negative relationship between Loans and Suscriptions of Term Deposits:
# <a id="negative_relationship"></a>
# ## Summary
# ***
# <ul>
# <li type="square">There is a <b>negative correlation</b> of 20% for potential clients who have house loans. </li>
# <li type="square"> Potential clients that had a housing loan were more <b>eager to refuse offers</b> to suscribe a term deposit in the bank. </li>
# </ul>

# In[ ]:


# Apparently having a house loan was a huge reason for not suscribing a term deposit.
cross_house = pd.crosstab(df['deposit'], df['housing_int']).apply(lambda x: x/x.sum() * 100)
print(cross_house)
nodeposits = cross_house.iloc[0]
nodeposits = np.around(nodeposits, 2)
nodeposits = nodeposits.values.tolist()
deposits = cross_house.iloc[1]
deposits = np.around(deposits, 2)
deposits = deposits.values.tolist()
deposits

# In[ ]:


import plotly.plotly as py
import plotly.graph_objs as go

trace1 = go.Bar(
    x=['No House Loan', 'Has a House Loan'],
    y=nodeposits,
    text=['(%) Refused to Open D.A', '(%) Refused to Open D.A'],
    name='Refused Suscriptions',
    marker=dict(
        color='#FE4835',
        line=dict(
        color='#FF1E07',
        width=3,
        )
    ),
    opacity=0.8
)
trace2 = go.Bar(
    x=['No House Loan', 'Has a House Loan'],
    y=deposits,
    text=['(%) Accepted to Open D.A', '(%) Accepted to Open D.A' ],
    name='Accepted Suscriptions',
    marker=dict(
        color='#07FF58',
        line=dict(
        color='#07C344',
        width=3,
        )
    ),
    opacity=0.8
)

data = [trace1, trace2]
layout = go.Layout(
    barmode='stack', 
    title= "Previous House Loans VS Term Deposit Suscriptions",
)

fig = go.Figure(data=data, layout=layout)
# iplot(fig, filename='stacked-bar')

# <iframe width="800" height="600" frameborder="0" scrolling="no" src="//plot.ly/~AlexanderBach/582.embed"></iframe>

# In[ ]:


# People with no balance and low balance have a higher probability of having a house loan which in return will lead 
# to potential clients that refused suscribing term deposits.
cross_house = pd.crosstab(df["housing_int"], df["balance_categories"]).apply(lambda x: x/x.sum() * 100)
cross_house

# In[ ]:


fig, ax = plt.subplots(figsize=(10,8))
colors = ["#0B6121", "#DF0101"]
ax = sns.barplot(x='housing_int', y='balance_categories', data=df, hue="deposit", palette=colors)
ax.set_title("How likely is for a balance category \n to have a housing loan?")
ax.set_xlabel('totalCount')
ax.set_ylabel('Balance Categories')
legend_name = plt.legend()
legend_name.get_texts()[0].set_text('No House Loan')
legend_name.get_texts()[1].set_text('Has a House Loan')
plt.show()

# # Classification Model:
# <a id="classification_model">
# <img src="https://cdn-images-1.medium.com/max/1280/1*Jx3X4pD0KdiP8QDhi3d4Og.png">

# In[ ]:


dep = term_deposits['deposit']
term_deposits.drop(labels=['deposit'], axis=1,inplace=True)
term_deposits.insert(0, 'deposit', dep)
term_deposits.head()
# housing has a -20% correlation with deposit let's see how it is distributed.
# 52 %
term_deposits["housing"].value_counts()/len(term_deposits)

# In[ ]:


term_deposits["loan"].value_counts()/len(term_deposits)

# ## Stratified Sampling: <br>
# 
# <a id="stratified"></a>
# **Stratified Sampling:** Is an important concept that is often missed when developing a model either for regression or classification. Remember, that in order to avoid overfitting of our data we must implement a cross validation however, we must make sure that at least the features that have the greatest influence on our label (whether a potential client will open a term deposit or not) is **equally distributed**. What do I mean by this? <br><br>
# 
# **Personal Loans:**<br>
# For instance, having a personal loan is an important feature that determines whether a potential client will open a term deposit or not. To confirm it has a heavy weight on the final output you can check the correlation matrix above and you can see it has a -11% correlation with opening a deposit. What steps we should take before implementing stratified sampling in our train and test data?<br>
# 1) We need to see how our data is distributed. <br>
# 2) After noticiing that the column of loan contains 87% of "no" (Does not have personal loans) and 13% of "yes" (Have personal loans.) <br>
# 3) We want to make sure that our training and test set contains the same ratio of 87% "no" and 13% "yes"."
# **Stratified Sampling:** Is an important concept that is often missed when developing a model either for regression or classification. Remember, that in order to avoid overfitting of our data we must implement a cross validation however, we must make sure that at least the features that have the greatest influence on our label (whether a potential client will open a term deposit or not) is **equally distributed**. What do I mean by this? <br><br>
# 
# **Personal Loans:**<br>
# For instance, having a personal loan is an important feature that determines whether a potential client will open a term deposit or not. To confirm it has a heavy weight on the final output you can check the correlation matrix above and you can see it has a -11% correlation with opening a deposit. What steps we should take before implementing stratified sampling in our train and test data?<br>
# 1) We need to see how our data is distributed. <br>
# 2) After noticiing that the column of loan contains 87% of "no" (Does not have personal loans) and 13% of "yes" (Have personal loans.) <br>
# 3) We want to make sure that our training and test set contains the same ratio of 87% "no" and 13% "yes".

# In[ ]:


from sklearn.model_selection import StratifiedShuffleSplit
# Here we split the data into training and test sets and implement a stratified shuffle split.
stratified = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)

for train_set, test_set in stratified.split(term_deposits, term_deposits["loan"]):
    stratified_train = term_deposits.loc[train_set]
    stratified_test = term_deposits.loc[test_set]
    
stratified_train["loan"].value_counts()/len(df)
stratified_test["loan"].value_counts()/len(df)

# In[ ]:


# Separate the labels and the features.
train_data = stratified_train # Make a copy of the stratified training set.
test_data = stratified_test
train_data.shape
test_data.shape
train_data['deposit'].value_counts()

# In[ ]:


# Definition of the CategoricalEncoder class, copied from PR #9151.
# Just run this cell, or copy it to your code, no need to try to
# understand every line.

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils import check_array
from sklearn.preprocessing import LabelEncoder
from scipy import sparse

class CategoricalEncoder(BaseEstimator, TransformerMixin):
    """Encode categorical features as a numeric array.
    The input to this transformer should be a matrix of integers or strings,
    denoting the values taken on by categorical (discrete) features.
    The features can be encoded using a one-hot aka one-of-K scheme
    (``encoding='onehot'``, the default) or converted to ordinal integers
    (``encoding='ordinal'``).
    This encoding is needed for feeding categorical data to many scikit-learn
    estimators, notably linear models and SVMs with the standard kernels.
    Read more in the :ref:`User Guide <preprocessing_categorical_features>`.
    Parameters
    ----------
    encoding : str, 'onehot', 'onehot-dense' or 'ordinal'
        The type of encoding to use (default is 'onehot'):
        - 'onehot': encode the features using a one-hot aka one-of-K scheme
          (or also called 'dummy' encoding). This creates a binary column for
          each category and returns a sparse matrix.
        - 'onehot-dense': the same as 'onehot' but returns a dense array
          instead of a sparse matrix.
        - 'ordinal': encode the features as ordinal integers. This results in
          a single column of integers (0 to n_categories - 1) per feature.
    categories : 'auto' or a list of lists/arrays of values.
        Categories (unique values) per feature:
        - 'auto' : Determine categories automatically from the training data.
        - list : ``categories[i]`` holds the categories expected in the ith
          column. The passed categories are sorted before encoding the data
          (used categories can be found in the ``categories_`` attribute).
    dtype : number type, default np.float64
        Desired dtype of output.
    handle_unknown : 'error' (default) or 'ignore'
        Whether to raise an error or ignore if a unknown categorical feature is
        present during transform (default is to raise). When this is parameter
        is set to 'ignore' and an unknown category is encountered during
        transform, the resulting one-hot encoded columns for this feature
        will be all zeros.
        Ignoring unknown categories is not supported for
        ``encoding='ordinal'``.
    Attributes
    ----------
    categories_ : list of arrays
        The categories of each feature determined during fitting. When
        categories were specified manually, this holds the sorted categories
        (in order corresponding with output of `transform`).
    Examples
    --------
    Given a dataset with three features and two samples, we let the encoder
    find the maximum value per feature and transform the data to a binary
    one-hot encoding.
    >>> from sklearn.preprocessing import CategoricalEncoder
    >>> enc = CategoricalEncoder(handle_unknown='ignore')
    >>> enc.fit([[0, 0, 3], [1, 1, 0], [0, 2, 1], [1, 0, 2]])
    ... # doctest: +ELLIPSIS
    CategoricalEncoder(categories='auto', dtype=<... 'numpy.float64'>,
              encoding='onehot', handle_unknown='ignore')
    >>> enc.transform([[0, 1, 1], [1, 0, 4]]).toarray()
    array([[ 1.,  0.,  0.,  1.,  0.,  0.,  1.,  0.,  0.],
           [ 0.,  1.,  1.,  0.,  0.,  0.,  0.,  0.,  0.]])
    See also
    --------
    sklearn.preprocessing.OneHotEncoder : performs a one-hot encoding of
      integer ordinal features. The ``OneHotEncoder assumes`` that input
      features take on values in the range ``[0, max(feature)]`` instead of
      using the unique values.
    sklearn.feature_extraction.DictVectorizer : performs a one-hot encoding of
      dictionary items (also handles string-valued features).
    sklearn.feature_extraction.FeatureHasher : performs an approximate one-hot
      encoding of dictionary items or strings.
    """

    def __init__(self, encoding='onehot', categories='auto', dtype=np.float64,
                 handle_unknown='error'):
        self.encoding = encoding
        self.categories = categories
        self.dtype = dtype
        self.handle_unknown = handle_unknown

    def fit(self, X, y=None):
        """Fit the CategoricalEncoder to X.
        Parameters
        ----------
        X : array-like, shape [n_samples, n_feature]
            The data to determine the categories of each feature.
        Returns
        -------
        self
        """

        if self.encoding not in ['onehot', 'onehot-dense', 'ordinal']:
            template = ("encoding should be either 'onehot', 'onehot-dense' "
                        "or 'ordinal', got %s")
            raise ValueError(template % self.handle_unknown)

        if self.handle_unknown not in ['error', 'ignore']:
            template = ("handle_unknown should be either 'error' or "
                        "'ignore', got %s")
            raise ValueError(template % self.handle_unknown)

        if self.encoding == 'ordinal' and self.handle_unknown == 'ignore':
            raise ValueError("handle_unknown='ignore' is not supported for"
                             " encoding='ordinal'")

        X = check_array(X, dtype=np.object, accept_sparse='csc', copy=True)
        n_samples, n_features = X.shape

        self._label_encoders_ = [LabelEncoder() for _ in range(n_features)]

        for i in range(n_features):
            le = self._label_encoders_[i]
            Xi = X[:, i]
            if self.categories == 'auto':
                le.fit(Xi)
            else:
                valid_mask = np.in1d(Xi, self.categories[i])
                if not np.all(valid_mask):
                    if self.handle_unknown == 'error':
                        diff = np.unique(Xi[~valid_mask])
                        msg = ("Found unknown categories {0} in column {1}"
                               " during fit".format(diff, i))
                        raise ValueError(msg)
                le.classes_ = np.array(np.sort(self.categories[i]))

        self.categories_ = [le.classes_ for le in self._label_encoders_]

        return self

    def transform(self, X):
        """Transform X using one-hot encoding.
        Parameters
        ----------
        X : array-like, shape [n_samples, n_features]
            The data to encode.
        Returns
        -------
        X_out : sparse matrix or a 2-d array
            Transformed input.
        """
        X = check_array(X, accept_sparse='csc', dtype=np.object, copy=True)
        n_samples, n_features = X.shape
        X_int = np.zeros_like(X, dtype=np.int)
        X_mask = np.ones_like(X, dtype=np.bool)

        for i in range(n_features):
            valid_mask = np.in1d(X[:, i], self.categories_[i])

            if not np.all(valid_mask):
                if self.handle_unknown == 'error':
                    diff = np.unique(X[~valid_mask, i])
                    msg = ("Found unknown categories {0} in column {1}"
                           " during transform".format(diff, i))
                    raise ValueError(msg)
                else:
                    # Set the problematic rows to an acceptable value and
                    # continue `The rows are marked `X_mask` and will be
                    # removed later.
                    X_mask[:, i] = valid_mask
                    X[:, i][~valid_mask] = self.categories_[i][0]
            X_int[:, i] = self._label_encoders_[i].transform(X[:, i])

        if self.encoding == 'ordinal':
            return X_int.astype(self.dtype, copy=False)

        mask = X_mask.ravel()
        n_values = [cats.shape[0] for cats in self.categories_]
        n_values = np.array([0] + n_values)
        indices = np.cumsum(n_values)

        column_indices = (X_int + indices[:-1]).ravel()[mask]
        row_indices = np.repeat(np.arange(n_samples, dtype=np.int32),
                                n_features)[mask]
        data = np.ones(n_samples * n_features)[mask]

        out = sparse.csc_matrix((data, (row_indices, column_indices)),
                                shape=(n_samples, indices[-1]),
                                dtype=self.dtype).tocsr()
        if self.encoding == 'onehot-dense':
            return out.toarray()
        else:
            return out

# In[ ]:


from sklearn.base import BaseEstimator, TransformerMixin

# A class to select numerical or categorical columns 
# since Scikit-Learn doesn't handle DataFrames yet
class DataFrameSelector(BaseEstimator, TransformerMixin):
    def __init__(self, attribute_names):
        self.attribute_names = attribute_names
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        return X[self.attribute_names]

# In[ ]:


train_data.info()

# In[ ]:


from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

numerical_pipeline = Pipeline([
    ("select_numeric", DataFrameSelector(["age", "balance", "day", "campaign", "pdays", "previous","duration"])),
    ("std_scaler", StandardScaler()),
])

# In[ ]:


numerical_pipeline.fit_transform(train_data)

# In[ ]:


categorical_pipeline = Pipeline([
    ("select_cat", DataFrameSelector(["job", "education", "marital", "default", "housing", "loan", "contact", "month",
                                     "poutcome"])),
    ("cat_encoder", CategoricalEncoder(encoding='onehot-dense'))
])

# In[ ]:


categorical_pipeline.fit_transform(train_data)

# In[ ]:


from sklearn.pipeline import FeatureUnion
preprocess_pipeline = FeatureUnion(transformer_list=[
        ("numerical_pipeline", numerical_pipeline),
        ("categorical_pipeline", categorical_pipeline),
    ])

# In[ ]:


X_train = preprocess_pipeline.fit_transform(train_data)
X_train

# In[ ]:


y_train = train_data['deposit']
y_test = test_data['deposit']
y_train.shape

# In[ ]:


from sklearn.preprocessing import LabelEncoder

encode = LabelEncoder()
y_train = encode.fit_transform(y_train)
y_test = encode.fit_transform(y_test)
y_train_yes = (y_train == 1)
y_train
y_train_yes

# In[ ]:


some_instance = X_train[1250]

# # Classification Models:
# <a id="models"></a>

# In[ ]:


import time


from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, LabelEncoder
 
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB


dict_classifiers = {
    "Logistic Regression": LogisticRegression(),
    "Nearest Neighbors": KNeighborsClassifier(),
    "Linear SVM": SVC(),
    "Gradient Boosting Classifier": GradientBoostingClassifier(),
    "Decision Tree": tree.DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(n_estimators=18),
    "Neural Net": MLPClassifier(alpha=1),
    "Naive Bayes": GaussianNB()
}

# In[ ]:


# Thanks to Ahspinar for the function. 
no_classifiers = len(dict_classifiers.keys())

def batch_classify(X_train, Y_train, verbose = True):
    df_results = pd.DataFrame(data=np.zeros(shape=(no_classifiers,3)), columns = ['classifier', 'train_score', 'training_time'])
    count = 0
    for key, classifier in dict_classifiers.items():
        t_start = time.clock()
        classifier.fit(X_train, Y_train)
        t_end = time.clock()
        t_diff = t_end - t_start
        train_score = classifier.score(X_train, Y_train)
        df_results.loc[count,'classifier'] = key
        df_results.loc[count,'train_score'] = train_score
        df_results.loc[count,'training_time'] = t_diff
        if verbose:
            print("trained {c} in {f:.2f} s".format(c=key, f=t_diff))
        count+=1
    return df_results

# In[ ]:


df_results = batch_classify(X_train, y_train)
print(df_results.sort_values(by='train_score', ascending=False))

# # Overfitting:
# ## Example of Overfitting:
# <img src="https://tomrobertshaw.net/img/2015/12/overfitting.jpg"><br><br>
# ## Example of Cross Validation:
# <img src="http://vinhkhuc.github.io/assets/2015-03-01-cross-validation/5-fold-cv.png">
# <br><br> 
# ## Brief Description of Overfitting?
# This is an **error** in the modeling algorithm that takes into consideration random noise in the fitting process rather than the **pattern** itself.  You can see that this occurs when the model gets an **awsome** score in the training set but when we use the test set (Unknown data for the model) we get an **awful** score. This is likely to happen because of overfitting of the data (taking into consideration random noise in our pattern). What we want our model to do is to take the overall pattern of the data in order to correctly classify whether a potential client will suscribe to a term deposit or not. In the examples above, it is most likely that the Decision Tree Classifier and Random Forest classifiers are overfitting since they both give us nearly perfect scores (100% and 99%) accuracy scores. <br><br>
# 
# ## How can we avoid Overfitting?
# The best alternative to avoid overfitting is to use **cross validation.** Taking the training test and splitting it. For instance, if we split it by 3, 2/3 of the data or 66% will be used for training and 1/3 33% will be used or testing and we will do the testing process three times. This algorithm will iterate through all the training and test sets and the main purpose of this is to grab the overall pattern of the data.

# In[ ]:


# Use Cross-validation.
from sklearn.model_selection import cross_val_score

# Logistic Regression
log_reg = LogisticRegression()
log_scores = cross_val_score(log_reg, X_train, y_train, cv=3)
log_reg_mean = log_scores.mean()

# SVC
svc_clf = SVC()
svc_scores = cross_val_score(svc_clf, X_train, y_train, cv=3)
svc_mean = svc_scores.mean()

# KNearestNeighbors
knn_clf = KNeighborsClassifier()
knn_scores = cross_val_score(knn_clf, X_train, y_train, cv=3)
knn_mean = knn_scores.mean()

# Decision Tree
tree_clf = tree.DecisionTreeClassifier()
tree_scores = cross_val_score(tree_clf, X_train, y_train, cv=3)
tree_mean = tree_scores.mean()

# Gradient Boosting Classifier
grad_clf = GradientBoostingClassifier()
grad_scores = cross_val_score(grad_clf, X_train, y_train, cv=3)
grad_mean = grad_scores.mean()

# Random Forest Classifier
rand_clf = RandomForestClassifier(n_estimators=18)
rand_scores = cross_val_score(rand_clf, X_train, y_train, cv=3)
rand_mean = rand_scores.mean()

# NeuralNet Classifier
neural_clf = MLPClassifier(alpha=1)
neural_scores = cross_val_score(neural_clf, X_train, y_train, cv=3)
neural_mean = neural_scores.mean()

# Naives Bayes
nav_clf = GaussianNB()
nav_scores = cross_val_score(nav_clf, X_train, y_train, cv=3)
nav_mean = neural_scores.mean()

# Create a Dataframe with the results.
d = {'Classifiers': ['Logistic Reg.', 'SVC', 'KNN', 'Dec Tree', 'Grad B CLF', 'Rand FC', 'Neural Classifier', 'Naives Bayes'], 
    'Crossval Mean Scores': [log_reg_mean, svc_mean, knn_mean, tree_mean, grad_mean, rand_mean, neural_mean, nav_mean]}

result_df = pd.DataFrame(data=d)

# In[ ]:


# Gradient Boosting Classifier is the best performer.
result_df = result_df.sort_values(by=['Crossval Mean Scores'], ascending=False)
result_df

# # Confusion Matrix: 
# <a id="confusion"></a>
# <img src="https://computersciencesource.files.wordpress.com/2010/01/conmat.png">
# 
# ## Insights of a Confusion Matrix: 
# The main purpose of a confusion matrix is to see how our model is performing when it comes to classifying potential clients that are likely to suscribe to a term deposit. We will see in the confusion matrix four terms the True Positives, False Positives, True Negatives and False Negatives.<br><br>
# 
# **Positive/Negative:** Type of Class (label) ["No", "Yes"]
# **True/False:** Correctly or Incorrectly classified by the model.<br><br>
# 
# **True Negatives (Top-Left Square):** This is the number of **correctly** classifications of the "No" class or potenial clients that are **not willing** to suscribe a term deposit. <br><br>
# 
# **False Negatives (Top-Right Square):** This is the number of **incorrectly** classifications of the "No" class or potential clients that are **not willing** to suscribe a term depositt. <br><br>
# 
# **False Positives (Bottom-Left Square):** This is the number of **incorrectly** classifications of the "Yes" class or potential clients that are **willing** to suscribe a term deposit. <br><br>
# 
# **True Positives (Bottom-Right Square):** This is the number of **correctly** classifications of the "Yes" class or potenial clients that are **willing** to suscribe a term deposit.

# In[ ]:


# Cross validate our Gradient Boosting Classifier
from sklearn.model_selection import cross_val_predict

y_train_pred = cross_val_predict(grad_clf, X_train, y_train, cv=3)

# In[ ]:


from sklearn.metrics import accuracy_score
grad_clf.fit(X_train, y_train)
print ("Gradient Boost Classifier accuracy is %2.2f" % accuracy_score(y_train, y_train_pred))
# Our model has 73% accuracy.

# In[ ]:


from sklearn.metrics import confusion_matrix
# 4697: no's, 4232: yes
conf_matrix = confusion_matrix(y_train, y_train_pred)
f, ax = plt.subplots(figsize=(12, 8))
sns.heatmap(conf_matrix, annot=True, fmt="d", linewidths=.5, ax=ax)
plt.title("Confusion Matrix", fontsize=20)
plt.subplots_adjust(left=0.15, right=0.99, bottom=0.15, top=0.99)
ax.set_yticks(np.arange(conf_matrix.shape[0]) + 0.5, minor=False)
ax.set_xticklabels("")
ax.set_yticklabels(['Refused T. Deposits', 'Accepted T. Deposits'], fontsize=16, rotation=360)
plt.show()

# # Precision and Recall:
# <a id="precision_recall"></a>
# **Recall:** Is the total number of "Yes" in the label column of the dataset. So how many "Yes" labels does our model detect. <br><br>
# **Precision:** Means how sure is the prediction of our model that the actual label is a "Yes".
# 
# ## Recall Precision Tradeoff:
# As the precision gets higher the recall gets lower and vice versa. For instance, if we increase the precision from 30% to 60% the model is picking the predictions that the model believes is 60% sure. If there is an instance where the model believes that is 58% likely to be a potential client that will suscribe to a term deposit then the model will classify it as a **"No."** However, that instance was actually a **"Yes"** (potential client did suscribe to a term deposit.) That is why the higher the precision the more likely the model is to miss instances that are actually a **"Yes"!**

# In[ ]:


# Let's find the scores  for precision and recall.
from sklearn.metrics import precision_score, recall_score
# The model is 77% sure that the potential client will suscribe to a term deposit. 
# The model is only retaining 60% of clients that agree to suscribe a term deposit.
print('Precision Score: ', precision_score(y_train, y_train_pred))
# The classifier only detects 60% of potential clients that will suscribe to a term deposit.
print('Recall Score: ', recall_score(y_train, y_train_pred))

# In[ ]:


from sklearn.metrics import f1_score

f1_score(y_train, y_train_pred)

# In[ ]:


y_scores = grad_clf.decision_function([some_instance])
y_scores

# In[ ]:


# Increasing the threshold decreases the recall.
threshold = 0
y_some_digit_pred = (y_scores > threshold)

# In[ ]:


y_scores = cross_val_predict(grad_clf, X_train, y_train, cv=3, method="decision_function")
neural_y_scores = cross_val_predict(neural_clf, X_train, y_train, cv=3, method="predict_proba")
naives_y_scores = cross_val_predict(nav_clf, X_train, y_train, cv=3, method="predict_proba")

# In[ ]:


# hack to work around issue #9589 introduced in Scikit-Learn 0.19.0
if y_scores.ndim == 2:
    y_scores = y_scores[:, 1]

if neural_y_scores.ndim == 2:
    neural_y_scores = neural_y_scores[:, 1]
    
if naives_y_scores.ndim == 2:
    naives_y_scores = naives_y_scores[:, 1]

# In[ ]:


y_scores.shape

# In[ ]:


# How can we decide which threshold to use? We want to return the scores instead of predictions with this code.
from sklearn.metrics import precision_recall_curve

precisions, recalls, threshold = precision_recall_curve(y_train, y_scores)

# In[ ]:


def precision_recall_curve(precisions, recalls, thresholds):
    fig, ax = plt.subplots(figsize=(12,8))
    plt.plot(thresholds, precisions[:-1], "r--", label="Precisions")
    plt.plot(thresholds, recalls[:-1], "#424242", label="Recalls")
    plt.title("Precision and Recall \n Tradeoff", fontsize=18)
    plt.ylabel("Level of Precision and Recall", fontsize=16)
    plt.xlabel("Thresholds", fontsize=16)
    plt.legend(loc="best", fontsize=14)
    plt.xlim([-2, 4.7])
    plt.ylim([0, 1])
    plt.axvline(x=0.13, linewidth=3, color="#0B3861")
    plt.annotate('Best Precision and \n Recall Balance \n is at 0.13 \n threshold ', xy=(0.13, 0.83), xytext=(55, -40),
             textcoords="offset points",
            arrowprops=dict(facecolor='black', shrink=0.05),
                fontsize=12, 
                color='k')
    
precision_recall_curve(precisions, recalls, threshold)
plt.show()

# # ROC Curve (Receiver Operating Characteristic):
# The **ROC curve** tells us how well our classifier is classifying between term deposit suscriptions (True Positives) and non-term deposit suscriptions. The **X-axis** is represented by False positive rates (Specificity) and the **Y-axis** is represented by the True Positive Rate (Sensitivity.) As the line moves the threshold of the classification changes giving us different values. The closer is the line to our top left corner the better is our model separating both classes.
# 

# In[ ]:


from sklearn.metrics import roc_curve
# Gradient Boosting Classifier
# Neural Classifier
# Naives Bayes Classifier
grd_fpr, grd_tpr, thresold = roc_curve(y_train, y_scores)
neu_fpr, neu_tpr, neu_threshold = roc_curve(y_train, neural_y_scores)
nav_fpr, nav_tpr, nav_threshold = roc_curve(y_train, naives_y_scores)

# In[ ]:


def graph_roc_curve(false_positive_rate, true_positive_rate, label=None):
    plt.figure(figsize=(10,6))
    plt.title('ROC Curve \n Gradient Boosting Classifier', fontsize=18)
    plt.plot(false_positive_rate, true_positive_rate, label=label)
    plt.plot([0, 1], [0, 1], '#0C8EE0')
    plt.axis([0, 1, 0, 1])
    plt.xlabel('False Positive Rate', fontsize=16)
    plt.ylabel('True Positive Rate', fontsize=16)
    plt.annotate('ROC Score of 91.73% \n (Not the best score)', xy=(0.25, 0.9), xytext=(0.4, 0.85),
            arrowprops=dict(facecolor='#F75118', shrink=0.05),
            )
    plt.annotate('Minimum ROC Score of 50% \n (This is the minimum score to get)', xy=(0.5, 0.5), xytext=(0.6, 0.3),
                arrowprops=dict(facecolor='#F75118', shrink=0.05),
                )
    
    
graph_roc_curve(grd_fpr, grd_tpr, threshold)
plt.show()

# In[ ]:


from sklearn.metrics import roc_auc_score

print('Gradient Boost Classifier Score: ', roc_auc_score(y_train, y_scores))
print('Neural Classifier Score: ', roc_auc_score(y_train, neural_y_scores))
print('Naives Bayes Classifier: ', roc_auc_score(y_train, naives_y_scores))

# In[ ]:


def graph_roc_curve_multiple(grd_fpr, grd_tpr, neu_fpr, neu_tpr, nav_fpr, nav_tpr):
    plt.figure(figsize=(8,6))
    plt.title('ROC Curve \n Top 3 Classifiers', fontsize=18)
    plt.plot(grd_fpr, grd_tpr, label='Gradient Boosting Classifier (Score = 91.72%)')
    plt.plot(neu_fpr, neu_tpr, label='Neural Classifier (Score = 91.54%)')
    plt.plot(nav_fpr, nav_tpr, label='Naives Bayes Classifier (Score = 80.33%)')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.axis([0, 1, 0, 1])
    plt.xlabel('False Positive Rate', fontsize=16)
    plt.ylabel('True Positive Rate', fontsize=16)
    plt.annotate('Minimum ROC Score of 50% \n (This is the minimum score to get)', xy=(0.5, 0.5), xytext=(0.6, 0.3),
                arrowprops=dict(facecolor='#6E726D', shrink=0.05),
                )
    plt.legend()
    
graph_roc_curve_multiple(grd_fpr, grd_tpr, neu_fpr, neu_tpr, nav_fpr, nav_tpr)
plt.show()

# In[ ]:


# 97% that this potential client will not suscribe to a term deposit.
grad_clf.predict_proba([some_instance])

# In[ ]:


# Let's see what does our classifier predict.
grad_clf.predict([some_instance]) 

# In[ ]:


# Our classifier predicted that the potential client will reject to suscribe a term deposit.
# Let's confirm if this is true.
y_train[1250]

# # Which Features Influence the Result of a Term Deposit Suscription?
# ## DecisionTreeClassifier:
# <a id="decision"></a>
# The top three most important features for our classifier are **Duration (how long it took the conversation between the sales representative and the potential client), contact (number of contacts to the potential client within the same marketing campaign), month (the month of the year).
# 
# 
# 

# In[ ]:


term_deposits.head()

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
plt.style.use('seaborn-white')

# Convert the columns into categorical variables
term_deposits['job'] = term_deposits['job'].astype('category').cat.codes
term_deposits['marital'] = term_deposits['marital'].astype('category').cat.codes
term_deposits['education'] = term_deposits['education'].astype('category').cat.codes
term_deposits['contact'] = term_deposits['contact'].astype('category').cat.codes
term_deposits['poutcome'] = term_deposits['poutcome'].astype('category').cat.codes
term_deposits['month'] = term_deposits['month'].astype('category').cat.codes
term_deposits['default'] = term_deposits['default'].astype('category').cat.codes
term_deposits['loan'] = term_deposits['loan'].astype('category').cat.codes
term_deposits['housing'] = term_deposits['housing'].astype('category').cat.codes

# Let's create new splittings like before but now we modified the data so we need to do it one more time.
# Create train and test splits
target_name = 'deposit'
X = term_deposits.drop('deposit', axis=1)


label=term_deposits[target_name]

X_train, X_test, y_train, y_test = train_test_split(X,label,test_size=0.2, random_state=42, stratify=label)

# Build a classification task using 3 informative features
tree = tree.DecisionTreeClassifier(
    class_weight='balanced',
    min_weight_fraction_leaf = 0.01
    
)



tree = tree.fit(X_train, y_train)
importances = tree.feature_importances_
feature_names = term_deposits.drop('deposit', axis=1).columns
indices = np.argsort(importances)[::-1]

# Print the feature ranking
print("Feature ranking:")

for f in range(X_train.shape[1]):
    print("%d. feature %d (%f)" % (f + 1, indices[f], importances[indices[f]]))

# Plot the feature importances of the forest
def feature_importance_graph(indices, importances, feature_names):
    plt.figure(figsize=(12,6))
    plt.title("Determining Feature importances \n with DecisionTreeClassifier", fontsize=18)
    plt.barh(range(len(indices)), importances[indices], color='#31B173',  align="center")
    plt.yticks(range(len(indices)), feature_names[indices], rotation='horizontal',fontsize=14)
    plt.ylim([-1, len(indices)])
    plt.axhline(y=1.85, xmin=0.21, xmax=0.952, color='k', linewidth=3, linestyle='--')
    plt.text(0.30, 2.8, '46% Difference between \n duration and contacts', color='k', fontsize=15)
    
feature_importance_graph(indices, importances, feature_names)
plt.show()

# ## GradientBoosting Classifier Wins!
# Gradient Boosting classifier is the best model to predict whether or not a **potential client** will suscribe to a term deposit or not.  84% accuracy!

# In[ ]:


# Our three classifiers are grad_clf, nav_clf and neural_clf
from sklearn.ensemble import VotingClassifier

voting_clf = VotingClassifier(
    estimators=[('gbc', grad_clf), ('nav', nav_clf), ('neural', neural_clf)],
    voting='soft'
)

voting_clf.fit(X_train, y_train)

# In[ ]:


from sklearn.metrics import accuracy_score

for clf in (grad_clf, nav_clf, neural_clf, voting_clf):
    clf.fit(X_train, y_train)
    predict = clf.predict(X_test)
    print(clf.__class__.__name__, accuracy_score(y_test, predict))

# # What Actions should the Bank Consider?
# <a id="bank_actions"></a>
# <img src="https://media.giphy.com/media/l46Cy1rHbQ92uuLXa/giphy.gif">
# 
# 
# ## Solutions for the Next Marketing Campaign (Conclusion):
# 1) **Months of Marketing Activity:** We saw that the the month of highest level of marketing activity was the month of **May**. However, this was the month that potential clients tended to reject term deposits offers (Lowest effective rate: -34.49%). For the next marketing campaign, it will be wise for the bank to focus the marketing campaign during the months of **March, September, October and December.** (December should be under consideration because it was the month with the lowest marketing activity, there might be a reason why december is the lowest.)<br><br>
# 2) **Seasonality:** Potential clients opted to suscribe term deposits during the seasons of **fall** and **winter**. The next marketing campaign should focus its activity throghout these seasons. <br><br>
# 3) **Campaign Calls:** A policy should be implemented that states that no more than 3 calls should be applied to the same potential client in order to save time and effort in getting new potential clients. Remember, the more we call the same potential client, the likely he or she will decline to open a term deposit. <br><br>
# 4) **Age Category:** The next marketing campaign of the bank should target potential clients in their 20s or younger and 60s or older. The youngest category had a 60% chance of suscribing to a term deposit while the eldest category had a 76% chance of suscribing to a term deposit. It will be great if for the next campaign the bank addressed these two categories and therefore, increase the likelihood of more term deposits suscriptions. <br><br>
# 5) **Occupation:** Not surprisingly, potential clients that were students or retired were the most likely to suscribe to a term deposit. Retired individuals, tend to have more term deposits in order to gain some cash through interest payments. Remember, term deposits are short-term loans in which the individual (in this case the retired person) agrees not to withdraw the cash from the bank until a certain date agreed between the individual and the financial institution. After that time the individual gets its capital back and its interest made on the loan. Retired individuals tend to not spend bigly its cash so they are morelikely to put their cash to work by lending it to the financial institution. Students were the other group that used to suscribe term deposits.<br><br>
# 6) **House Loans and Balances:** Potential clients in the low balance and no balance category were more likely to have a house loan than people in the average and high balance category. What does it mean to have a house loan? This means that the potential client has financial compromises to pay back its house loan and thus, there is no cash for he or she to suscribe to a term deposit account. However, we see that potential clients in the average and hih balances are less likely to have a house loan and therefore, more likely to open a term deposit. Lastly, the next marketing campaign should focus on individuals of average and high balances in order to increase the likelihood of suscribing to a term deposit. <br><br>
# 
# 7) **Develop a Questionaire during the Calls:** Since duration of the call is the feature that most positively correlates with whether a potential client will open a term deposit or not, by providing an interesting questionaire for potential clients during the calls the conversation length might increase. Of course, this does not assure us that the potential client will suscribe to a term deposit! Nevertheless, we don't loose anything by implementing a strategy that will increase the level of engagement of the potential client leading to an increase probability of suscribing to a term deposit, and therefore an increase in effectiveness for the next marketing campaign the bank will excecute. <br><br>
# 
# By combining all these strategies and simplifying the market audience the next campaign should address, it is likely that the next marketing campaign of the bank will be more effective than the current one.
# 
# 
# 
# 
# 

# # References:
# 1) Hands-On Machine Learning with Scikit-Learn and TensorFlow by Aurélien Géron.<br>
# 2) Special Thanks to Ahmet Taspinar. (Insights on a handul of functions) Link: http://ataspinar.com/2017/05/26/classification-with-scikit-learn/ <br>
# 3) Special Thanks to Randy Lao and his Predicting Employee KernelOver work. Link: https://www.kaggle.com/randylaosat/predicting-employee-kernelover

# In[ ]:



