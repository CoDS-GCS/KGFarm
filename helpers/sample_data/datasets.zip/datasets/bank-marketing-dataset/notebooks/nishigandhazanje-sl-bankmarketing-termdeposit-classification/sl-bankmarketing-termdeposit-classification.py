#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
        pass

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# # PROBLEM STATEMENT
# **The data is related with direct marketing campaigns (phone calls) of a Portuguese banking institution. The classification goal is to predict if the client will subscribe (yes/no) a term deposit (variable y).**
# 
# 

# **#input variables(bank client data):**
# 
# **#age | int64 | age in years**
# 
# **#job | object | type of job (categorical: ['admin.' 'technician' 'services' 'management' 'retired' 'blue-collar' 'unemployed' 'entrepreneur' 'housemaid' 'unknown' 'self-employed' 'student'])
# **
# **#marital | object | marital status (categorical: ['married' 'single' 'divorced'])**
# 
# **#education | Object | education background (categorical: ['secondary' 'tertiary' 'primary' 'unknown'])**
# 
# **#default | Object | has credit in default? (categorical: ['no' 'yes'])**
# 
# **#balance | int64 | Balance of the individual**
# 
# **#housing | object | has housing loan? (categorical: ['yes' 'no'])**
# 
# **#loan | object | has personal loan? (categorical: ['no' 'yes'])**
# 
# **#contact | object | contact communication type (categorical: ['unknown' 'cellular' 'telephone'])**
# 
# **#day | int64 | last contact day of the week (categorical: 'mon','tue','wed','thu','fri')**
# 
# **#month | object | last contact month of year (categorical: ['may' 'jun' 'jul' 'aug' 'oct' 'nov' 'dec' 'jan' 'feb' 'mar' 'apr' 'sep'])**
# 
# **#duration | int64 | last contact duration, in seconds (numeric)**
# 
# **#campaign | int64 | number of contacts performed during this campaign and for this client**
# 
# **#pdays | int64 | number of days that passed by after the client was last contacted from a previous campaign (numeric; 999 means client was not previously contacted)**
# 
# **#previous | int64 | number of contacts performed before this campaign and for this client**
# 
# **#poutcome | object | outcome of the previous marketing campaign (categorical: ['unknown' 'other' 'failure' 'success'])****
# 
# 
# **#Output variable (desired target):
# #y-has the client subscribed a term deposit? (binary: 'yes','no')**

# *Import libraries*

# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns


# # Explore and Visualize the features

# ##  Load the dataset

# In[ ]:


df=pd.read_csv('../input/bank-marketing-dataset/bank.csv')


# In[ ]:


#Shows top 5 records
df.head()


# In[ ]:


#shows no. of rows and columns
df.shape


# In[ ]:


#checks if null values present(0)
df.isnull().sum()


# In[ ]:


#shows datatype and null values present for all columns
df.info() 


# In[ ]:


#shows no.of unique values per column
for column in df.columns:
    print(column,df[column].nunique())


# In[ ]:


#shows statistical summary for numerical columns
df.describe()


# ## Data Preprocessing: Label Encoder

# In[ ]:


#converts categorical columns to numeric format
from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
df['n_deposit']=le.fit_transform(df['deposit'])


# In[ ]:


df


# In[ ]:


#deleted 2 columns from dataset 
# df.drop(['deposit','pdays'],axis=1,inplace=True)
# df


# In[ ]:


#checks no. of values in deposit column(balanced data)
df.n_deposit.value_counts()


# ## Categorical Feature Distribution

# In[ ]:


#balanced output data
sns.countplot(x='n_deposit',data=df)


# In[ ]:


#shows unique values for all columns
for col in df.select_dtypes(include='object').columns:
  print(col)
  print(df[col].unique()) 


# **Client with job type as management records are high and housemaid are very less**

# ## Data Visualization

# In[ ]:


#client with job profile managemnent is higher and less for housemaid.
sns.countplot(y='job',data=df)


# In[ ]:


#client who married are high in records and divorced are less
sns.countplot(y='marital',data=df)


# In[ ]:


sns.countplot(y='education',data=df)
#client whoes education background is secondary are in high numbers


# In[ ]:


sns.countplot(y='default',data=df)
#defualt feature looks unimportant  as it has value of no at high ratio to value yes(highly imbalance) which can drop


# In[ ]:


sns.countplot(y='housing',data=df)
##balance in housing loan for clients


# In[ ]:


sns.countplot(y='loan',data=df)
#high no. of clients with no personal loan


# In[ ]:


sns.countplot(y='contact',data=df)


# In[ ]:


sns.countplot(y='month',data=df)
#data in month of may is high and less in dec


# In[ ]:


sns.countplot(y='poutcome',data=df)


# In[ ]:


#applying label encoder on categorical columns
df['n_job']=le.fit_transform(df['job'])
df['n_marital']=le.fit_transform(df['marital'])
df['n_education']=le.fit_transform(df['education'])
df['n_loan']=le.fit_transform(df['loan'])
df['n_contact']=le.fit_transform(df['contact'])
df['n_month']=le.fit_transform(df['month'])
df['n_poutcome']=le.fit_transform(df['poutcome'])
df['n1_deposit']=df['n_deposit']


# In[ ]:


# df.drop(['n_deposit'],axis=1,inplace=True)
# df


# In[ ]:


# df.drop(['job','month','marital','education','default','housing','loan','contact','poutcome'],axis=1,inplace=True)


# In[ ]:


df.head()


# In[ ]:


#shows all uniquevalues per column
for col in df.select_dtypes(include='int64').columns:
  print(col)
  print(df[col].unique()) 


# In[ ]:


df.describe()


# # Outlier Detection

# In[ ]:


figure, axis = plt.subplots(3, 4, figsize = (50,25))
sns.boxplot(x='n1_deposit',y='age',data=df,ax=axis[0,0])
sns.boxplot(x='n1_deposit',y='balance',data=df,ax=axis[0,1])
sns.boxplot(x='n1_deposit',y='duration',data=df,ax=axis[0,2])
sns.boxplot(x='n1_deposit',y='campaign',data=df,ax=axis[0,3])
sns.boxplot(x='n1_deposit',y='previous',data=df,ax=axis[1,0])
sns.boxplot(x='n1_deposit',y='n_job',data=df,ax=axis[1,1])
sns.boxplot(x='n1_deposit',y='n_marital',data=df,ax=axis[1,2])
sns.boxplot(x='n1_deposit',y='n_education',data=df,ax=axis[1,3])
sns.boxplot(x='n1_deposit',y='n_loan',data=df,ax=axis[2,0])
sns.boxplot(x='n1_deposit',y='n_contact',data=df,ax=axis[2,1])
sns.boxplot(x='n1_deposit',y='n_month',data=df,ax=axis[2,2])
sns.boxplot(x='n1_deposit',y='n_poutcome',data=df,ax=axis[2,3])



# In[ ]:


#shows all record whose deposit value is 0 
outcome_zero=df[df['n1_deposit'] == 0]
outcome_zero


# In[ ]:


#shows all record whose deposit value is 1
outcome_one=df[df['n1_deposit'] == 1]
outcome_one


# In[ ]:


df.n1_deposit.value_counts()


# # Outlier Removal

# In[ ]:


def Outdet(df):
    Q1=df.quantile(0.25)
    Q3=df.quantile(0.75)
    IQR=Q3-Q1
    LR=Q1-(IQR*1.5)
    UR=Q3+(IQR*1.5)
    return LR,UR


# In[ ]:


LR,UR=Outdet(outcome_zero.age)
print(LR,UR)


# In[ ]:


#removing outliers from feature(age)
outcome_zero=outcome_zero[(outcome_zero['age'] > LR)  &  (outcome_zero['age'] < UR)]
outcome_zero


# **5873 rows-Before outlier removal from age**
# 
# **5818 rows-After outlier removal from age**

# In[ ]:


LR,UR=Outdet(outcome_zero.balance)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['balance']>LR) & (outcome_zero['balance']< UR)]
outcome_zero


# **5818 rows-Before outlier removal from balance**
# 
# **5205  rows-After outlier removal from balance**

# In[ ]:


LR,UR=Outdet(outcome_zero.day)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['day']>LR) & (outcome_zero['day']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_zero.duration)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['duration']>LR) & (outcome_zero['duration']< UR)]
outcome_zero


# **5205**
# 
# **4865**
# 

# In[ ]:


LR,UR=Outdet(outcome_zero.campaign)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['campaign']>LR) & (outcome_zero['campaign']< UR)]
outcome_zero


# **4865**
# 
# **4339** 
# 
# 

# In[ ]:


LR,UR=Outdet(outcome_one.age)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['age']>LR) & (outcome_one['age']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.balance)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['balance']>LR) & (outcome_one['balance']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.day)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['day']>LR) & (outcome_one['day']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.duration)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['duration']>LR) & (outcome_one['duration']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.campaign)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['campaign']>LR) & (outcome_one['campaign']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.n_poutcome)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['n_poutcome']>LR) & (outcome_one['n_poutcome']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_one.balance)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['balance']>LR) & (outcome_one['balance']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_zero.balance)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['balance']>LR) & (outcome_zero['balance']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_zero.duration)
print(LR,UR)


# In[ ]:


outcome_zero=outcome_zero[(outcome_zero['duration']>LR) & (outcome_zero['duration']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_one.duration)
print(LR,UR)


# In[ ]:


outcome_one=outcome_one[(outcome_one['duration']>LR) & (outcome_one['duration']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_zero.balance)
print(LR,UR)
outcome_zero=outcome_zero[(outcome_zero['balance']>LR) & (outcome_zero['balance']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_one.balance)
print(LR,UR)
outcome_one=outcome_one[(outcome_one['balance']>LR) & (outcome_one['balance']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_zero.balance)
print(LR,UR)
outcome_zero=outcome_zero[(outcome_zero['balance']>LR) & (outcome_zero['balance']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_one.balance)
print(LR,UR)
outcome_one=outcome_one[(outcome_one['balance']>LR) & (outcome_one['balance']< UR)]
outcome_one


# In[ ]:


LR,UR=Outdet(outcome_zero.balance)
print(LR,UR)
outcome_zero=outcome_zero[(outcome_zero['balance']>LR) & (outcome_zero['balance']< UR)]
outcome_zero


# In[ ]:


LR,UR=Outdet(outcome_one.balance)
print(LR,UR)
outcome_one=outcome_one[(outcome_one['balance']>LR) & (outcome_one['balance']< UR)]
outcome_one


# In[ ]:


df_1=pd.concat([outcome_zero,outcome_one],axis=0)
df_1


# In[ ]:


df_1.n1_deposit.value_counts()


# In[ ]:


figure, axis = plt.subplots(3, 4, figsize = (50,25))
sns.boxplot(x='n1_deposit',y='age',data=df_1,ax=axis[0,0])
sns.boxplot(x='n1_deposit',y='balance',data=df_1,ax=axis[0,1])
sns.boxplot(x='n1_deposit',y='duration',data=df_1,ax=axis[0,2])
sns.boxplot(x='n1_deposit',y='campaign',data=df_1,ax=axis[0,3])
sns.boxplot(x='n1_deposit',y='previous',data=df_1,ax=axis[1,0])
sns.boxplot(x='n1_deposit',y='n_job',data=df_1,ax=axis[1,1])
sns.boxplot(x='n1_deposit',y='n_marital',data=df_1,ax=axis[1,2])
sns.boxplot(x='n1_deposit',y='n_education',data=df_1,ax=axis[1,3])
sns.boxplot(x='n1_deposit',y='n_loan',data=df_1,ax=axis[2,0])
sns.boxplot(x='n1_deposit',y='n_contact',data=df_1,ax=axis[2,1])
sns.boxplot(x='n1_deposit',y='n_month',data=df_1,ax=axis[2,2])
sns.boxplot(x='n1_deposit',y='n_poutcome',data=df_1,ax=axis[2,3])


# In[ ]:


sns.pairplot(df_1)


# # Correlation Matrix

# In[ ]:


plt.figure(figsize=(20,20))
sns.heatmap(df_1.corr(),annot =True)


# **High correlation between feature and target label
# 1)duration(0.56)
# 2)balance(0.30)
# 3)n_contact(-0.25)
# 4)campaign(-0.23)
# 5)n_loan(-0.12)
# 6)previous(0.11)
# 7)n_education(0.10)
# **
# 
# 
# 

# In[ ]:


df_1


# In[ ]:


# x=df_1.drop(['n1_deposit','age','day','n_job','n_marital','n_month','n_poutcome'],axis=1).values
print(x)
y=df_1['n1_deposit'].values
print(y)


# # Splitting of Data

# In[ ]:


from sklearn.model_selection import train_test_split
(x_train,x_test,y_train,y_test)=train_test_split(x,y,test_size=0.2)


# # Scale the data to improve model performance

# In[ ]:


from sklearn.preprocessing import StandardScaler
std_model=StandardScaler()
x_train_std_features=std_model.fit_transform(x_train)
x_test_std_features=std_model.transform(x_test)


# In[ ]:


x_train_std_features.shape


# In[ ]:


x_test_std_features.shape


# # Model Building(Logistic Regression)

# In[ ]:


from sklearn.linear_model import LogisticRegression
modelreg=LogisticRegression()


# In[ ]:


modelreg.fit(x_train_std_features,y_train)


# In[ ]:


ypred=modelreg.predict(x_test_std_features)
ypred


# In[ ]:


modelreg.score(x_test_std_features,y_test)


# In[ ]:


x_test_std_features.shape


# In[ ]:


y_test.shape


# In[ ]:


from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(y_test, ypred))
print("Precision:",metrics.precision_score(y_test, ypred))
print("Recall:",metrics.recall_score(y_test, ypred))


# In[ ]:


cnf_matrix = metrics.confusion_matrix(y_test, ypred)
cnf_matrix


# # Model Building(KNeighborsClassifier)

# In[ ]:


from sklearn.neighbors import KNeighborsClassifier
KNN_model = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
KNN_model.fit(x_train_std_features, y_train)


# In[ ]:


y_predicted_KNN = KNN_model.predict(x_test_std_features)


# In[ ]:


KNN_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test, y_predicted_KNN))
print("Precision:",metrics.precision_score(y_test,y_predicted_KNN))
print("Recall:",metrics.recall_score(y_test, y_predicted_KNN))


# # Model Building(Naive Bayes)

# In[ ]:


from sklearn.naive_bayes import GaussianNB
naive_bayes_model= GaussianNB()
naive_bayes_model.fit(x_train_std_features, y_train)


# In[ ]:


y_predicted_naive = naive_bayes_model.predict(x_test_std_features)


# In[ ]:


naive_bayes_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test, y_predicted_naive))
print("Precision:",metrics.precision_score(y_test,y_predicted_naive))
print("Recall:",metrics.recall_score(y_test, y_predicted_naive))


# # Model Building(Decision Tree Classifier)

# In[ ]:


from sklearn.tree import DecisionTreeClassifier
deseciontree_model=DecisionTreeClassifier()
deseciontree_model.fit(x_train_std_features, y_train)


# In[ ]:


y_predicted_deseciontree = deseciontree_model.predict(x_test_std_features)
deseciontree_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_deseciontree))
print("Precision:",metrics.precision_score(y_test,y_predicted_deseciontree))
print("Recall:",metrics.recall_score(y_test, y_predicted_deseciontree))


# # Model Building(Random Forest Classifier)

# In[ ]:


from sklearn.ensemble import RandomForestClassifier
randomforest_model= RandomForestClassifier(n_estimators = 10, criterion = 'entropy')
randomforest_model.fit(x_train_std_features, y_train)


# In[ ]:


y_predicted_randomforest = randomforest_model.predict(x_test_std_features)
randomforest_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_randomforest))
print("Precision:",metrics.precision_score(y_test,y_predicted_randomforest))
print("Recall:",metrics.recall_score(y_test, y_predicted_randomforest))


# # Model Building(SVM using RBF kernel)

# In[ ]:


from sklearn.svm import SVC
SVM_model_rbf=SVC(kernel='rbf')
SVM_model_rbf.fit(x_train_std_features,y_train)


# In[ ]:


y_predicted_SVM_rbf = SVM_model_rbf.predict(x_test_std_features)
SVM_model_rbf.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_SVM_rbf))
print("Precision:",metrics.precision_score(y_test,y_predicted_SVM_rbf))
print("Recall:",metrics.recall_score(y_test, y_predicted_SVM_rbf))


# # Model Building(SVM using linear kernel)

# In[ ]:


from sklearn.svm import SVC
SVM_model_linear=SVC(kernel='linear')
SVM_model_linear.fit(x_train_std_features,y_train)


# In[ ]:


y_predicted_SVM_linear = SVM_model_linear.predict(x_test_std_features)


# In[ ]:


SVM_model_linear.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_SVM_linear))
print("Precision:",metrics.precision_score(y_test,y_predicted_SVM_linear))
print("Recall:",metrics.recall_score(y_test, y_predicted_SVM_linear))


# # Model Building(Gradient Boosting Classifier)

# In[ ]:


from sklearn.ensemble import GradientBoostingClassifier
GradientB_model=GradientBoostingClassifier(n_estimators=100,learning_rate=1.0)


# In[ ]:


GradientB_model.fit(x_train_std_features,y_train)
y_predicted_GradientB = GradientB_model.predict(x_test_std_features)


# In[ ]:


GradientB_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_GradientB))
print("Precision:",metrics.precision_score(y_test,y_predicted_GradientB))
print("Recall:",metrics.recall_score(y_test, y_predicted_GradientB))


# # Model Building(AdaBoost Classifier)

# In[ ]:


from sklearn.ensemble import AdaBoostClassifier


# In[ ]:


Adaboost_model=AdaBoostClassifier(n_estimators=100)


# In[ ]:


Adaboost_model.fit(x_train_std_features,y_train)
y_predicted_Adaboost = Adaboost_model.predict(x_test_std_features)


# In[ ]:


Adaboost_model.score(x_test_std_features,y_test)


# In[ ]:


print("Accuracy:",metrics.accuracy_score(y_test,y_predicted_Adaboost))
print("Precision:",metrics.precision_score(y_test,y_predicted_Adaboost))
print("Recall:",metrics.recall_score(y_test, y_predicted_Adaboost))


# # Final Report

# In[ ]:


dfnew = pd.DataFrame()
dfnew['Names'] = ['LogisticRegression','KNeighborsClassifier','GaussianNB','DecisionTreeClassifier','RandomForestClassifier','SVM_RBF','SVM_Linear','GradientBoostingClassifier','AdaBoostClassifier']
dfnew['Score'] = [0.8411764705882353,0.8235294117647058,0.8213235294117647,0.8154411764705882,0.8286764705882353,0.8485294117647059,0.8404411764705882,0.8404411764705882,0.8551470588235294]
dfnew['precision']=[0.8547008547008547,0.831918505942275,0.8540145985401459,0.790519877675841,0.8466898954703833,0.8828828828828829,0.8544520547945206,0.8544520547945206,0.8754325259515571]
dfnew['recall']=[0.7923930269413629,0.7765451664025357,0.7416798732171157,0.8193343898573693,0.7702060221870047,0.7765451664025357,0.7908082408874801,0.7908082408874801,0.8019017432646592]
dfnew


# In[ ]:


cm = sns.light_palette('navy',as_cmap=True)
s = dfnew.style.background_gradient(cmap=cm)
s


# In[ ]:


plt.figure(figsize=(20,5))
sns.set(style="whitegrid")
ax = sns.barplot(y ='Score',x = 'Names',data = dfnew)


# In[ ]:


from sklearn.metrics import classification_report,roc_auc_score,roc_curve,auc
report_Adaboost = classification_report(y_test,y_predicted_Adaboost)
print(report_Adaboost)


# In[ ]:


roc_auc_score(y_test,y_predicted_Adaboost)


# In[ ]:


fpr,tpr,threshold =roc_curve(y_test,y_predicted_Adaboost)
auc = auc(fpr,tpr)


# In[ ]:


plt.figure(figsize=(5,5),dpi=100)
plt.plot(fpr,tpr,linestyle='-',label = "(auc = %0.3f)" % auc)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend()
plt.show()


# # Conclusion:
# **The dataset contained 16 features and 1 target variable for binary classification which determines if client will subscribe deposit or not.I have done feature extraction and got 7 important features, then applied various classification algorithms on the data which made it clear that Adaboost Classifier Model performed excellent with high accuracy(85%) compared to other algorithms.**
