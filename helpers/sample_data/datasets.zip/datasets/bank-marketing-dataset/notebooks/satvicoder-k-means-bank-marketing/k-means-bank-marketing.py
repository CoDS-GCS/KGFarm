#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline

# In[ ]:


df= pd.read_csv('../input/bank-marketing-dataset/bank.csv')

# In[ ]:


df.head()

# In[ ]:


df.columns

# In[ ]:


df.info

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df, x='age')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df, x='age', hue='loan')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df, x='pdays')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df[df['pdays']<400], x='pdays')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df, x='duration')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.histplot(data=df, x='duration', hue='contact')
plt.xlim(0,2000)

# In[ ]:


sns.countplot(data=df, x='contact')

# In[ ]:


plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='previous', hue='contact' )
plt.legend(loc=(1.1, 0.5))

# In[ ]:


df['previous'].value_counts()

# In[ ]:


plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='job', order=df['job'].value_counts().index)
plt.xticks(rotation=90);

# In[ ]:


plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='education', order=df['education'].value_counts().index)
plt.xticks(rotation=90);

# In[ ]:


plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='education', order=df['education'].value_counts().index, hue='default')
plt.xticks(rotation=90);

# In[ ]:


plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='job', order=df['job'].value_counts().index, hue='default')
plt.xticks(rotation=90);

# In[ ]:


sns.countplot(data=df, x='default')

# In[ ]:


X= pd.get_dummies(df)

# In[ ]:


X

# In[ ]:


from sklearn.preprocessing import StandardScaler

# In[ ]:


Sc= StandardScaler()

# In[ ]:


Sc_X= Sc.fit_transform(X)

# In[ ]:


from sklearn.cluster import KMeans

# In[ ]:


Mdl = KMeans(n_clusters=2)

# In[ ]:


Clus_Lbls= Mdl.fit_predict(Sc_X)

# In[ ]:


len(Sc_X)

# In[ ]:


len(Clus_Lbls)

# In[ ]:


X['Cluster']=Clus_Lbls

# In[ ]:


X.corr()['Cluster'].sort_values()

# In[ ]:


plt.figure(figsize=(15,6))
X.corr()['Cluster'].sort_values().plot(kind='bar')

# In[ ]:


ssd= []

for k in range (2, 10):
    Mdl=KMeans(n_clusters=k)
    
    Mdl.fit(Sc_X)
    
    ssd.append(Mdl.inertia_)

# In[ ]:


plt.plot(range(2,10), ssd, 'o--')
plt.xlabel('K Value')
plt.ylabel('Sum of Squared Distances')

# In[ ]:


pd.Series(ssd).diff()

# In[ ]:


pd.Series(ssd).diff().plot(kind='bar')
