#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import f1_score


# In[2]:


entity_df = pd.read_csv('../../data/bank_stats.csv')
entity_df


# In[3]:


label_encoder = LabelEncoder()
entity_df['membership'] = label_encoder.fit_transform(entity_df['membership']) 
entity_df


# In[4]:


X = entity_df.drop(['membership', 'customer_id', 'event_timestamp', 'n_accounts', 'deposit'], axis=1)

y = entity_df['membership']


# In[5]:


# split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=0)

# instanciate the models
random_forest_classifier = RandomForestClassifier()
gradient_boosting_classifier = GradientBoostingClassifier()
naive_bayes_classifier = GaussianNB()

# fit the models on data
random_forest_classifier.fit(X_train, y_train)
gradient_boosting_classifier.fit(X_train, y_train)
naive_bayes_classifier.fit(X_train, y_train)

# evaluate model performance
y_pred = random_forest_classifier.predict(X_test)
f1_random_forest_classifier = round(f1_score(y_test, y_pred), 3)
y_pred = gradient_boosting_classifier.predict(X_test)
f1_gradient_boosting_classifier = round(f1_score(y_test, y_pred), 3)
y_pred = naive_bayes_classifier.predict(X_test)
f1_naive_bayes_classifier = round(f1_score(y_test, y_pred), 3)


# In[6]:


conventional_approach = {'Random forest classifier': f1_random_forest_classifier,
                         'Gradient boosting classifier': f1_gradient_boosting_classifier,
                         'Naive bayes classifier': f1_naive_bayes_classifier}


for classifier, f1 in conventional_approach.items():
    print(f"{'{} (f1-score):'.format(classifier):<42}{f1:>1}")

