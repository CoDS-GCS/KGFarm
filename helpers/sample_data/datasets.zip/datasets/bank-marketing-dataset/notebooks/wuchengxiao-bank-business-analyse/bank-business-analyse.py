#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 5GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# # Catalog
# > ## Section Ⅰ Business analyse(业务分析)
# >> ###   1.1  Basic attributes(基本属性)
# >> ###   1.2  Business contact（业务联系）
# >> ###   1.3  Marketing activities（营销活动）
# >> ###   1.4  Target data(目标数据)
# > ## Section Ⅱ Basic data processing(数据基本处理)
# >> ###   2.1  data description(数据描述)
# >> ###   2.2  Data cleaning and filtering(数据清洗及过滤)
# > ## Section Ⅲ EDA
# >> ###   3.1  Job
# >> ###   3.2  Balance
# >> ###   3.3  Marital
# >> ###   3.4  Education
# >> ###   3.5  Housing and Loan
# >> ###   3.6  Deposit
# > ## Section Ⅳ Marketing analysis
# >> ###   4.1  Deposit business user age（存款业务用户年龄）
# >> ###   4.2  Deposit business user job（存款业务用户职业）
# >> ###   4.3  Marketing month analysis（营销月份分析）
# > ## Section Ⅴ Prediction Model
# >> ###   5.1  Logistic Regression Model（逻辑回归模型）
# >> ###   5.2  Random Forest model（随机森林模型）
# > ## Section Ⅵ Summary

# # Section Ⅰ Business analyse
# 

# In[ ]:


import numpy as np
import pandas as pd
import seaborn as sns 
import matplotlib.pyplot as plt

# In[ ]:


df=pd.read_csv('../input/bank-marketing-dataset/bank.csv')
df.head()

# In[ ]:


df.info()
df.shape

# # A total of 11162 rows and 17 columns of data are defined as follows:
# # 共有11162行和17列数据，定义如下：

# # 1.1 Basic attributes（基本属性）
# > age：年龄<p>
#     > job：工作岗位<p>
#        > marital：婚姻状态<p>
#          > education：教育程度<p>
#             > defalut：是否违约<p>
#                > balance：盈余<p>
#                  > housing：是否有住房贷款<p>
#                     > loan：是否有个人贷款<p>
# # 1.2 Business contact（业务联系）
# > contact：联系方式<p> 
#     >day:上一个联系日 <p>
#         > month：上一个联系月<p>
#             > duration：通话时间，秒<p>
# # 1.3 Marketing activities（营销活动）
# > campain：上一次营销活动和此客户联系的次数<p>
#     >pdays：自上一次营销活动联系后，至今的天数<p>
#         >previous：上一次营销活动之前和客户累计联系过的次数<p>
#             >poutcome：上一次营销的结果
# # 1.4 target data(目标数据)
# >deposit：客户是否有定期存款？

# # Section Ⅱ Business analyse

#  # 2.1 data description(数据描述)

# In[ ]:


df.describe()

# * # The average age of clients is about 41 years old, the highest is 95 years old, and the lowest is 18 years old;
# # 客户平均年龄41岁左右，最高95岁，最低18岁；
# * # The average customer banlance is 1528, but the standard deviation is very large, indicating that the distribution of this data is very scattered.
# # 平均客户盈余为1528，但标准差非常大，说明这一数据的分布非常分散。
# * # The number of contacts in the last marketing activity ranged from 1 to 63, and the more the corresponding contact times, the higher the customer's participation in the previous campaign was;
# # 上一次营销活动中的联系次数为1-63次，对应的联系次数越多，客户对上一次活动的参与度越高；
# * # The number of days since the last marketing campaign is - 1 ~ 854 days. Why is there - 1? Whether it is data error or not;
# # 上次营销活动后的天数为-1~854天。为什么有-1？是否数据错误；
# * # The cumulative number of contact with customers before the last marketing campaign is 0 ~ 58
# # 上次营销活动前与客户的累计接触次数为0~58次

# # 2.2  Data cleaning and filtering(数据清洗及过滤)

# In[ ]:


df.isnull().sum()

# # We can find that there is no missing data in this data, so there is no need to interpolate the data. The only problem is that the "- 1" in pdays is not cleaned.
# # 我们可以发现这些数据中没有丢失的数据，因此不需要对数据进行插值。唯一的问题是pdays中的“-1”没有被清理。

# # Section Ⅲ EDA

# # 3.1 Job

# In[ ]:


plt.figure(figsize=(20,12))
plt.subplot(211)
sns.countplot(x = 'job', data = df, order = df['job'].value_counts().index)
plt.subplot(212)
sns.boxplot(x='job',y='age',data=df)

# * # Management is the most common job type;
# #  管理是最常见的工作类型；
# * # Retired people are older than other jobs and students are the youngest;
# # 退休人员比其他工作年龄大，学生年龄最小；
# * # Retired people have the most balance。
# # 退休的人有最多的盈余
# # //the better chart is stacked column chart，we can cut the balance as high,mid,low three type,and see the proportion that every type of job have<p>
# # //比较好的图表是堆积柱形图，我们可以把平衡分为高、中、低三种类型，看每种工作所占的比例

# # 3.2  Balance

# In[ ]:


plt.figure(figsize=(15,8))
sns.boxplot(x='default',y='balance',hue='deposit',data=df)

# In[ ]:


plt.figure(figsize=(15,8))
sns.boxplot(x='job',y='balance',hue='deposit',data=df)

# In[ ]:


plt.figure(figsize=(15,8))
sns.boxplot(x='education',y='balance',hue='deposit',data=df)

# * # The balance of people with default record is obviously low, which indicates that their economic situation is not very good;
# # 有违约记录的人员盈余明显偏低，说明他们的经济状况不是很好；
# * # There are several jobs that are better off financially: retired,technician,blue-collar,self-employed
# # 有几种工作在经济上比较好：retired,technician,blue-collar,self-employed
# * # Different from the forecast, the level of education does not significantly affect the level of economic balance
# # 与预测不同的是，受教育程度对balance水平的影响并不显著

# # 3.3  Marital

# In[ ]:


plt.figure(figsize=(15,8))
sns.countplot('marital', data = df)

# In[ ]:


plt.figure(figsize=(20,6))
plt.subplot(311)
plt.title('Price Distrubution by Martial Status',fontsize=20)
sns.distplot(df[df.marital=='married'].balance)
plt.ylabel('married')
plt.subplot(312)
sns.distplot(df[df.marital=='divorced'].balance)
plt.ylabel('divorced')
plt.subplot(313)
sns.distplot(df[df.marital=='single'].balance)
plt.ylabel('single')

# #  We can see that the marital status has no correlation with the balance, and the distribution difference is not big. which is basically between 0 and 10000, but the married people will have a higher value in the balance<p>
# # 我们可以看出婚姻状态对于盈余而言没有什么相关性，分布差别也不大。基本都是在0-10000，只不过结婚的人在盈余上会有更高的值

# # 3.4  Education

# In[ ]:


plt.figure(figsize=(8,16))
group = df.groupby('education')
med_balance = group.aggregate({'balance':np.median}).sort_values('balance', ascending = False)
print(med_balance)
sns.boxplot(x = 'education', y = 'balance', data = df,order = med_balance.index, color = 'steelblue')

# # There seems to be little difference in the surplus status among different education levels, because the median value of concentrated surplus is almost the same<p>
# # 不同教育程度的盈余状况似乎相差不大，因为集中盈余状态的中值都差不多.

# # 3.5  Housing and Loan

# In[ ]:


plt.rcParams['figure.figsize']=(20,10)
plt.subplot(121)
sns.stripplot(x='housing',y='balance',data=df)
plt.subplot(122)
sns.stripplot(x='loan',y='balance',data=df)

# # With or without housing loans and personal loans will greatly affect the balance, and those without housing loans and personal loans will have more banlance.
# # 有无住房贷款和个人贷款会很大程度影响盈余，没有住房贷款和个人贷款的将具有更多的盈余。

# In[ ]:


dp=df.deposit.value_counts()
plt.figure(figsize=(16,8))
plt.subplot(1,2,1)
labels = ['Have depoist','No deposit']
explode=[0.05,0.05]
plt.pie(dp,
labels=labels,
explode=explode,
autopct='%.2f%%',
pctdistance=0.5,
shadow=True,
wedgeprops= {'linewidth':1,'edgecolor':'green'},
labeldistance = 1.1,
textprops=dict(color='k',  #  字体颜色                    
               fontsize=15),
startangle=30),
plt.legend(bbox_to_anchor=(1.0, 1.0), loc=1, borderaxespad=0,fontsize=12)
plt.title('Deposit',fontsize=20)
plt.subplot(1,2,2)
sns.barplot(x="education", y="balance", hue="deposit", data=df, estimator=lambda x: len(x) / len(df)*100)
plt.ylabel('(%)')
plt.show()

# # It can be seen that the higher the education level, the more tend to have deposit,and the greater proportion in the banking business.<p>
# # 这里可以看出，受教育程度越高，越趋向于拥有存款，且在银行的业务中占比也越重。

# # Section Ⅳ Marketing analysis

# # 4.1  Deposit business user age（存款业务用户年龄）

# In[ ]:


#画有无定期存款的各年龄段分布状况
plt.figure(figsize=(16,8))
plt.subplot(211)
sns.distplot(df[df.deposit=='yes'].age)
#distplot和barplot的区别：distplot是会自动按照区间比例画柱状图及其趋势线，而barplot则是通常要取确定数值或数值的均值绘图，而不能反映数据分布。
plt.ylabel('deposit=yes')
plt.subplot(212)
sns.distplot(df[df.deposit=='no'].age)
plt.ylabel('deposit=no')

# # It can be seen that the main deposit business crowd is 20-60 years old
# # 可以看出主要的存款业务人群集中在20~60岁

# In[ ]:


#同样对不同的年龄层，是否有定期存款的分类所占比例画图，所以要按年龄划分年龄层
data=df
data['age_status']=data['age']
def agerank(age):
    if age<20:
        age_status='teen'
    elif age>=20 and age<30:
        age_status='young'
    elif age>=30 and age<40:
        age_status='mid'
    elif age>=40 and age<60:
        age_status='mid_old'
    else:age_status='old'
    return age_status
data.age_status=data.age_status.transform(lambda x:agerank(x))
data1=(data.groupby(['age_status','deposit']).age.count()/data.groupby(['age_status']).age.count()).to_frame().reset_index() 
#reset_index()将会将原来的索引index作为新的一列，否则标识数字的属性部分不会成为列
sns.barplot(x='age_status',y='age',data=data1,hue='deposit')
#age在这一部分实际上已经变为了百分比，而不是原来的数值，上一个语句因为是把age分类了，并没有换属性名，所以现实的是百分比
plt.ylabel('(%)')
data1

# # It can be seen that people after the age of 20 are happy to have deposit, while the younger people under 20 are more likely to have no deposit.
# # 可以看出20岁之后的人乐于拥有存款，而20岁以下年轻人则更大多数是没有存款的。

# In[ ]:


#原理同上，同样对不同的年龄层，上一次营销的结果的分类所占比例画图
data2=(data[data.poutcome!='unknown'].groupby(['age_status','poutcome']).age.count()/data.groupby(['age_status']).age.count()).to_frame().reset_index() 
sns.barplot(x='age_status',y='age',data=data2,hue='poutcome')
plt.ylabel('(%)')
data2

# # It can be seen that the marketing results for the elderly (over 60 years old) and young people (under 20 years old) marketing success rate is higher, even in young people will not fail. But with the growth of age, until the middle-aged (30-40 years old) stage, the marketing failure rate will rise, after that, with the further growth of age, the marketing failure rate will start to decrease.
# # 可以看出，营销的结果对于老年人（60岁以上）和年轻人（20岁以下）的营销成功率更高，在年轻人中甚至不会失败。但是随着年龄的增长，直到中年人（30~40岁）阶段，营销的失败率会攀升，在此之后，随着年龄的进一步增长，营销失败率又会开始降低。<p>
# #     To sum up, the key marketing targets of banks should be those under 20 years old and over 60 years old.But the 20-to-60-year-old group is the main customer group of the bank, so their feelings also need to be considered.
# # 综上可知，银行的重点营销对象应当是20岁以下和60岁以上的群体。但是20到60岁的群体是银行的主要顾客群体，也需要考虑到他们的感受。

# # 4.2  Deposit business user job（存款业务用户职业）

# In[ ]:


data['percent']=1 #添加新的一列全为1的值，
data3=(data.groupby(['job','deposit']).percent.count()/data.groupby(['job']).percent.count()).to_frame().reset_index()
data4=(data[data.poutcome!='unknown'].groupby(['job','poutcome']).percent.count()/data.groupby(['job']).percent.count()).to_frame().reset_index()

plt.subplot(211)
sns.barplot(x='job',y='percent',data=data3,hue='deposit')
plt.subplot(212)
sns.barplot(x='job',y='percent',data=data4,hue='poutcome')

# * # students and retirees are more likely to have deposits and succeed in marketing;
# * # 学生及退休人员更加可能有定期存款，同时在营销方面取得成功；
# * # Blue collar workers, entrepreneurs, service providers and technicians are not easy to sell successfully
# * # 蓝领、企业家、服务者、技术员不容易推销成功

# # 4.3 Marketing month analysis（营销月份分析）

# In[ ]:


import datetime
# date=bank.pdays
now=datetime.datetime.today()
bank_date=df
bank_date['compain_date']=bank_date.pdays.transform(lambda x:now-datetime.timedelta(days=x))
bank_date['month']=bank_date['compain_date'].transform(lambda x:x.strftime('%m'))
plt.bar(bank_date['month'].value_counts().index,bank_date['month'].value_counts())
plt.xlabel('month')

# In[ ]:


data=bank_date.groupby(['month','poutcome']).count().reset_index()
sns.barplot(x='month',y='age',data=data,hue='poutcome')

# # It can be seen from the above two pictures that the number of marketing activities in July is the most. However, since many marketing activities in July are actually of unkown's, it is necessary to exclude unkown from drawing again.
# # 从以上两张图可以看到七月份的营销活动最多，但是由于7月份有很多营销活动其实是unkown的，所以要排除unkown重新作图。

# In[ ]:


sns.barplot(x='month',y='age',data=data[data['poutcome']!='unknown'],hue='poutcome')

# # Redrawing makes it clearer to see the correlation between months and the number of marketing activities, as well as success stories
# # 重新作图可以更清楚的让我们看到月份与营销活动次数，以及成功案例的相关性

# # It can be concluded that:
# # 可以综合得知：
# > # Marketing activities are mainly concentrated in January, April and August;
# # 营销活动主要集中在1月、4月、8月；

# # Section Ⅴ Prediction Model

# # Because it is a classification event to decide whether a person will have a deposit, we think of the construction model in machine learning. One is the simplest logical regression model based on the correlation of numerical variables, and the other is the random forest model, in which the relevant numerical variables and classification variables are included in the model.
# # 由于决定一个人是否会有存款是属于一个分类事件，所以我们在机器学习中想到的建构模型，一个是最简单的根据数值变量的相关性建立逻辑回归模型，另外一个则是随机森林模型，将相关的数值变量与分类变量都纳入到模型中预测。
# 

# # 5.1  Logistic Regression Model（逻辑回归模型）

# In[ ]:


from sklearn.preprocessing import LabelEncoder
data5=df
data5['deposit']=LabelEncoder().fit_transform(data5['deposit'])
#把deposit转化为数值变量
cancel_corr = df.corr()["deposit"]
cancel_corr.abs().sort_values(ascending = False)

# In[ ]:


from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
# preprocessing
data5 = data5[data5['deposit'].notna()]
features = ['duration', 'pdays', 'previous', 'campaign','balance']
X = data5[features]
Y = data5["deposit"]
# missing value with median
num_transformer = SimpleImputer(strategy="median")
num_transformer.fit_transform(X)
# extract training data (80%) and test data (20%)
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20, random_state=42)
logreg = LogisticRegression()
logreg.fit(X_train, Y_train)

# In[ ]:


Y_pred=logreg.predict(X_test)
# get confusion matrix
cnf_matrix = metrics.confusion_matrix(Y_test, Y_pred)
# visualize confusion matrix
class_names=[0,1] # name  of classes
fig, ax = plt.subplots()
tick_marks = np.arange(len(class_names))
plt.xticks(tick_marks, class_names)
plt.yticks(tick_marks, class_names)
# create heatmap
sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu" ,fmt='g')
ax.xaxis.set_label_position("top")
plt.tight_layout()
plt.title('Confusion matrix', y=1.1)
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
# accuracy, percision, recall
print("Accuracy:",metrics.accuracy_score(Y_test, Y_pred))
print("Precision:",metrics.precision_score(Y_test, Y_pred))
print("Recall:",metrics.recall_score(Y_test, Y_pred))

# # After several parameter adjustments, we found that the parameters we selected in the simple logistic regression model : duration, pdays, previous, campaign,balance。if the parameters are too many, it will affect the prediction of the model.
# # 经过几次参数调整发现，我们在简单逻辑回归模型中选择的参数有：duration, pdays, previous, campaign,balance，如果参数过多，则反而会影响模型预测。
# 
# # In fact, we can see that in the simple logistic regression prediction model, Accuracy rate,Precision rate ，Recall rate are not very ideal. Therefore, we can generally construct a more ideal random forest model.
# # 其实可以看到，在简单的逻辑回归预测模型中，准确率，精确率，召回率的百分比都不算很理想。所以我们可以一般而言建构分类模型更理想的随机森林模型。

# # 5.2  Random Forest model（随机森林模型）

# In[ ]:


from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
num_features = ['duration', 'pdays', 'previous', 'campaign','balance','day','age']
cat_features = ['job','marital','education', 'default','housing','loan','contact','poutcome','month']
features = num_features + cat_features
X = df.drop(["deposit"], axis=1)[features]
y = df["deposit"]
num_transformer = SimpleImputer(strategy="constant", fill_value=0)
# deal with categorical data
cat_transformer = Pipeline(steps = [("imputer", SimpleImputer(strategy="constant", fill_value="unkown")), 
                                   ("onehot", OneHotEncoder(handle_unknown="ignore"))])
preprocessor = ColumnTransformer(transformers=[("num", num_transformer, num_features),
                                               ("cat", cat_transformer, cat_features)])

# In[ ]:


from sklearn.ensemble import RandomForestClassifier
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.8, random_state=0)
model = Pipeline(steps=[('preprocessor', preprocessor),('rf', RandomForestClassifier(random_state=42,n_jobs=-1))])
model.fit(X_train, y_train)
pred = model.predict(X_test)

# In[ ]:


cnf_matrix = metrics.confusion_matrix(y_test, pred)
# visualize confusion matrix
class_names=[0,1] # name  of classes
fig, ax = plt.subplots()
tick_marks = np.arange(len(class_names))
plt.xticks(tick_marks, class_names)
plt.yticks(tick_marks, class_names)
# create heatmap
sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu" ,fmt='g')
ax.xaxis.set_label_position("top")
plt.tight_layout()
plt.title('Confusion matrix', y=1.1)
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
# accuracy, percision, recall
print("Accuracy:",metrics.accuracy_score(y_test, pred))
print("Precision:",metrics.precision_score(y_test, pred))
print("Recall:",metrics.recall_score(y_test, pred))

# # It can be clearly seen that the accuracy rate of the random forest prediction model is 81.59%, the accuracy rate is 79.86%, and the recall rate is 81.46%. All indicators are far better than the simple logistic regression prediction model, so we choose the random forest model in the banking business forecast.
# # 可以很明显的看出，随机森林预测模型的构建的准确率为81.59%，精准率为79.86%，召回率为81.46%，各项指标都远好于简单的逻辑回归预测模型，因此在银行业务预测中选择随机森林模型。

# # Section Ⅵ Summary
