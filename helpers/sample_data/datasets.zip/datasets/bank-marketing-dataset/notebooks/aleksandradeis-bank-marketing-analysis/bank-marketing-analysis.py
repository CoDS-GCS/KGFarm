#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#import linear algebra and data manipulation libraries
import numpy as np
import pandas as pd

#import standard visualization
import matplotlib.pyplot as plt
import seaborn as sns

#import machine learning
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB

import xgboost

from sklearn.model_selection import train_test_split #split
from sklearn.metrics import accuracy_score #metrics

#tools for hyperparameters search
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV

import os
print(os.listdir("../input"))

# Any results you write to the current directory are saved as output.

# ## Introduction

# Today organizations, which hire data scientists are especially interested in job candidate's portfolio. Analysis of organization's marketing data is one of the most typical applications of data science and machine learning. Such analysis will definetely be a nice contribution to the protfolio.

# In general, datasets which contain marketing data can be used for 2 different business goals:
# 1. Prediction of the results of the marketing campaign for each customer and clarification of factors which affect the campaign results. This helps to find out the ways how to make marketing campaigns more efficient.
# 2. Finding out customer segments, using data for customers, who subscribed to term deposit. This helps to identify the profile of a customer, who is more likely to acquire the product and develop more targeted marketing campaigns.

# This dataset contains banking marketing campaign data and we can use it to optimize marketing campaigns to attract more customers to term deposit subscription.
# Detailed description of the dataset's content is describe in this  [kaggle kernel](https://www.kaggle.com/janiobachmann/marketing-in-banking-opening-term-deposits).

# ## Approach

# In order to optimize marketing campaigns with the help of the dataset, we will have to take the following steps:
# 1. Import data from dataset and perform initial high-level analysis: look at the number of rows, look at the missing values, look at dataset columns and their values respective to the campaign outcome.
# 2. Clean the data: remove irrelevant columns, deal with missing and incorrect values, turn categorical columns into dummy variables.
# 3. Use machine learning techniques to predict the marketing campaign outcome and to find out factors, which affect the success of the campaign.

# ## Import Data

# First of all to perform the analysis, we have to import the data:

# In[ ]:


#import dataset

df = pd.read_csv('../input/bank.csv')

# In[ ]:


df.head()

# ## Data Exploration

# After we imported the dataset, we have to look at the total number of rows in the dataset and analyze the number of missing values.

# In[ ]:


# number of rows in dataset

print("Bank marketing dataset consists of {rows} rows.".format(rows = len(df)))

# In[ ]:


#find percentage of missing values for each column
missing_values = df.isnull().mean()*100

missing_values.sum()

# So we see that there are no missing values.

# ### Categorical columns exploration

# In the dataset we have both categorical and numerical columns. Let's look at the values of categorical columns first.

# In[ ]:


cat_columns = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'month','poutcome']

fig, axs = plt.subplots(3, 3, sharex=False, sharey=False, figsize=(20, 15))

counter = 0
for cat_column in cat_columns:
    value_counts = df[cat_column].value_counts()
    
    trace_x = counter // 3
    trace_y = counter % 3
    x_pos = np.arange(0, len(value_counts))
    
    axs[trace_x, trace_y].bar(x_pos, value_counts.values, tick_label = value_counts.index)
    
    axs[trace_x, trace_y].set_title(cat_column)
    
    for tick in axs[trace_x, trace_y].get_xticklabels():
        tick.set_rotation(90)
    
    counter += 1

plt.show()

# ### Numerical columns exploration

# Now let's look at the numerical columns' values. The most convenient way to look at the numerical values is plotting histograms.

# In[ ]:


num_columns = ['balance', 'day','duration', 'campaign', 'pdays', 'previous']

fig, axs = plt.subplots(2, 3, sharex=False, sharey=False, figsize=(20, 15))

counter = 0
for num_column in num_columns:
    
    trace_x = counter // 3
    trace_y = counter % 3
    
    axs[trace_x, trace_y].hist(df[num_column])
    
    axs[trace_x, trace_y].set_title(num_column)
    
    counter += 1

plt.show()

# We can see that numerical columns have outliers (especially 'pdays', 'campaign' and 'previous' columns). Possibly there are incorrect values (noisy data), so we should look closer at the data and decide how do we manage the noise.
# <br> Let's look closer at the values of 'campaign', 'pdays' and 'previous' columns:

# In[ ]:


df[['pdays', 'campaign', 'previous']].describe()

# Percentage of 'pdays' values above 400:

# In[ ]:


len (df[df['pdays'] > 400] ) / len(df) * 100

# 'pdays' holds the number of days that passed by after the client was last contacted from a previous campaign
# Looking closer into 'pdays' data we can see that:
# * only 1.2% of values above 400. They are possibly outliers, so we should consider imputing something (possibly mean value) instead of these values.
# * -1 possibly means that the client wasn't contacted before or stands for missing data.
# 
# Since we are not sure exactly what -1 means I suggest to drop this column, because -1 makes more than 50% of the values of the column.

# Percentage of 'campaign' values above 20:

# In[ ]:


len (df[df['campaign'] > 34] ) / len(df) * 100

# 'campaign' holds the number of contacts performed during this campaign and for this client (numeric, includes last contact)
# Numbers for 'campaign' above 34 are clearly noise, so I suggest to impute them with average campaign values while data cleaning.

# Percentage of 'previous' values above 20:

# In[ ]:


len (df[df['previous'] > 34] ) / len(df) * 100

# 'previous' holds the number of contacts performed before this campaign and for this client (numeric)
# Numbers for 'previous' above 34 are also really strange, so I suggest to impute them with average campaign values while data cleaning.

# ### Analysis of the response column

# It is very important to look at the response column, which holds the information, which we are going to predict. In our case we should look at 'deposit' column and compare its values to other columns. 
# <br> First of all we should look at the number of 'yes' and 'no' values in the response column 'deposit'.

# In[ ]:


value_counts = df['deposit'].value_counts()

value_counts.plot.bar(title = 'Deposit value counts')

# On the diagram we see that counts for 'yes' and 'no' values for 'deposit' are close, so we can use accuracy as a metric for a model, which predicts the campaign outcome.

# Let's see how 'deposit' column value varies depending on other categorical columns' values:

# In[ ]:


#job and deposit
j_df = pd.DataFrame()

j_df['yes'] = df[df['deposit'] == 'yes']['job'].value_counts()
j_df['no'] = df[df['deposit'] == 'no']['job'].value_counts()

j_df.plot.bar(title = 'Job and deposit')

# In[ ]:


#marital status and deposit
j_df = pd.DataFrame()

j_df['yes'] = df[df['deposit'] == 'yes']['marital'].value_counts()
j_df['no'] = df[df['deposit'] == 'no']['marital'].value_counts()

j_df.plot.bar(title = 'Marital status and deposit')

# In[ ]:


#education and deposit
j_df = pd.DataFrame()

j_df['yes'] = df[df['deposit'] == 'yes']['education'].value_counts()
j_df['no'] = df[df['deposit'] == 'no']['education'].value_counts()

j_df.plot.bar(title = 'Education and deposit')

# In[ ]:


#type of contact and deposit
j_df = pd.DataFrame()

j_df['yes'] = df[df['deposit'] == 'yes']['contact'].value_counts()
j_df['no'] = df[df['deposit'] == 'no']['contact'].value_counts()

j_df.plot.bar(title = 'Type of contact and deposit')

# Regarding the diagrams we can tell that according to our dataset:
# 1. Customers with 'blue-collar' and 'services' jobs are less likely to subscribe for term deposit.
# 2. Married customers are less likely to subscribe for term deposit.
# 3. Customers with 'cellular' type of contact are less likely to subscribe for term deposit.

# Now let's look how numerical columns affect term deposit subscription.

# In[ ]:


#balance and deposit

b_df = pd.DataFrame()
b_df['balance_yes'] = (df[df['deposit'] == 'yes'][['deposit','balance']].describe())['balance']
b_df['balance_no'] = (df[df['deposit'] == 'no'][['deposit','balance']].describe())['balance']

b_df

# In[ ]:


b_df.drop(['count', '25%', '50%', '75%']).plot.bar(title = 'Balance and deposit statistics')

# In[ ]:


#age and deposit

a_df = pd.DataFrame()
a_df['age_yes'] = (df[df['deposit'] == 'yes'][['deposit','age']].describe())['age']
a_df['age_no'] = (df[df['deposit'] == 'no'][['deposit','age']].describe())['age']

a_df

# In[ ]:


a_df.drop(['count', '25%', '50%', '75%']).plot.bar(title = 'Age and deposit statistics')

# In[ ]:


#number of contacts performed during this campaign ('campaign') and deposit
c_df = pd.DataFrame()
c_df['campaign_yes'] = (df[df['deposit'] == 'yes'][['deposit','campaign']].describe())['campaign']
c_df['campaign_no'] = (df[df['deposit'] == 'no'][['deposit','campaign']].describe())['campaign']

c_df

# In[ ]:


c_df.drop(['count', '25%', '50%', '75%']).plot.bar(title = 'Number of contacts performed during this campaign and deposit statistics')

# In[ ]:


#number of contacts performed during previous campaign ('previous') and deposit
p_df = pd.DataFrame()
p_df['previous_yes'] = (df[df['deposit'] == 'yes'][['deposit','previous']].describe())['previous']
p_df['previous_no'] = (df[df['deposit'] == 'no'][['deposit','previous']].describe())['previous']

p_df

# In[ ]:


p_df.drop(['count', '25%', '50%', '75%']).plot.bar(title = 'Number of contacts performed during previous campaign and deposit statistics')

# Looking at the diagrams above we can conclude that:
# 1. People who subscribed for term deposit tend to have greater balance and age values.
# 2. People who subscribed for term deposit tend to have fewer number of contacts during this campaign.

# ## Data Cleaning

# Before we will be able to apply machine learning techniques, we should prepare the dataset for processing:
# 1. Convert columns with 'yes' and 'no' values to boolean columns;
# 2. Convert categorical columns into dummy variables.

# In[ ]:


def get_dummy_from_bool(row, column_name):
    ''' Returns 0 if value in column_name is no, returns 1 if value in column_name is yes'''
    return 1 if row[column_name] == 'yes' else 0

def get_correct_values(row, column_name, threshold, df):
    ''' Returns mean value if value in column_name is above threshold'''
    if row[column_name] <= threshold:
        return row[column_name]
    else:
        mean = df[df[column_name] <= threshold][column_name].mean()
        return mean

def clean_data(df):
    '''
    INPUT
    df - pandas dataframe containing bank marketing campaign dataset
    
    OUTPUT
    df - cleaned dataset:
    1. columns with 'yes' and 'no' values are converted into boolean variables;
    2. categorical columns are converted into dummy variables;
    3. drop irrelevant columns.
    4. impute incorrect values
    '''
    
    cleaned_df = df.copy()
    
    #convert columns containing 'yes' and 'no' values to boolean variables and drop original columns
    bool_columns = ['default', 'housing', 'loan', 'deposit']
    for bool_col in bool_columns:
        cleaned_df[bool_col + '_bool'] = df.apply(lambda row: get_dummy_from_bool(row, bool_col),axis=1)
    
    cleaned_df = cleaned_df.drop(columns = bool_columns)
    
    #convert categorical columns to dummies
    cat_columns = ['job', 'marital', 'education', 'contact', 'month', 'poutcome']
    
    for col in  cat_columns:
        cleaned_df = pd.concat([cleaned_df.drop(col, axis=1),
                                pd.get_dummies(cleaned_df[col], prefix=col, prefix_sep='_',
                                               drop_first=True, dummy_na=False)], axis=1)
    
    #drop irrelevant columns
    cleaned_df = cleaned_df.drop(columns = ['pdays'])
    
    #impute incorrect values and drop original columns
    cleaned_df['campaign_cleaned'] = df.apply(lambda row: get_correct_values(row, 'campaign', 34, cleaned_df),axis=1)
    cleaned_df['previous_cleaned'] = df.apply(lambda row: get_correct_values(row, 'previous', 34, cleaned_df),axis=1)
    
    cleaned_df = cleaned_df.drop(columns = ['campaign', 'previous'])
    
    return cleaned_df

# In[ ]:


#clean the dataset
cleaned_df = clean_data(df)
cleaned_df.head()

# ## Machine Learning for prediction of campaign outcome

# ### Classification model for the campaign outcome prediction

# Now let's use cleaned datasets for prediction of campaign outcome with help of machine learning classification models. I will use __[XGBoost](https://xgboost.readthedocs.io/en/latest/)__, which is one of the most common machine learning libraries for modelling.
# <br> Resulting model will also help me to understand, which features have the greatest importance for the prediction of the results of the campaing.

# Create X and y datasets for training the model and split into train and test datasets.

# In[ ]:


X = cleaned_df.drop(columns = 'deposit_bool')
y = cleaned_df[['deposit_bool']]

# In[ ]:


TEST_SIZE = 0.3
RAND_STATE = 42

# In[ ]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = TEST_SIZE, random_state=RAND_STATE)

# Train XGBoost classifier model:

# In[ ]:


#train XGBoost model
xgb = xgboost.XGBClassifier(n_estimators=100, learning_rate=0.08, gamma=0, subsample=0.75,
                           colsample_bytree=1, max_depth=7)
xgb.fit(X_train,y_train.squeeze().values)

#calculate and print scores for the model for top 15 features
y_train_preds = xgb.predict(X_train)
y_test_preds = xgb.predict(X_test)

print('XGB accuracy score for train: %.3f: test: %.3f' % (
        accuracy_score(y_train, y_train_preds),
        accuracy_score(y_test, y_test_preds)))

# Get the feature importances from the trained model:

# In[ ]:


#get feature importances from the model
headers = ["name", "score"]
values = sorted(zip(X_train.columns, xgb.feature_importances_), key=lambda x: x[1] * -1)
xgb_feature_importances = pd.DataFrame(values, columns = headers)

#plot feature importances
x_pos = np.arange(0, len(xgb_feature_importances))
plt.bar(x_pos, xgb_feature_importances['score'])
plt.xticks(x_pos, xgb_feature_importances['name'])
plt.xticks(rotation=90)
plt.title('Feature importances (XGB)')

plt.show()

# As we can see from the diagram showing feature importances, the most important features are:
# * Customer's account balance,
# * Customer's age,
# * Number of contacts performed during this campaign and contact duration,
# * Number of contacts performed before this campaign.

# So the main outcomes of the modelling are:
# * Customers of greater age are more likely to subscribe for the term deposit.
# * Customers with greater account balance are more likely to subscribe for the term deposit.
# * Number of contacts with the customers really matters. Too many contacts with the customer could make him decline the offer.

# Let's try to make more specific recommendations:

# 1. Find out account balance, which marketing campaign should focus on: 

# In[ ]:


df_new = cleaned_df.copy()

#introduce new column 'balance_buckets' to  ''
df_new['balance_buckets'] = pd.qcut(df_new['balance'], 50, labels=False, duplicates = 'drop')

#group by 'balance_buckets' and find average campaign outcome per balance bucket
mean_deposit = df_new.groupby(['balance_buckets'])['deposit_bool'].mean()

#plot
plt.plot(mean_deposit.index, mean_deposit.values)
plt.title('Mean % subscription depending on account balance')
plt.xlabel('balance bucket')
plt.ylabel('% subscription')
plt.show()

# In[ ]:


df_new[df_new['balance_buckets'] == 34]['balance'].min()

# From the diagram above we can conclude, that marketing campaigns should concentrate on customers with account balance greater than 1490$.

# In[ ]:


#introduce new column 'age_buckets' to  ''
df_new['age_buckets'] = pd.qcut(df_new['age'], 20, labels=False, duplicates = 'drop')

#group by 'balance_buckets' and find average campaign outcome per balance bucket
mean_age = df_new.groupby(['age_buckets'])['deposit_bool'].mean()

#plot
plt.plot(mean_age.index, mean_age.values)
plt.title('Mean % subscription depending on age')
plt.xlabel('age bucket')
plt.ylabel('% subscription')
plt.show()

# In[ ]:


df_new[df_new['age_buckets'] == 3]['age'].max()

# In[ ]:


df_new[df_new['age_buckets'] == 17]['age'].min()

# So we see that average subscrition rate tends to be higher for customers below 31 years old or above 56 years old.

# 3. Find out appropriate number of contacts with the customer during campaign:

# In[ ]:


#introduce new column 'age_buckets' to  ''
df_new['campaign_buckets'] = pd.qcut(df_new['campaign_cleaned'], 20, labels=False, duplicates = 'drop')

#group by 'balance_buckets' and find average campaign outcome per balance bucket
mean_campaign = df_new.groupby(['campaign_buckets'])['deposit_bool'].mean()

#plot average campaign outcome per bucket 
plt.plot(mean_campaign.index, mean_campaign.values)
plt.title('Mean % subscription depending on number of contacts')
plt.xlabel('number of contacts bucket')
plt.ylabel('% subscription')
plt.show()

# In[ ]:


df_new[df_new['campaign_buckets'] == 2]['campaign_cleaned'].min()

# From the plot above we see that average subscription rate is below 50% if the number of contacts during the campaign exceeds 4.

# ## Conclusion

# Key outcomes of the analysis are the recommendations for future marketing campaigns:
# * The customer's account balance has a huge influence on the campaign's outcome. People with account balance above 1490$ are more likely to subscribe for term deposit, so future address those customers.
# * The customer's age affects campaign outcome as well. Future campains should concentrate on customers from age categories below 30 years old and above 50 years old.
# * Number of contacts with the customer during the campaign is also very important. The number of contacts with the customer shouldn't exceed 4.
