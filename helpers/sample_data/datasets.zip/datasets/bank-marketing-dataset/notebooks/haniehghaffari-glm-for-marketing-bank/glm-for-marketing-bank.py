#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis,QuadraticDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression

# In[ ]:


df  =pd.read_csv('../input/bank-marketing-dataset/bank.csv')

# In[ ]:


df.head()

# In[ ]:


df.describe()

# In[ ]:


x = df[:-1]
y= df['deposit']

# In[ ]:


z = df['deposit'].value_counts()

# In[ ]:


plt.bar(df['marital'],df['deposit'],color='y',edgecolor='g');

# In[ ]:


df['deposit'].value_counts()

# In[ ]:



plt.pie(df['deposit'].value_counts(),explode=[0,0.25],labels =['no','yes'] );


# In[ ]:


sns.boxplot('deposit','age',data=df);

# In[ ]:


sns.boxplot('deposit','duration',data=df);

# In[ ]:


sns.barplot(hue = 'deposit',x = 'education',y='balance',data=df);

# In[ ]:


sns.barplot(x='marital',y='age',hue='deposit',data=df);

# In[ ]:


fullmodel =smf.glm('deposit~ age+job+marital+education+default+balance+housing+loan+contact+day+month+duration+campaign+previous+poutcome ',family=sm.families.Binomial(),data=df).fit()
# fullmodel.summary()

# In[ ]:


fullmodel.deviance

# In[ ]:


reducemodel = smf.glm('deposit~1',family= sm.families.Binomial(),data=df).fit()
# reducemodel.summary()

# In[ ]:


reducemodel.deviance

# In[ ]:


df.head()

# In[ ]:


df.columns

# In[ ]:


df['job']=pd.get_dummies(df['job'])
df['marital'] =pd.get_dummies(df['marital'])
df['education']=pd.get_dummies(df['education'])
df['default']=pd.get_dummies(df['default'])
df['housing']=pd.get_dummies(df['housing'])
df['loan']=pd.get_dummies(df['loan'])
df['day']=pd.get_dummies(df['day'])
df['month']=pd.get_dummies(df['month'])
df['deposit']=pd.get_dummies(df['deposit'])
df['contact']= pd.get_dummies(df['contact'])
df['poutcome']= pd.get_dummies(df['poutcome'])

# In[ ]:


X  = df.loc[:,['age', 'job', 'marital', 'education', 'default', 'balance', 'housing','loan','day', 'month', 'duration', 'campaign', 'pdays','previous', 'poutcome']]
y = df['deposit']

# In[ ]:


X_train,X_test,y_train,y_test =train_test_split(X,y,test_size = 0.2)

# In[ ]:


lda =LinearDiscriminantAnalysis()
qda =QuadraticDiscriminantAnalysis()
gnb = GaussianNB()
lr = LogisticRegression(penalty='none',solver = 'newton-cg')
lda.fit(X_train,y_train)
qda.fit(X_train,y_train)
gnb.fit(X_train,y_train)
lr.fit(X_train,y_train)

# In[ ]:


print("LDA : ",lda.score(X_test,y_test))
print("QDA : ",qda.score(X_test,y_test))
print('NBayes score : ',gnb.score(X_test,y_test))
print('LogesticR    : ',lr.score(X_test,y_test))

# In[ ]:


print("LDA : \n",confusion_matrix(y_test,lda.predict(X_test)))
print("QDA : \n",confusion_matrix(y_test,qda.predict(X_test)))
print('\nNBayes Confusion Matrix: \n \n ',confusion_matrix(y_test,gnb.predict(X_test)))
print('\nLogesticR confusion Matrix: \n \n',confusion_matrix(y_test,lr.predict(X_test)))

# In[ ]:



