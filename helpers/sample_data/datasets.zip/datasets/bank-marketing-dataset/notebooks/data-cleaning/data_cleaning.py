#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import missingno as msno


# In[2]:


df = pd.read_csv('../../data/bank.csv')
df


# In[3]:


possible_missing_values = [np.nan, 'None', 'N/a', 'na']


# In[4]:


df = pd.read_csv('../../data/bank.csv', na_values=possible_missing_values)
df


# In[5]:


df.isnull().sum()


# In[6]:


plt.rcParams['figure.dpi'] = 300
plt.figure(figsize=(15, 7))
sns.heatmap(df.isnull(), yticklabels=False, cmap='Greens_r', linecolor='red', linewidths=False)
plt.show()


# In[7]:


df = df.interpolate(method='ffill')
df


# In[8]:


df.isnull().sum()

