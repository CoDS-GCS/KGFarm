#!/usr/bin/env python
# coding: utf-8

# This will be a very, very simple look at the data to determine which countries had unusually high youth unemployment in 2014. 

# In[ ]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load in 

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

from subprocess import check_output
print(check_output(["ls", "../input"]).decode("utf8"))

# Any results you write to the current directory are saved as output.

# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('../input/API_ILO_country_YU.csv', index_col='Country Name')
data = data.drop('Country Code', 1)
print(data.info())

# In[ ]:


data.head()
data.columns = data.columns.astype(str)

# I will create some beeswarm plots to look at the data and get a feel for things.

# In[ ]:


for column in data:
    info = data[column]
    _ = plt.xlabel('Youth Unemployment (%)')
    _ = plt.ylabel('Number of Countries')
    _ = plt.title('World Youth Unemployment')
    sns.swarmplot(info)
    plt.tight_layout()
    plt.show()

# Apparently most countries were between 10 and 20 percent youth unemployment throughout the period our dataset covers. Now I'll take a look at some very simple statistics that will tell me what the exact numbers actually are.

# In[ ]:


for column in data:
    info = data[column]
    std = np.std(info)
    mean = np.mean(info)
    median = np.median(info)
    print(mean, median, std)

# I'm curious to know who my outliers are in 2014 (the whole point of this kernel). For my purposes an outlier is two standard deviations above the mean and I'll use some singularly unsophisticated code to figure out what that is.

# In[ ]:


two_std_above = 17.94353 + 2 * 11.52826
print(two_std_above)

# In[ ]:


high_unemployment = data[data['2014'] >= 41.00005]
print(high_unemployment)

# Well, there you go. There are 13 countries on this list. It is interesting to note that many of these countries would not have made this list in 2010. Egypt especially stands out to me.

# In[ ]:


egypt = high_unemployment.loc['Egypt, Arab Rep.']
rate = high_unemployment[['2010', '2011', '2012', '2013', '2014']]
_ = egypt.plot.bar()
_ = plt.xlabel('Year')
_ = plt.ylabel('Youth Percent Unemployment')
_ = plt.title('Egyptian Youth Unemployment 2010 - 2014')
plt.show()
